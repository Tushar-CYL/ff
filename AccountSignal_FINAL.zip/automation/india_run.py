"""End-to-end INDIA report: all-departments India hiring -> insights -> dashboard + DOCX.

Sources India roles from the discovery dumps (discovery/<slug>_roles_raw.json, produced by discover.py)
so we don't re-scrape, re-enriches them through the SAME classification used in production, adds news +
filings, computes the insights, and renders with the existing delivery modules into output_india/.

Usage:
    python discover.py        # first, to (re)build the India raw dumps
    python india_run.py       # then build the report from them
"""
import json
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor

import settings
import discover
import sources.jobs as jobs
from sources import news as newsmod, filings as filingsmod, people as peoplemod, newsroom as newsroommod
from sources import browser
from analysis import classify, signals as sig, opportunities as oppt, strategic, coverage
from analysis.fields import build_bundle
from analysis.llm import EYQClient, synthesize, synthesize_themes, account_insight
from delivery import export_json, export_excel
from timeframe import Month, now_stamp

DISCOVERY = settings.ROOT / "discovery"
OUT = settings.ROOT / "output_india"
# "Open roles posted in the last month": keep roles posted within this many days of today.
# Matches settings.JOB_RECENCY_DAYS so the LLM narrative's "last N days" text stays accurate.
INDIA_RECENCY_DAYS = int(os.environ.get("INDIA_RECENCY_DAYS", str(settings.JOB_RECENCY_DAYS)))


def _desc(raw):
    html = raw.get("description") or raw.get("jobDescription") or ""
    return re.sub("<[^>]+>", " ", html)


def _load_india_roles(company):
    """Re-enrich the discovery dump for one company through the production enrich path."""
    path = DISCOVERY / f"{company['slug']}_roles_raw.json"
    if not path.exists():
        return []
    dump = json.loads(path.read_text(encoding="utf-8"))
    method = coverage.extraction_method(company)
    roles = []
    for r in dump.get("roles", []):
        raw = r.get("_raw") or {}
        desc = _desc(raw)
        role = jobs._enrich({
            "company": company["name"],
            "role_title": r.get("title", ""),
            "location": r.get("location", ""),
            "country": r.get("country", ""),
            "source_url": r.get("source_url", ""),
            "employment_type": r.get("employment_type_raw", ""),
            "_posted": r.get("posted_date", ""),
            "_description": desc,
        })
        # Provenance: a real JD was captured (grounds skills/team/critical), and by which method.
        # A role may carry its own method from the dump (e.g. Indeed titles-only); prefer that.
        role["description_captured"] = len((desc or "").strip()) > 40
        role["extraction_method"] = r.get("extraction_method") or method
        roles.append(role)
    # Keep India only (safety) and recently-posted (open & fresh).
    roles = [r for r in roles if classify.is_india(r.get("location", "")) or classify.is_india(r.get("country", ""))]
    # Recency applies to deep-scraped postings with reliable posting dates (Radancy/Workday/Avature/
    # Phenom). Indeed + Eightfold rows are current active listings (the source only shows live jobs) so
    # keep them regardless of first-posted date.
    _live = {"indeed", "eightfold"}
    roles = [r for r in roles if r.get("extraction_method") in _live
             or r.get("aging_days") is None or r["aging_days"] <= INDIA_RECENCY_DAYS]
    return roles


# Map our department taxonomy to the words Explorium uses in a leader's department/title, so we can
# attach the most senior relevant leader to each role as the LIKELY manager (not the confirmed req owner).
DEPT_MATCH = {
    "Technology / IT": ["it", "information technology", "data", "engineering", "technology", "digital", "product"],
    "Finance": ["finance", "account", "fp&a", "treasury"],
    "Supply Chain": ["operations", "supply", "procurement", "logistics"],
    "Clinical / R&D": ["research", "r&d", "clinical", "medical", "development", "scientific"],
    "Risk & Compliance": ["legal", "compliance", "risk", "quality", "regulatory", "audit"],
    "Manufacturing": ["operations", "manufacturing", "engineering", "production", "plant"],
    "Commercial & Marketing": ["sales", "marketing", "commercial", "brand", "customer"],
    "HR & People": ["human resources", "hr", "people", "talent"],
}
LEVEL_RANK = {"c-suite": 0, "c_level": 0, "cxo": 0, "president": 0, "owner": 0,
              "vice president": 1, "vp": 1, "director": 2, "head": 2, "manager": 3, "partner": 4}


def _manager_match(role, people):
    """Likely manager with confidence + evidence. High when the JD actually names a person; otherwise a
    confidence-rated match to the department leader; 'Unknown' rather than a guess. Never the confirmed
    requisition owner (that is private)."""
    jd_name = (role.get("hiring_manager") or "").strip()
    if jd_name:
        return {"name": jd_name, "title": role.get("reports_to", ""), "profile": "",
                "confidence": "High", "evidence": "Named in the job posting"}
    keys = DEPT_MATCH.get(role.get("business_domain", ""), [])
    cands = [p for p in people
             if any(k in ((p.get("department") or "") + " " + (p.get("title") or "")).lower() for k in keys)]
    cands.sort(key=lambda p: LEVEL_RANK.get((p.get("level") or "").lower(), 9))
    if not cands:
        return {"name": "Unknown", "confidence": "Unknown", "title": "", "profile": "", "evidence": ""}
    top = cands[0]
    lvl = (top.get("level") or "").lower()
    title = (top.get("title") or "").lower()
    recruiter = "talent" in title or "recruit" in title
    if lvl in ("director", "vice president", "vp", "head"):
        conf = "High"
    elif lvl in ("c-suite", "c_level", "cxo", "president", "owner") or recruiter:
        conf = "Medium"
    else:
        conf = "Low"
    ev = ("Recruiter / TA contact" if recruiter
          else f"Dept leader of {role.get('business_domain')}") + " · Explorium licensed data"
    return {"name": top["name"], "title": top.get("title", ""), "profile": top.get("linkedin", ""),
            "confidence": conf, "evidence": ev}


def _assign_managers(roles, people):
    """Attach a confidence-rated likely manager + an action priority to each role."""
    for r in roles:
        m = _manager_match(r, people or [])
        r["likely_manager"] = m
        conf = m.get("confidence")
        if r.get("critical") and conf == "High":
            r["priority"] = "High"
        elif r.get("critical") or conf in ("High", "Medium"):
            r["priority"] = "Medium"
        else:
            r["priority"] = "Low"


def _collect_news(company, month):
    """Configured source first; if it returns nothing (e.g. Tavily out of credits), fall back to the
    free, keyless Google News feed so #1 Client Intelligence always has real company updates."""
    try:
        items = newsmod.collect(company, month)
    except Exception as e:
        print(f"  news (primary) failed: {type(e).__name__}"); items = []
    if not items:
        try:
            items = newsmod._classify_pool(newsmod._google_pool(company, month), month, company=company)
        except Exception as e:
            print(f"  news (google fallback) failed: {type(e).__name__}"); items = []
    # Official newsroom / investor-relations feeds (first-party, dated) — classified into the same
    # FIELDS and placed FIRST so authoritative announcements lead each field summary.
    try:
        nr = newsroommod.pool(company, month)
        if nr:
            official = newsmod._classify_pool(nr, month, company=company, official=True)
            seen = {(i.get("url") or i["title"]).lower() for i in official}
            items = official + [i for i in items if (i.get("url") or i["title"]).lower() not in seen]
            print(f"  [newsroom] {company['name']}: +{len(official)} official items")
    except Exception as e:
        print(f"  newsroom failed: {type(e).__name__}")
    return items


def _prev_people(month_key):
    """Reuse stakeholder names already fetched (Explorium credits are limited — don't refetch/lose them)."""
    path = OUT / month_key / f"report_{month_key}.json"
    if not path.exists():
        return {}
    try:
        rep = json.loads(path.read_text(encoding="utf-8"))
        return {c["slug"]: c.get("stakeholder_people", []) for c in rep.get("companies", [])}
    except (ValueError, KeyError):
        return {}


def _merged_roster():
    """The full account book to process: full-config clients (settings.COMPANIES, with a career portal)
    FIRST so their deep hiring + Explorium names cache before any minimal-account run, then every other
    account from settings.ACCOUNTS as a minimal dict (name only → global news/strategic signals, no
    hiring until its portal is wired into COMPANIES)."""
    by_slug = {c["slug"]: c for c in settings.COMPANIES}
    ordered, seen = list(settings.COMPANIES), set(by_slug)
    for a in getattr(settings, "ACCOUNTS", []):
        if a["slug"] in seen:
            continue
        seen.add(a["slug"])
        entry = {"name": a["name"], "slug": a["slug"], "sector": a["sector"],
                 "listing": "", "region": a.get("region", ""), "aliases": [a["name"]]}
        extra = getattr(settings, "CAREERS_EXTRA", {}).get(a["slug"])
        if extra:
            entry["careers"] = extra  # custom/virtualized site scraped best-effort via remote browser
        ordered.append(entry)
    return ordered


def _build_company(company, month, client, saved_people):
    """Compute one account's block: news → synthesis → strategic signals, with India hiring + people
    only where a career portal / identifiers exist. Network + LLM heavy — the caller caches the result."""
    roles = _load_india_roles(company)
    news_items = _collect_news(company, month)
    filing_items = []
    if company.get("sec_cik") or company.get("rns_ticker"):
        try:
            filing_items = filingsmod.collect(company, month)
        except Exception as e:
            print(f"  filings failed: {type(e).__name__}")
    jobs_data = {"careers_url": company.get("careers", {}).get("url", ""), "roles": roles,
                 "total_roles": len(roles), "it_roles": len(roles), "it_all_time": len(roles)} if roles else None
    bundle = build_bundle(company, news_items, filing_items, jobs_data, month)
    synthesis = synthesize(bundle, client)
    opps = oppt.detect(roles) if roles else []
    strat = newsmod.strategy_research(company)
    all_titles = [i["title"] for i in news_items] + [s["title"] for s in strat]
    ins = account_insight(company, bundle["jobs_agg"], all_titles, opps, client)
    # Reuse already-fetched names to conserve Explorium credits; only call for clients that have roles.
    stake_people = saved_people.get(company["slug"]) or (peoplemod.stakeholders(company) if roles else [])
    _assign_managers(roles, stake_people)
    critical_roles = [r for r in roles if r.get("critical")]
    emp = classify.Counter(r.get("employment_category") for r in roles).most_common()
    most_active = (bundle["jobs_agg"]["by_business_domain"][0] if bundle["jobs_agg"] else ["", 0])
    # Strategic signals from the GLOBAL market record (clean synthesized field summaries + strategy heads).
    evidence = strategic.evidence_from_live(synthesis, strat)
    dept = classify.Counter(r["business_domain"] for r in roles) if roles else {}
    print(f"  {company['name']}: roles {len(roles)} | news {len(news_items)} | filings {len(filing_items)} "
          f"| signals {len(strategic.partnership_signals(company, evidence))} | depts {dict(dept)}")
    return {
        "name": company["name"], "slug": company["slug"], "sector": company["sector"],
        "region": company.get("region", ""),
        "provenance": coverage.provenance(company, roles),
        "strategic_signals": strategic.partnership_signals(company, evidence),
        "tool_gravitation": strategic.tool_gravitation(bundle["jobs_agg"], evidence),
        "listing": company.get("listing", ""), "direction": synthesis["direction"],
        "key_development": synthesis["key_development"], "fields": synthesis["fields"],
        "takeaways": ins.get("takeaways", []),
        "current_state": ins.get("current_state", ""),
        "discovery_questions": ins.get("discovery_questions", []),
        "strategy": ins.get("strategy", ""), "strategy_sources": strat[:4],
        "why_hiring": ins["why"], "investments": ins["investments"],
        "stakeholders": ins["stakeholders"], "actions": ins["actions"],
        "stakeholder_people": stake_people, "filings_count": len(filing_items),
        "critical_count": len(critical_roles), "employment": emp,
        "most_active_team": {"name": most_active[0], "roles": most_active[1]},
        "jobs_agg": bundle["jobs_agg"],
        "role_sample": sorted(roles, key=lambda r: r.get("posted_date", ""), reverse=True)[:40],
        "opportunities": opps, "careers_url": (jobs_data or {}).get("careers_url", ""),
        "jobs_available": jobs_data is not None,
    }


def _scrape_all():
    """STEP 1: scrape India hiring from every configured official career site (refreshes the discovery
    dumps india_run reads). Each company is isolated — one failing site keeps its previous dump. Set
    SKIP_SCRAPE=1 to reuse existing dumps (e.g. to only re-run enrichment)."""
    if os.environ.get("SKIP_SCRAPE") == "1":
        print("SKIP_SCRAPE=1 — reusing existing discovery dumps (no re-scrape).")
        return
    # Scrape every account that has a career portal wired — the official-ATS clients (COMPANIES) AND the
    # custom/virtualized sites registered in settings.CAREERS_EXTRA (scraped via the Bright Data browser).
    roster = [c for c in _merged_roster() if c.get("careers")]
    engine = "Bright Data remote browser" if browser.remote_enabled() else "local browser / direct HTTP"
    print(f"STEP 1/2 — scraping India hiring from {len(roster)} career sites (engine: {engine}) ...")

    # Per-company HARD time budget (seconds). On the office network every page goes through the (slow)
    # Bright Data remote browser, so one heavy site — a big Phenom board, or a JS site that won't load —
    # can stall the whole run. If a company exceeds this budget we abandon it, KEEP its previous dump,
    # and move on, so the run always finishes. Raise it (e.g. SCRAPE_TIMEOUT=900) to let big sites finish.
    budget = int(os.environ.get("SCRAPE_TIMEOUT", "360"))

    def _scrape_company(c):
        # Retry a few times on an exception (e.g. a flaky Bright Data session / TargetClosedError) before
        # giving up; a failed scrape never wipes good data (discover.scrape_and_save keeps the previous dump).
        for attempt in range(3):
            try:
                n = discover.scrape_and_save(c)
                print(f"  [ok] {c['name']}: {n} India roles")
                return
            except Exception as e:
                if attempt < 2:
                    continue
                print(f"  [!!] {c['name']}: scrape failed ({type(e).__name__}) - keeping previous dump")

    def _one(c):
        # Run the scrape in a daemon thread and wait at most `budget` seconds. If it overruns, we leave the
        # thread to die with the process and carry on — the dump for that company is simply not refreshed
        # (its previous data is kept), so a single slow/stuck site never hangs the whole pipeline.
        t = threading.Thread(target=_scrape_company, args=(c,), daemon=True)
        t.start()
        t.join(budget)
        if t.is_alive():
            print(f"  [timeout] {c['name']}: exceeded {budget}s via the remote browser - skipped "
                  f"(kept previous dump). Set SCRAPE_TIMEOUT higher to let it finish.")

    # Direct-HTTP ATS sites run CONCURRENTLY across companies (each also fetches its job pages in a thread
    # pool), which is where the speed-up is. Browser / Bright Data sites run sequentially because each
    # opens its own remote session (per-session domain limit + plan concurrency).
    http_kinds = {"radancy", "workday", "avature", "phenom"}
    http_sites = [c for c in roster if c["careers"]["type"] in http_kinds]
    browser_sites = [c for c in roster if c["careers"]["type"] not in http_kinds]
    workers = int(os.environ.get("SCRAPE_WORKERS", "4"))
    if http_sites:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(_one, http_sites))
    for c in browser_sites:
        _one(c)
    # Indeed-fallback accounts (no official career site) keep their existing dumps; refresh those via
    # `python -m delivery.indeed_ingest` in a Claude Code session when you re-pull Indeed.
    print("STEP 2/2 — enriching (news + newsroom + filings + signals + LLM) and exporting ...")


def run():
    _scrape_all()
    # REPORT_MONTH env (YYYY-MM) overrides the default (previous complete month) — lets us run the
    # current month so same-month news/newsroom/IR items fall inside the window.
    month = Month(os.environ.get("REPORT_MONTH") or settings.default_month())
    saved_people = _prev_people(month.key)
    client = EYQClient()
    if not client.configured:
        client = None
    OUT.mkdir(parents=True, exist_ok=True)
    out_dir = OUT / month.key
    out_dir.mkdir(parents=True, exist_ok=True)

    # Resumable, batched run across the FULL account book. Each account's expensive block (news + LLM)
    # is cached under output_india/<month>/_cache/<slug>.json, so a stopped run resumes where it left
    # off and the dashboard/Excel show partial progress. ACCOUNT_LIMIT caps new (uncached) accounts per
    # invocation (batching to protect memory/credits); ACCOUNT_FORCE=1 recomputes even cached ones.
    cache_dir = out_dir / "_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    limit = int(os.environ.get("ACCOUNT_LIMIT", "999"))
    # Fresh by default: recompute every account each run so the dashboard + Excel reflect THIS run's data
    # (not a stale cache). Set RESUME=1 to reuse the cache and continue an interrupted run instead.
    force = os.environ.get("ACCOUNT_FORCE") == "1" or os.environ.get("RESUME") != "1"

    roster = _merged_roster()
    # Decide which accounts need the expensive (news + LLM) build this run: uncached, or all when
    # ACCOUNT_FORCE=1, capped by ACCOUNT_LIMIT for batching. Then compute them CONCURRENTLY — each
    # account is independent (its own news/filings/LLM), so a thread pool overlaps the network/LLM waits
    # (GDELT stays rate-limited by a shared lock). Each worker writes its own cache file.
    to_compute = [c for c in roster if force or not (cache_dir / f"{c['slug']}.json").exists()][:limit]

    def _build_cached(company):
        try:
            block = _build_company(company, month, client, saved_people)
            (cache_dir / f"{company['slug']}.json").write_text(
                json.dumps(block, indent=2, ensure_ascii=False), encoding="utf-8")
            return company["slug"], True
        except Exception as e:
            print(f"  [!!] {company['name']}: enrich failed ({type(e).__name__}: {str(e)[:80]})")
            return company["slug"], False

    if to_compute:
        workers = int(os.environ.get("ENRICH_WORKERS", "4"))
        print(f"Enriching {len(to_compute)} accounts ({workers} workers) ...")
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for slug, ok in ex.map(_build_cached, to_compute):
                print(f"  [done] {slug}" + ("" if ok else " (failed)"))

    # Assemble the report in roster order from the cache (fresh roles re-loaded locally per account).
    companies, all_roles, companies_agg, roles_by_company = [], [], {}, {}
    for company in roster:
        slug = company["slug"]
        cache_file = cache_dir / f"{slug}.json"
        if not cache_file.exists():
            continue  # not computed this batch and no prior cache — left for a later batch
        block = json.loads(cache_file.read_text(encoding="utf-8"))
        roles = _load_india_roles(company)
        companies.append(block)
        all_roles.extend(roles)
        if block.get("jobs_agg"):
            companies_agg[slug] = block["jobs_agg"]
        roles_by_company[slug] = roles
    print(f"Accounts in report: {len(companies)} (computed {len(to_compute)} this run)")

    cross = classify.cross_client(all_roles) if all_roles else None
    snap_now = classify.snapshot(companies_agg)
    (out_dir / "snapshot.json").write_text(json.dumps(snap_now, indent=2, ensure_ascii=False), encoding="utf-8")
    prev_path = OUT / settings.prev_month(month.key) / "snapshot.json"
    prev_snap = json.loads(prev_path.read_text(encoding="utf-8")) if prev_path.exists() else None

    report = {
        "month": month.key,
        "month_label": f"India · all departments · open roles, last {INDIA_RECENCY_DAYS} days (as of {now_stamp()})",
        "generated": now_stamp(),
        "prev_month": settings.prev_month(month.key) if prev_snap else None,
        "companies": companies, "cross_client": cross,
        "changes": sig.what_changed(snap_now, prev_snap),
        "heatmap": sig.heatmap(companies, prev_snap),
        "tech_demand": sig.tech_demand(cross),
        "tech_radar": sig.tech_radar(cross),
        "sectors": sig.sector_intelligence(companies),
        "talent": sig.talent_intelligence(all_roles, cross) if cross else None,
        "opportunity_radar": oppt.radar(companies),
    }
    report["themes"] = synthesize_themes(report, client)

    (out_dir / f"report_{month.key}.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    data_path = settings.ROOT / "webapp" / "public" / "data.json"
    export_json.build(report, roles_by_company, str(data_path))
    # Push the fresh data into the prebuilt dashboard (out/) so the UI shows it WITHOUT an npm rebuild
    # (the app fetches /data.json at runtime; serve_nocache.py serves out/).
    out_data = settings.ROOT / "webapp" / "out" / "data.json"
    if out_data.parent.exists():
        out_data.write_text(data_path.read_text(encoding="utf-8"), encoding="utf-8")
    xlsx_path = out_dir / f"account_intelligence_{month.key}.xlsx"
    try:
        export_excel.build(report, roles_by_company, settings.ACCOUNTS, str(xlsx_path))
    except Exception as e:
        print(f"  Excel export failed: {type(e).__name__}: {e}")
        xlsx_path = None

    hiring = sum(1 for rs in roles_by_company.values() if rs)
    roles = sum(len(rs) for rs in roles_by_company.values())

    # Scrape-health summary: of the accounts that HAVE a career portal wired, which returned 0 India
    # roles this run (worth a look — bot-wall / site change), vs the rest that are blank by design.
    wired = {c["slug"]: c["name"] for c in _merged_roster() if c.get("careers")}
    zero_wired = sorted(nm for sl, nm in wired.items() if not roles_by_company.get(sl))
    print("\n" + "=" * 64)
    print(f"  SCRAPE HEALTH — {len(wired) - len(zero_wired)}/{len(wired)} wired portals returned India roles")
    if zero_wired:
        print(f"  Review (wired but 0 this run; kept any previous data): {', '.join(zero_wired)}")
    print("=" * 64)
    print(f"  DONE - {len(companies)} accounts | {hiring} with India hiring | {roles} roles ({month.key})")
    print(f"  BI Excel : {xlsx_path}" if xlsx_path else "  BI Excel : (failed)")
    print(f"  Report   : {out_dir / ('report_' + month.key + '.json')}")
    print("  --- Open the dashboard -------------------------------")
    print("    cd webapp && python serve_nocache.py")
    print("    then open  http://localhost:3000")
    print("=" * 64)
    browser.shutdown()  # close the shared Bright Data fallback browser, if one was opened
    return report


if __name__ == "__main__":
    run()
