# EY — India Account Intelligence Engine · Project Dossier

_Single source of truth: what we're building, what the manager asked for, every account + its source
URLs, what's done, and the honest gaps. First-to-last._

---

## 1. What I am trying to make

A **monthly account-intelligence engine** for EY's Sales & Account Management function, covering ~**50
target accounts**. Per company it produces, and presents in a **dashboard** + a **Power-BI Excel**:

- **India hiring** (India-only): open roles with department, competency, seniority, team, permanent/
  contract, critical flag, skills, location.
- **Market intelligence** (global, past full month) across the **5 fields** — Hiring · Vision & strategy ·
  Partnerships · Financial performance · Expansion.
- **True strategic signals** — partnerships, change-of-vision, **tool-gravitation** (which platform/vendor
  a client is leaning into, e.g. *Cargill → Neo4j*) → mapped to the **EY opportunity**.
- **Opportunity radar, technology radar, cross-client themes, named stakeholders, LLM takeaways.**

**It is NOT a hiring scraper** — hiring is one input; the value is tying hiring *together with* news,
partnerships, filings and strategy into an EY opportunity.

**Golden rules**
- **Hiring = India only. All other signals = global, past full month.**
- **Never fake data.** A company with no scrapable hiring shows blank hiring + its global signals (with a
  coverage badge), never a fabricated number.
- **Scraping runs on the personal laptop** (open network); the **office laptop is a viewer** (its firewall
  blocks most career sites).

---

## 2. What my manager wants — and status

| # | Manager requirement | Status |
|---|---|---|
| 1 | Holistic per-account drill-down: total open reqs → **critical** reqs → most-active **team** (buy signal) | ✅ Done (dashboard cards + deep-dive) |
| 2 | **Permanent vs contract** staffing signal (~20% permanent → contractor demand) | ✅ Done (employment split + deep-dive chart) |
| 3 | **Strategy / "explore, research"** insight per account | ✅ Done (strategy field + LLM) |
| 4 | **True insights**: Partnerships, change-of-vision, **tool-gravitation** (vendor → EY angle) | ✅ Done (`analysis/strategic.py`) |
| 5 | **India hiring only; all other signals global** | ✅ Done |
| 6 | **Technology radar / domain concentration / exec narrative** (KPI cards) | ✅ Done |
| 7 | **BI-ready Excel** to drop into Power BI | ✅ Done (`account_intelligence_<month>.xlsx`, 4 sheets) |
| 8 | **Keep the Next.js dashboard** too (both, not either/or) | ✅ Done |
| 9 | **Scale to all ~50 accounts** (region-tagged BLR/Hyd/West) | ✅ Roster complete; hiring 40/50 (see §4) |
| 10 | **Past full month** data, from **Google News + official newsroom URLs** | ✅ Google News+filings all 50; newsroom wired (see §6) |
| 11 | **Value-adding, not time-consuming**; scannable; deploy-worthy | ✅ Static dashboard + Excel, one-command pipeline |
| 12 | Named **stakeholders / decision-makers** | ⚠️ Partial — public only; Explorium (licensed) out of credits |
| — | **OUT OF SCOPE** (separate topic): pharma domain value-chain / accelerator / Databricks-MS-gap research | ⛔ Not built (as instructed) |

---

## 3. Data sources

**Hiring (India)** — each company's **official career portal** via these ATS adapters (in `discover.py`):
Radancy · Workday · Avature · Phenom · Eightfold · SuccessFactors, plus a generic **browser** adapter for
custom/virtualized sites. **Indeed** (last-month filtered) is the assisted fallback for sites that block
automation.

**Scraping engine (`sources/browser.py`):** all browser-driven adapters, and a fallback for any blocked
HTTP GET, run through the **Bright Data Scraping Browser** (`BRIGHTDATA_CDP`). The browser executes on
Bright Data's servers, which (a) defeats bot-walls / CAPTCHAs / virtualized SPAs and (b) makes the one
command work on the **office laptop** too — the laptop only talks to `brd.superproxy.io:9222`, never the
blocked career sites. A fresh Bright Data session is opened per company (per-session domain limit), and an
empty scrape never overwrites existing/Indeed data.

**News correlation ranking (`analysis/relevance.py`):** every news/newsroom item is scored by how strongly
it correlates to the account (named in title vs body), to a tracked vendor/partnership/vision signal, by
recency, and by first-party source, so the most relevant items lead each field and feed the LLM + Excel.
Internal only — it changes ordering, not the dashboard layout.

**Insights (global, past full month):**
- **Google News** (date-bounded RSS) + **GDELT** — classified into the 5 fields. _Primary, all 50._
- **Official newsroom / investor-relations RSS** (`sources/newsroom.py`) — first-party announcements.
- **SEC EDGAR** (US) + **RNS** (UK) — regulatory/financial filings.
- **Tavily** — targeted strategy research (optional).

**News / insight reference URLs (manager-provided):**
- Newsrooms: Cargill `cargill.com/news` · Microsoft `news.microsoft.com` · Adobe `news.adobe.com` ·
  Unilever `unilever.com/news` · PMI `pmi.com/media-center`
- Investor relations / filings: `sec.gov/edgar` · `nseindia.com` · Unilever / Microsoft / PMI IR pages
- RSS feeds: Estée Lauder IR RSS · Colgate IR RSS
- Business news (reference): Reuters · Bloomberg · CNBC · Business Standard · Economic Times

---

## 4. The 50 accounts — careers portal, hiring source, coverage

Legend — **Coverage**: `Full JD` = deep scrape w/ job description · `Titles` = official site, titles+dept
(Eightfold/SF) · `Indeed` = last-month Indeed fallback · `None` = no scrapable India hiring (signals only).

| # | Company | Careers portal (official) | ATS / source | Coverage |
|---|---|---|---|---|
| 1 | Unilever | careers.unilever.com | Radancy | Full JD |
| 2 | Cargill | careers.cargill.com | Radancy | Full JD |
| 3 | Takeda | jobs.takeda.com/india | Radancy | Full JD |
| 4 | Tesco | tesco.com/careers (India) | Avature | Full JD |
| 5 | Nike | careers.nike.com | Workday | Full JD |
| 6 | BP | careers.bp.com | Workday | Full JD |
| 7 | TIAA | careers.tiaa.org | Workday | Full JD |
| 8 | Carrier | jobs.carrier.com | Workday | Full JD |
| 9 | Diageo | careers.diageo.com | Workday | Full JD |
| 10 | Adobe | careers.adobe.com | Phenom | Full JD |
| 11 | Lowe's | talent.lowes.com | Phenom | Full JD |
| 12 | Thermo Fisher | jobs.thermofisher.com | Phenom | Full JD |
| 13 | Procter & Gamble | pgcareers.com | Phenom | Full JD |
| 14 | GSK | jobs.gsk.com | Phenom | Full JD |
| 15 | DaVita | careers.davita.com | Phenom | Full JD |
| 16 | BCG | careers.bcg.com | Phenom | Full JD |
| 17 | AstraZeneca | careers.astrazeneca.com | Radancy | Full JD |
| 18 | Chevron | careers.chevron.com | Radancy | Full JD |
| 19 | Flex | flex.com/careers (flextronics.wd1) | Workday | Full JD |
| 20 | Qualcomm | careers.qualcomm.com | Eightfold | Titles |
| 21 | Microsoft | apply.careers.microsoft.com | Eightfold | Titles |
| 22 | Applied Materials | careers.appliedmaterials.com | Eightfold | Titles |
| 23 | Estée Lauder | careers.elcompanies.com | Eightfold | Titles |
| 24 | Colgate-Palmolive | jobs.colgate.com | SuccessFactors | Titles |
| 25 | Alstom | jobsearch.alstom.com | SuccessFactors | Titles |
| 26 | Novo Nordisk | careers.novonordisk.com | SuccessFactors | Titles |
| 27 | Kimberly-Clark | careers.kimberly-clark.com | (403 bot-wall) | Indeed |
| 28 | Caterpillar | careers.caterpillar.com | (custom JS) | Indeed |
| 29 | Merck | jobs.merck.com / merckgroup.com | (custom JS) | Indeed |
| 30 | SLB | careers.slb.com | (custom JS) | Indeed |
| 31 | Baker Hughes | careers.bakerhughes.com | Phenom (no JSON-LD) | Indeed |
| 32 | PepsiCo | pepsicojobs.com | Jibe / Paradox | Indeed |
| 33 | Rio Tinto | careers.riotinto.com | (custom) | Indeed |
| 34 | HCLTech | hcltech.com/careers | SuccessFactors (non-std) | Indeed |
| 35 | Levi's | levistrauss.com/careers | (custom) | Indeed |
| 36 | ZS Associates | zs.com/careers (jobs.zs.com) | iCIMS | Indeed |
| 37 | Kohler | kohlercompany.com/careers | (custom) | Indeed |
| 38 | DTICI (Daimler Truck) | daimlertruck.com/en/career | (custom) | Indeed |
| 39 | MBRDI (Mercedes-Benz R&D) | group.mercedes-benz.com/careers | (custom) | Indeed |
| 40 | Philip Morris Intl (PMI) | pmicareers.com | (custom) | Indeed |
| 41 | Airbnb | careers.airbnb.com | custom React (virtualized) | None* |
| 42 | AB InBev | ab-inbev.com/careers | custom | None |
| 43 | Colt Technology | colt.net/careers | custom | None |
| 44 | Kellogg's (Kellanova) | kellanova.com/careers | custom | None |
| 45 | Godrej | godrejindustries.com/careers | custom | None |
| 46 | 7-Eleven | careers.7-eleven.com | Radancy (≈0 India) | None |
| 47 | Henny Penny | hennypenny.com | private/small | None |
| 48 | Magnum ICC | (identity unconfirmed) | — | None |
| 49 | Magnum International | (identity unconfirmed) | — | None |
| 50 | North Star | (identity unconfirmed) | — | None |

\*Airbnb: loads via a real browser and shows ~5 India roles, but its virtualized React filter resists
automation — captured as "None" rather than fake data. All 50 still carry full **global insights**
regardless of hiring coverage.

**Tally:** ~**19 Full JD · 7 Titles · 14 Indeed (last-month) · 10 None** → **40/50 with hiring, ~2,170
India roles**; **50/50 with global insights**.

---

## 5. What we've done so far (first → last)

1. **Phase 1** — Next.js dashboard for 4 clients (hiring + insights), driven by `data.json`.
2. **Phase 2** — `analysis/strategic.py` (partnership / vision / tool-gravitation signals) + BI **Excel**
   export + the **50-account region-tagged roster** + dashboard "Partnerships & tool bets" card + region filter.
3. **Coverage/provenance** — `analysis/coverage.py`: every account tagged `full_jd / titles_only /
   signals_only`, so observed data is never confused with a gap. Team name + any JD-named person surfaced.
4. **Scaled hiring 8 → 40 from official sites** — generalized Workday; built **Phenom** (JSON-LD sitemap),
   **Eightfold** (PCSX API via Playwright), **SuccessFactors** (CSB render via Playwright) adapters;
   added Diageo, Adobe, Lowe's, Thermo Fisher, P&G, GSK, DaVita, BCG, AstraZeneca, Chevron, Flex, Qualcomm,
   Microsoft, Applied Materials, Estée Lauder, Colgate, Alstom, Novo.
5. **Indeed fallback (last-month)** — `delivery/indeed_ingest.py` for the 14 bot-walled/custom sites;
   company-match guard drops keyword-junk; filtered to the last 31 days by posting date.
6. **Newsroom/IR source** — `sources/newsroom.py` auto-discovers official RSS feeds; classified into the 5
   fields (contributes where a site has a past-month feed; Google News covers the rest).
7. **Dashboard deep-dive** — added 2 data-backed charts: **Hiring by India city** (normalized) and
   **Permanent vs Contract vs Internship**.
8. **One-command pipeline** — `python india_run.py` now scrapes → enriches → generates Excel → refreshes
   the UI data → prints the dashboard URL. Non-destructive scrape (a blocked network never wipes data).
9. **Code cleanup** — removed dead modules/code; **README.md** run guide; **zip** (with `.env`, prebuilt UI,
   data, Excel) for the office laptop.

---

## 6. Honest gaps / notes
- **Newsroom RSS for a *past* month yields little** — feeds are current-biased, so past-month items are
  mostly gone from them. Google News (date-bounded) + filings carry the official news for the past month.
- **10 accounts have no scrapable India hiring** — bot-walled/custom/virtualized sites or tiny-private
  firms. They need either a paid bot-defeating scraper (Bright Data paid tier) or per-site bespoke work;
  all still have full global insights.
- **Stakeholder names** are limited to public sources; deeper named-leader lists need Explorium credits.
- **Full fresh scrape of all official sites is slow** (~45–90 min — big Phenom/Eightfold sitemaps). Use
  `SKIP_SCRAPE=1` to re-run insights only in minutes; lower the Phenom/Eightfold page cap to speed scrapes.

---

## 7. How to run — see `README.md`
- **View (office laptop):** `cd webapp && python serve_nocache.py` → http://localhost:3000
- **Refresh (personal laptop):** `python india_run.py` (one command: scrape + insights + Excel + UI)
- Knobs: `SKIP_SCRAPE=1`, `ACCOUNT_FORCE=1`, `REPORT_MONTH=YYYY-MM`.
