"""BI-ready Excel export (openpyxl).

Writes one workbook holding every textual AND numerical signal in a Power-BI-pivot-friendly shape, so
an account manager can drop it straight into Power BI (the resolution of the "why not Power BI?" debate)
WITHOUT touching the code. Four flat, tidy sheets:

  Accounts     one row per account (the full book) — the landscape + headline signal
  Hiring       one row per India role — numerical / competency columns that drive BI graphs
  Insights     one row per signal across ALL fields — the textual table (company, date, type, text,
               vendor, source, EY opportunity)
  Skill demand tidy Company x Competency x count rows for one-drag BI pivots

Tolerant by design: it fills region/sector from the account roster and computes strategic signals from
the company if they were not pre-attached, so it also runs off an already-generated report_<month>.json.
"""
from collections import Counter

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

import settings
from analysis import strategic, coverage

_COMPANIES_BY_SLUG = {c["slug"]: c for c in settings.COMPANIES}


def _provenance(c, roles):
    """Pre-attached provenance, or compute it (resolving the ATS config from settings by slug)."""
    p = c.get("provenance")
    if p:
        return p
    cfg = _COMPANIES_BY_SLUG.get(c["slug"], {})
    return coverage.provenance({**c, "careers": cfg.get("careers")}, roles)


def _manager_cell(r):
    """A person's name tied to the role: the JD-named manager (observed), else a confidence-rated
    likely manager, else blank — never 'Unknown', never a fabricated name."""
    named = (r.get("hiring_manager") or "").strip()
    if named:
        return f"{named} (named in JD)"
    lm = r.get("likely_manager") or {}
    nm = (lm.get("name") or "").strip()
    if nm and nm != "Unknown":
        return f"{nm} (likely · {lm.get('confidence', '')})".replace(" · )", ")")
    return ""

EY_YELLOW = "FFE600"
EY_DARK = "2E2E38"
HEADER_FONT = Font(bold=True, color=EY_DARK, size=11)
HEADER_FILL = PatternFill("solid", fgColor=EY_YELLOW)
WRAP = Alignment(vertical="top", wrap_text=True)
TOP = Alignment(vertical="top")


def _region_label(code):
    return settings.REGIONS.get(code or "", code or "—")


def _signals_for(c):
    """Pre-attached strategic signals, or compute from the report company (no re-scrape)."""
    sig = c.get("strategic_signals")
    if sig is None:
        sig = strategic.partnership_signals(c, strategic.evidence_from_report_company(c))
    return sig or []


def _gravitation_for(c):
    grav = c.get("tool_gravitation")
    if grav is None:
        grav = strategic.tool_gravitation(c.get("jobs_agg"), strategic.evidence_from_report_company(c))
    return grav or []


def _roles_for(c, roles_by_company):
    return roles_by_company.get(c["slug"]) if roles_by_company.get(c["slug"]) else c.get("role_sample") or []


def _sheet(wb, title, headers, widths):
    ws = wb.create_sheet(title)
    ws.append(headers)
    for i, (h, w) in enumerate(zip(headers, widths), start=1):
        cell = ws.cell(row=1, column=i)
        cell.font, cell.fill, cell.alignment = HEADER_FONT, HEADER_FILL, TOP
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    return ws


def _finish(ws, wrap_cols=()):
    last = get_column_letter(ws.max_column)
    ws.auto_filter.ref = f"A1:{last}{ws.max_row}"
    for col in wrap_cols:
        for row in range(2, ws.max_row + 1):
            ws.cell(row=row, column=col).alignment = WRAP


def build(report, roles_by_company, accounts, path):
    roles_by_company = roles_by_company or {}
    generated = report.get("generated", "")
    month = report.get("month", "")
    companies = {c["slug"]: c for c in report.get("companies", [])}
    reg = {a["slug"]: a.get("region", "") for a in accounts}
    sec = {a["slug"]: a.get("sector", "") for a in accounts}

    wb = Workbook()
    wb.remove(wb.active)

    # ---- Accounts: the full book, one row each (hiring blank where not yet scraped) ----
    ws = _sheet(wb, "Accounts",
                ["Company", "Region", "Sector", "Listing", "Direction", "India open roles",
                 "Critical roles", "Top capability", "Headline partnership / tool",
                 "Coverage", "Hiring source"],
                [22, 16, 24, 16, 14, 15, 13, 24, 46, 13, 18])
    for a in accounts:
        c = companies.get(a["slug"])
        if c:
            agg = c.get("jobs_agg") or {}
            comp = agg.get("by_competency") or []
            sig = _signals_for(c)
            grav = _gravitation_for(c)
            prov = _provenance(c, _roles_for(c, roles_by_company))
            headline = ""
            part = next((s for s in sig if s["type"] == "Partnership"), None)
            if part:
                headline = f"{part['vendor']}: {part['headline']}" if part["vendor"] else part["headline"]
            elif grav:
                headline = f"Gravitating to {grav[0]['vendor']} ({grav[0]['ey_angle']})"
            row = [c["name"], _region_label(a.get("region") or c.get("region", "")),
                   a.get("sector") or c.get("sector", ""), c.get("listing", ""), c.get("direction", ""),
                   agg.get("total_open_roles", 0), c.get("critical_count", 0),
                   comp[0][0] if comp else "", headline[:300],
                   prov.get("coverage_label", ""), prov.get("method_label", "")]
        else:
            row = [a["name"], _region_label(a.get("region", "")), a.get("sector", ""), "", "",
                   None, None, "", "", "Signals only", "—"]
        ws.append(row)
    _finish(ws, wrap_cols=(8, 9))

    # ---- Hiring: one row per India role ----
    ws = _sheet(wb, "Hiring",
                ["Company", "Region", "Date posted", "Department", "Team", "Competency", "Role type",
                 "Seniority", "Location", "Critical", "Work mode", "Top skill",
                 "Manager / contact", "Source", "Extraction"],
                [20, 14, 12, 18, 24, 18, 20, 13, 16, 9, 11, 20, 30, 40, 16])
    for slug, c in companies.items():
        region = _region_label(reg.get(slug) or c.get("region", ""))
        method_lbl = _provenance(c, _roles_for(c, roles_by_company)).get("method_label", "")
        for r in _roles_for(c, roles_by_company):
            skills = r.get("skills") or []
            ws.append([c["name"], region, r.get("posted_date", ""),
                       r.get("business_domain", ""), r.get("team", ""), r.get("competency_cluster", ""),
                       r.get("role_type", ""), r.get("seniority", ""), r.get("location", ""),
                       "Yes" if r.get("critical") else "No", r.get("work_mode", ""),
                       skills[0] if skills else "", _manager_cell(r),
                       r.get("source_url", ""), method_lbl])
    _finish(ws, wrap_cols=(13,))

    # ---- Insights: one row per signal across ALL fields (the textual table) ----
    ws = _sheet(wb, "Insights",
                ["Company", "Region", "Date", "Type", "Insight", "Vendor / Tool", "Source", "EY opportunity"],
                [20, 16, 12, 18, 70, 18, 40, 42])
    field_label = {k: v["label"] for k, v in settings.FIELDS.items()}
    for slug, c in companies.items():
        region = _region_label(reg.get(slug) or c.get("region", ""))
        # Strategic signals first (partnerships / tool bets / vision) — the headline insights.
        _sigs = _signals_for(c)
        for s in _sigs:
            ws.append([c["name"], region, month, s["type"], s["headline"], s.get("vendor", ""),
                       s.get("source", ""), s.get("ey_opportunity", "")])
        # Tool-gravitation ranking (demand + market) as its own rows.
        for g in _gravitation_for(c):
            note = f"Gravitating toward {g['vendor']} — {g['hiring']} hiring signals, {g['mentions']} news mentions."
            ws.append([c["name"], region, month, "Tool gravitation", note, g["vendor"],
                       g.get("source", ""), g.get("ey_angle", "")])
        # The five market-intelligence field summaries (de-duplicated across fields AND vs the signals).
        _flds = strategic.strip_signals_from_fields(
            strategic.dedupe_field_summaries(c.get("fields") or {}, c), _sigs, c)
        for key, f in _flds.items():
            summ = (f or {}).get("summary") or ""
            if summ and summ != "No material developments this period.":
                srcs = (f or {}).get("sources") or []
                ws.append([c["name"], region, month, field_label.get(key, key), summ, "",
                           srcs[0] if srcs else "", (f or {}).get("significance", "")])
        # LLM connect-the-dots takeaways.
        for t in c.get("takeaways") or []:
            ws.append([c["name"], region, month, "Takeaway", t, "", "", ""])
    _finish(ws, wrap_cols=(5, 8))

    # ---- Skill demand: tidy Company x Competency x count ----
    ws = _sheet(wb, "Skill demand", ["Company", "Region", "Competency", "Open roles"], [20, 16, 24, 12])
    for slug, c in companies.items():
        region = _region_label(reg.get(slug) or c.get("region", ""))
        for comp, n in (c.get("jobs_agg") or {}).get("by_competency", []):
            ws.append([c["name"], region, comp, n])
    _finish(ws)

    wb.save(path)
    return path
