"""Export the India report as the JSON the Next.js app consumes (webapp/public/data.json).

Shapes the pipeline's report + roles into the data the front end reads. The app is data-driven:
replacing data.json and reloading updates the whole UI. Self-contained (no HTML renderer)."""
import json
import re
from collections import Counter
from pathlib import Path

import settings
from analysis import strategic, coverage

_COMPANIES_BY_SLUG = {c["slug"]: c for c in settings.COMPANIES}


def _provenance(c, roles):
    p = c.get("provenance")
    if p:
        return p
    cfg = _COMPANIES_BY_SLUG.get(c["slug"], {})
    return coverage.provenance({**c, "careers": cfg.get("careers")}, roles)


DEPT_RELABEL = {"General / Other": "Cross-functional", "Other": "Cross-functional"}
HEAT_LABELS = {"AI": "AI & GenAI", "Data": "Data & analytics", "Cloud": "Cloud platform",
               "Cyber": "Cybersecurity", "ERP": "ERP", "Automation": "Automation",
               "Digital Eng.": "Digital engineering"}
ROLE_KEYS = ["role_title", "business_domain", "team", "reports_to", "location", "seniority", "skills",
             "posted_date", "aging_days", "source_url", "critical", "employment_category",
             "likely_manager", "priority", "hiring_manager", "work_mode", "extraction_method",
             "description_captured"]

# The 8-stage Technology Consulting Sales journey; stages 1-3 are powered by live data.
JOURNEY = [
    {"n": 1, "name": "Market & Account Insight", "covered": True,
     "desc": "Where to play and who to target", "metric": "opportunity theses"},
    {"n": 2, "name": "Relationship Building", "covered": True,
     "desc": "Engage key stakeholders, earn the right to advise", "metric": "stakeholders mapped"},
    {"n": 3, "name": "Discover & Diagnose", "covered": True,
     "desc": "Uncover client needs and value opportunities", "metric": "critical needs"},
    {"n": 4, "name": "Develop Solution & Value Case", "covered": False,
     "desc": "Design a tailored solution with clear business value", "metric": ""},
    {"n": 5, "name": "Propose & Win", "covered": False,
     "desc": "Make the case, differentiate and secure the deal", "metric": ""},
    {"n": 6, "name": "Mobilize & Onboard", "covered": False,
     "desc": "Set the project up for success", "metric": ""},
    {"n": 7, "name": "Deliver & Create Value", "covered": False,
     "desc": "Execute, drive outcomes and exceed expectations", "metric": ""},
    {"n": 8, "name": "Grow & Deepen", "covered": False,
     "desc": "Turn success into a long-term partnership", "metric": ""},
]


def _signals(c):
    """Pre-attached strategic signals, or compute them from the report company (no re-scrape)."""
    s = c.get("strategic_signals")
    return s if s is not None else strategic.partnership_signals(c, strategic.evidence_from_report_company(c))


def _grav(c, agg):
    g = c.get("tool_gravitation")
    return g if g is not None else strategic.tool_gravitation(agg, strategic.evidence_from_report_company(c))


def _dept(name):
    return DEPT_RELABEL.get(name, name)


def _trim(r):
    out = {k: r.get(k) for k in ROLE_KEYS}
    out["business_domain"] = _dept(out.get("business_domain") or "")
    return out


def _intensity(heatmap):
    """Open roles touching each technology capability (raw counts — clearer than a 0-100 index)."""
    if not heatmap:
        return []
    rows = [[HEAT_LABELS.get(k, k), v] for k, v in heatmap.items() if v]
    return sorted(rows, key=lambda x: -x[1])[:6]


def _company_block(report, roles_by_company):
    blocks = []
    for c in report["companies"]:
        agg = c.get("jobs_agg") or {}
        roles = roles_by_company.get(c["slug"], [])
        sigs = _signals(c)
        # De-dupe across fields, then remove any field sentence already shown as a strategic signal
        # (so the 'signals' card and 'Market intelligence' never repeat the same line).
        flds = strategic.strip_signals_from_fields(
            strategic.dedupe_field_summaries(c.get("fields", {}), c), sigs, c)
        depts = [[_dept(d), n] for d, n in agg.get("by_business_domain", [])]
        hot = depts[0] if depts else None
        hotspot = None
        if hot:
            hot_roles = [r for r in roles if _dept(r.get("business_domain", "")) == hot[0]]
            sk = Counter()
            for r in hot_roles:
                sk.update(r.get("skills", []))
            mgrs = Counter(r["likely_manager"]["name"] for r in hot_roles
                           if r.get("likely_manager") and r["likely_manager"].get("name") not in (None, "", "Unknown"))
            hotspot = {"field": hot[0], "roles": hot[1],
                       "critical": sum(1 for r in hot_roles if r.get("critical")),
                       "skills": [k for k, _ in sk.most_common(6)],
                       "leader": mgrs.most_common(1)[0][0] if mgrs else ""}
        blocks.append({
            "slug": c["slug"], "name": c["name"], "sector": c["sector"], "listing": c["listing"],
            "region": c.get("region", ""),
            "provenance": _provenance(c, roles),
            "strategic_signals": sigs,
            "tool_gravitation": _grav(c, agg),
            "direction": c["direction"], "total": agg.get("total_open_roles", 0),
            "narrative": c.get("key_development", ""), "why": c.get("why_hiring", ""),
            "strategy": c.get("strategy", ""), "strategy_sources": c.get("strategy_sources", []),
            "critical": c.get("critical_count", 0), "employment": c.get("employment", []),
            "takeaways": c.get("takeaways", []),
            "investments": c.get("investments", ""), "stakeholders": c.get("stakeholders", ""),
            "actions": c.get("actions", []), "filings": c.get("filings_count", 0),
            "people": c.get("stakeholder_people", []),
            "recruiters": [p for p in c.get("stakeholder_people", [])
                           if "talent" in (p.get("title", "") + p.get("department", "")).lower()
                           or "recruit" in p.get("title", "").lower()],
            "departments": depts, "skills": agg.get("top_tech", [])[:12],
            "seniority": agg.get("by_seniority", []), "locations": agg.get("top_locations", [])[:8],
            "opportunities": c.get("opportunities", []),
            "hotspot": hotspot, "fields": flds,
            "intensity": _intensity(agg.get("heatmap", {})),
        })
    return blocks


def _journey(companies, report):
    counts = {1: len(report.get("opportunity_radar", [])),
              2: sum(len(c.get("people", [])) for c in companies),
              3: sum(c.get("critical", 0) for c in companies)}
    return [{**s, "count": counts.get(s["n"], 0) if s["covered"] else None} for s in JOURNEY]


def build(report, roles_by_company, path):
    companies = _company_block(report, roles_by_company)
    m = re.search(r"last (\d+) days", report.get("month_label", ""))
    # has_data = has live INDIA HIRING (a wired career portal), not merely "present in the report".
    hiring = {c["slug"] for c in companies if c.get("total", 0) > 0}
    signalled = {c["slug"] for c in companies if c.get("strategic_signals")}
    cov_by_slug = {c["slug"]: (c.get("provenance") or {}) for c in companies}
    accounts = [{"name": a["name"], "slug": a["slug"], "sector": a["sector"],
                 "region": a.get("region", ""), "has_data": a["slug"] in hiring,
                 "has_signals": a["slug"] in signalled,
                 "coverage_status": cov_by_slug.get(a["slug"], {}).get("coverage_status", "signals_only"),
                 "coverage_label": cov_by_slug.get(a["slug"], {}).get("coverage_label", "Signals only")}
                for a in getattr(settings, "ACCOUNTS", [])]
    data = {
        "generated": report["generated"],
        "month_label": report["month_label"],
        "window": m.group(1) if m else str(settings.JOB_RECENCY_DAYS),
        "names": {c["slug"]: c["name"] for c in companies},
        "accounts": accounts,
        "regions": getattr(settings, "REGIONS", {}),
        "companies": companies,
        "tech_radar": report.get("tech_radar", []),
        "opportunity_radar": report.get("opportunity_radar", []),
        "field_labels": {k: v["label"] for k, v in settings.FIELDS.items()},
        "roles_by_company": {s: [_trim(r) for r in rs] for s, rs in roles_by_company.items()},
        "sales_journey": _journey(companies, report),
    }
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(p)
