"""Ingest Indeed MCP job-search results into the discovery-dump format (titles-only Tier-C hiring).

Indeed results are fetched by the assistant via the Indeed MCP (the headless pipeline cannot call it)
and saved as raw text per account under discovery/_indeed_raw/<slug>.txt. This parses those blocks into
the same role schema discover.py writes, tagged extraction_method="indeed" + description_captured False,
so india_run picks them up as an honest titles-only fallback (no JD depth, excluded from skill math).

Usage:  python -m delivery.indeed_ingest            # ingest every *.txt in discovery/_indeed_raw/
"""
import json
import os
import re
from datetime import datetime, date

import settings
from analysis import classify
from timeframe import now_stamp

# Keep only Indeed roles posted within the last N days (user wants "last month only"). Indeed exposes a
# "Posted on" date per role, so we filter on it from today. Undated rows are dropped under this rule.
INDEED_RECENCY_DAYS = int(os.environ.get("INDEED_RECENCY_DAYS", "31"))

RAW = settings.ROOT / "discovery" / "_indeed_raw"
OUT = settings.ROOT / "discovery"

FIELD = lambda name, block: (re.search(rf"\*\*{name}:\*\*\s*(.+)", block) or [None, ""])[1].strip() \
    if re.search(rf"\*\*{name}:\*\*\s*(.+)", block) else ""


def _iso(datestr):
    for fmt in ("%B %d, %Y", "%b %d, %Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(datestr.strip(), fmt).date().isoformat()
        except ValueError:
            continue
    return ""


def _name_tokens(company_name, slug):
    """Significant tokens an Indeed 'Company' field must share to count as this account (avoids a
    keyword search pulling in unrelated firms)."""
    acct = next((a for a in settings.ACCOUNTS if a["slug"] == slug), {})
    names = [company_name] + (acct.get("aliases", []) if isinstance(acct, dict) else [])
    toks = set()
    for n in names:
        for t in re.findall(r"[a-z0-9]+", n.lower()):
            if t not in {"the", "and", "of", "inc", "ltd", "plc", "co", "company", "international",
                         "technology", "technologies", "associates", "global", "group"} and len(t) > 2:
                toks.add(t)
    return toks


def parse(text, company_name, slug):
    roles = []
    tokens = _name_tokens(company_name, slug)
    # Each job block starts at "**Job Title:**"
    blocks = re.split(r"(?=\*\*Job Title:\*\*)", text)
    for b in blocks:
        title = FIELD("Job Title", b)
        if not title:
            continue
        emp = FIELD("Company", b).lower()
        if tokens and emp and not any(t in emp for t in tokens):
            continue  # Indeed returned a different company for this keyword — drop it
        loc = FIELD("Location", b)
        url = FIELD("View Job URL", b)
        jtype = FIELD("Job Type", b)
        posted = _iso(FIELD("Posted on", b))
        # last-month filter: keep only roles posted within INDEED_RECENCY_DAYS of today
        if INDEED_RECENCY_DAYS and posted:
            try:
                if (date.today() - date.fromisoformat(posted)).days > INDEED_RECENCY_DAYS:
                    continue
            except ValueError:
                pass
        elif INDEED_RECENCY_DAYS and not posted:
            continue  # no date → can't confirm it's last-month → drop
        if not (classify.is_india(loc) or "india" in loc.lower()):
            # Indeed location was given as an India city/state in the query, but double-check.
            if not loc:
                continue
        roles.append({
            "company": company_name, "slug": slug, "title": title,
            "source_url": url, "location": loc, "country": "India",
            "posted_date": posted, "valid_through": "",
            "employment_type_raw": jtype, "job_id": FIELD("Job Id", b),
            "salary_value": "", "department_raw": "",
            "business_domain": "", "seniority": "", "experience_years": None,
            "skills": [], "team": "", "hiring_manager": "",
            "extraction_method": "indeed",          # <- Tier-C provenance stamp
            "is_india": True, "description_len": 0, "jsonld_keys": [], "_raw": {},
        })
    # de-dup by (title, location)
    seen, uniq = set(), []
    for r in roles:
        k = (r["title"].lower(), r["location"].lower())
        if k not in seen:
            seen.add(k); uniq.append(r)
    return uniq


def main():
    if not RAW.exists():
        print("no raw dir", RAW); return
    done = []
    for f in sorted(RAW.glob("*.txt")):
        slug = f.stem
        acct = next((a for a in settings.ACCOUNTS if a["slug"] == slug), None)
        name = acct["name"] if acct else slug
        roles = parse(f.read_text(encoding="utf-8"), name, slug)
        (OUT / f"{slug}_roles_raw.json").write_text(
            json.dumps({"company": name, "generated": now_stamp(), "count": len(roles),
                        "meta": {"source": "indeed"}, "roles": roles}, indent=2, ensure_ascii=False),
            encoding="utf-8")
        done.append((slug, len(roles)))
        print(f"  {slug:16} {len(roles)} India roles (Indeed)")
    print(f"Ingested {len(done)} accounts from Indeed.")


if __name__ == "__main__":
    main()
