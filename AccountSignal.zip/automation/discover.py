"""India-only, all-departments DISCOVERY extractor (Phase 0).

Pulls every India job posting for the configured clients, keeping every raw field each portal
exposes, and writes a coverage report so we can see what the public data actually supports before
building the dashboard. Non-destructive: writes only under automation/discovery/, never output/.

Usage:
    python discover.py                      # all clients
    python discover.py --companies cargill  # one or more slugs
"""
import argparse
import json
import os
import re
import time
from collections import Counter

import requests

import settings
import sources.jobs as jobs
from sources import browser
from analysis import classify
from timeframe import now_stamp, parse_date, Month

OUT = settings.ROOT / "discovery"

# India detection on a career-portal URL slug (Radancy puts the city in the path).
INDIA_SLUGS = ["bengaluru", "bangalore", "mumbai", "chennai", "hyderabad", "pune", "gurgaon",
               "gurugram", "noida", "kolkata", "delhi", "ahmedabad", "kochi", "cochin",
               "coimbatore", "nagpur", "chandigarh", "jaipur", "thiruvananthapuram",
               "trivandrum", "mysore", "mysuru", "visakhapatnam", "indore", "nashik",
               "navi mumbai", "thane", "/india/", "-india-", "/in/"]

# Fields we measure for fill-rate (derived + raw-presence).
COVERAGE_FIELDS = ["title", "location", "country", "posted_date", "employment_type_raw", "job_id",
                   "salary_value", "department_raw", "business_domain", "seniority",
                   "experience_years", "skills", "team", "hiring_manager"]


def _india_url(u):
    return any(h in u.lower() for h in INDIA_SLUGS)


def _ident(p):
    ident = p.get("identifier")
    if isinstance(ident, dict):
        return str(ident.get("value", "") or "")
    return str(ident or "")


def _salary_value(p):
    """Only report a salary when an actual amount is present. Several portals (e.g. Takeda) send a
    baseSalary block with a currency but an EMPTY value — that is not real salary data."""
    sal = p.get("baseSalary")
    if isinstance(sal, dict):
        val = sal.get("value")
        if isinstance(val, dict):
            amount = val.get("value") or val.get("minValue") or val.get("maxValue") or ""
            if str(amount).strip():
                return f"{sal.get('currency','')} {amount}".strip()
        elif val not in (None, "", {}):
            return str(val)
    return ""


def _dept_raw(p):
    for key in ("occupationalCategory", "industry"):
        v = p.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    org = p.get("hiringOrganization")
    if isinstance(org, dict) and org.get("department"):
        dep = org["department"]
        return dep.get("name", "") if isinstance(dep, dict) else str(dep)
    return ""


def _flatten_jsonld(company, p, url):
    loc, country = jobs._location_from(p)
    desc = re.sub("<[^>]+>", " ", p.get("description", "") or "")
    et = p.get("employmentType", "")
    if isinstance(et, list):
        et = et[0] if et else ""
    title = (p.get("title") or "").strip()
    exp = classify.experience_years(desc)
    skills = classify.detect_tech(f"{title} {desc}")
    return {
        "company": company["name"], "slug": company["slug"],
        "title": title, "source_url": p.get("url") or url,
        "location": loc, "country": country,
        "posted_date": p.get("datePosted", ""), "valid_through": p.get("validThrough", ""),
        "employment_type_raw": et if isinstance(et, str) else "",
        "job_id": _ident(p), "salary_value": _salary_value(p),
        "department_raw": _dept_raw(p),
        "business_domain": classify.business_domain(title, desc),
        "seniority": classify.seniority(title, exp), "experience_years": exp,
        "skills": skills, "team": classify.extract_team(desc),
        "hiring_manager": classify.extract_manager(desc),
        "is_india": classify.is_india(loc) or classify.is_india(country),
        "description_len": len(desc), "jsonld_keys": sorted(p.keys()),
        "_raw": p,
    }


def _flatten_workday(company, info, listing):
    title = (info.get("title") or listing.get("title", "")).strip()
    loc = (info.get("location") or listing.get("locationsText", "")).strip()
    country = info.get("country", {}).get("descriptor", "") if isinstance(info.get("country"), dict) else ""
    desc = re.sub("<[^>]+>", " ", info.get("jobDescription", "") or "")
    exp = classify.experience_years(desc)
    skills = classify.detect_tech(f"{title} {desc}")
    return {
        "company": company["name"], "slug": company["slug"],
        "title": title, "source_url": info.get("externalUrl", "") or listing.get("externalPath", ""),
        "location": loc, "country": country,
        "posted_date": info.get("startDate", ""), "valid_through": info.get("endDate", ""),
        "employment_type_raw": info.get("timeType", "") or "",
        "job_id": info.get("jobReqId", "") or "", "salary_value": "",
        "department_raw": info.get("jobFamily", "") or info.get("supervisoryOrganization", "") or "",
        "business_domain": classify.business_domain(title, desc),
        "seniority": classify.seniority(title, exp), "experience_years": exp,
        "skills": skills, "team": classify.extract_team(desc),
        "hiring_manager": classify.extract_manager(desc),
        "is_india": classify.is_india(loc) or classify.is_india(country),
        "description_len": len(desc), "jsonld_keys": sorted(info.keys()),
        "_raw": info,
    }


# ---------- per-portal India collectors (all departments) ----------
def _collect_radancy(company, cfg, session, stats):
    urls = jobs._sitemap_jobs(cfg["domain"], session, stats)
    india = [u for u in urls if _india_url(u)]
    stats["urls"] = len(india)
    roles = []
    for u, r in jobs.fetch_pages(session, india, stats):
        p = jobs._jsonld_posting(r.text) if r is not None else None
        if not p:
            continue
        stats["fetched"] += 1
        roles.append(_flatten_jsonld(company, p, u))
    return roles, {"sitemap_total": len(urls), "india_urls": len(india)}


def _collect_workday(company, cfg, session, stats):
    # Workday tenants live on different pods (wd1/wd3/wd5/wd103...); take it from config, default wd3.
    pod = cfg.get("pod", "wd3")
    base = f"https://{cfg['tenant']}.{pod}.myworkdayjobs.com/wday/cxs/{cfg['tenant']}/{cfg['site']}"

    def post(off):
        r = jobs._request(session, base + "/jobs", stats, method="POST",
                          json_body={"appliedFacets": {}, "limit": 20, "offset": off, "searchText": ""})
        return r.json() if r is not None else None

    first = post(0)
    if first is None:
        return [], {"board_total": 0, "india_listings": 0}
    total = first.get("total", 0)
    postings = list(first.get("jobPostings", []))
    off = len(postings)
    while off < total:
        page = post(off)
        if page is None:
            break
        batch = page.get("jobPostings", [])
        if not batch:
            break
        postings.extend(batch); off += len(batch); time.sleep(0.15)
    # Pre-filter to India from the listing text, then fetch detail only for those.
    india_listings = [p for p in postings if classify.is_india(p.get("locationsText", ""))]
    stats["urls"] = len(india_listings)
    detail_urls = [base + p.get("externalPath", "") for p in india_listings]
    roles = []
    for (u, r), p in zip(jobs.fetch_pages(session, detail_urls, stats), india_listings):
        try:
            info = r.json().get("jobPostingInfo", {}) if r is not None else {}
        except ValueError:
            info = {}
        if r is not None:
            stats["fetched"] += 1
        roles.append(_flatten_workday(company, info, p))
    return roles, {"board_total": total, "india_listings": len(india_listings)}


def _collect_avature(company, cfg, session, stats):
    base, path = cfg["base"], cfg["path"]
    search = cfg.get("search", "SearchJobs")
    sep = "&" if "?" in search else "?"
    order, seen = [], set()
    off = 0
    while off < jobs.AVATURE_CAP:
        r = jobs._request(session, f"{base}{path}/{search}{sep}jobOffset={off}", stats)
        if r is None:
            break
        new = [u for u in dict.fromkeys(re.findall(r'(/en_GB/careers/JobDetail/[^"\'\s]+)', r.text)) if u not in seen]
        if not new:
            break
        for u in new:
            seen.add(u); order.append(u)
        off += 10
        time.sleep(0.2)
    stats["urls"] = len(order)
    full_urls = [jobs.urljoin(base, link) for link in order]
    roles = []
    for u, r in jobs.fetch_pages(session, full_urls, stats):
        p = jobs._jsonld_posting(r.text) if r is not None else None
        if not p:
            continue
        stats["fetched"] += 1
        roles.append(_flatten_jsonld(company, p, u))  # already India-facet scoped
    return roles, {"india_listings": len(order)}


_EF_SEARCH_JS = """async ({host,domain,start}) => {
   const u=`https://${host}/api/pcsx/search?domain=${domain}&query=&location=India&start=${start}&sort_by=relevance&triggerGoButton=true`;
   const r=await fetch(u,{headers:{'accept':'application/json'}});
   return {status:r.status, text: await r.text()};
}"""


def _flatten_eightfold(company, pos):
    import datetime
    locs = pos.get("locations") or pos.get("standardizedLocations") or []
    loc = locs[0] if locs else (pos.get("location") or "")
    ts = pos.get("postedTs") or pos.get("creationTs")
    posted = ""
    if ts:
        try:
            posted = datetime.datetime.utcfromtimestamp(int(ts) / (1000 if int(ts) > 1e11 else 1)).date().isoformat()
        except (ValueError, OSError, OverflowError):
            posted = ""
    title = (pos.get("name") or pos.get("title") or "").strip()
    return {
        "company": company["name"], "slug": company["slug"], "title": title,
        "source_url": pos.get("positionUrl") or pos.get("canonicalPositionUrl") or "",
        "location": loc, "country": "India",
        "posted_date": posted, "valid_through": "",
        "employment_type_raw": pos.get("workLocationOption") or "",
        "job_id": str(pos.get("displayJobId") or pos.get("atsJobId") or pos.get("id") or ""),
        "salary_value": "", "department_raw": pos.get("department") or "",
        "business_domain": "", "seniority": "", "experience_years": None,
        "skills": [], "team": pos.get("department") or "", "hiring_manager": "",
        "extraction_method": "eightfold",
        "is_india": classify.is_india(loc) or "india" in (loc or "").lower(),
        "description_len": 0, "jsonld_keys": [], "_raw": {},
    }


def _collect_eightfold(company, cfg, session, stats):
    """Eightfold career sites (Qualcomm, Applied Materials, BCG...). The site is a JS SPA, so we drive a
    real headless browser (Playwright) to establish the session, then replay its PCSX search API with the
    India location filter, paginating until all India positions are collected. Titles + location +
    department (no JD) — honest titles-level depth from the real site, not a third party."""
    import json as _json
    host, domain = cfg["host"], cfg["domain"]
    cap = cfg.get("cap", 2000)
    roles, total = [], None
    b = browser.new_browser()
    try:
        _, pg = browser.page(b, viewport={"width": 1366, "height": 900})
        pg.goto(f"https://{host}/careers?location=India", wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(5000)
        start = 0
        while start < cap:
            res = pg.evaluate(_EF_SEARCH_JS, {"host": host, "domain": domain, "start": start})
            if res["status"] != 200:
                break
            data = _json.loads(res["text"]).get("data", {})
            pos = data.get("positions") or []
            total = data.get("count")
            if not pos:
                break
            for p0 in pos:
                roles.append(_flatten_eightfold(company, p0))
            start += len(pos)
            stats["fetched"] += 1
            if total and start >= total:
                break
    finally:
        try:
            b.close()
        except Exception:
            pass
    roles = [r for r in roles if r["is_india"]]
    stats["urls"] = len(roles)
    return roles, {"count": total, "india_roles": len(roles)}


_SF_EXTRACT = """() => {
  const rows=[]; const seen=new Set();
  document.querySelectorAll("a[href*='/job/']").forEach(a=>{
    const href=a.href.split('?')[0]; if(seen.has(href)) return; seen.add(href);
    const title=(a.textContent||'').trim().replace(/\\s+/g,' ');
    if(!title || title.length<3) return;
    // find a location near the anchor (SF CSB puts it in a sibling .jobLocation / span)
    let loc=''; let row=a.closest('li,tr,div');
    for(let i=0;i<4 && row && !loc;i++){
      const el=row.querySelector("[class*='ocation'], .jobLocation, span.job-location");
      if(el) loc=(el.textContent||'').trim().replace(/\\s+/g,' ');
      row=row.parentElement;
    }
    rows.push({href, title: title.slice(0,120), location: loc.slice(0,80)});
  });
  return rows;
}"""


def _collect_successfactors(company, cfg, session, stats):
    """SuccessFactors Career-Site-Builder sites (Colgate, Alstom, HCL, Novo...). JS-rendered, so drive a
    headless browser (Playwright), open the India-filtered search, extract each job tile (title +
    location + url), and page through with startrow. Titles+location level (SF job pages carry no JSON-LD)."""
    base = cfg["base"]
    step = cfg.get("step", 25)
    cap = cfg.get("cap", 600)
    roles, seen = [], set()
    b = browser.new_browser()
    try:
        _, pg = browser.page(b, viewport={"width": 1366, "height": 1200})
        start = 0
        while start < cap:
            url = f"{base}/search/?q=&locationsearch=India&startrow={start}"
            try:
                pg.goto(url, wait_until="domcontentloaded", timeout=45000)
                pg.wait_for_timeout(5000)  # SF CSB renders the job list via JS; give it time on a remote browser
                pg.mouse.wheel(0, 4000)
                pg.wait_for_timeout(1500)
            except Exception:
                break
            tiles = pg.evaluate(_SF_EXTRACT)
            new = [t for t in tiles if t["href"] not in seen]
            if not new:
                break
            for t in new:
                seen.add(t["href"])
                loc = t["location"] or "India"
                roles.append({
                    "company": company["name"], "slug": company["slug"], "title": t["title"],
                    "source_url": t["href"], "location": loc, "country": "India",
                    "posted_date": "", "valid_through": "", "employment_type_raw": "",
                    "job_id": "", "salary_value": "", "department_raw": "",
                    "business_domain": "", "seniority": "", "experience_years": None,
                    "skills": [], "team": "", "hiring_manager": "",
                    "extraction_method": "successfactors",
                    "is_india": classify.is_india(loc) or "india" in loc.lower(),
                    "description_len": 0, "jsonld_keys": [], "_raw": {},
                })
            stats["fetched"] += 1
            start += step
    finally:
        try:
            b.close()
        except Exception:
            pass
    roles = [r for r in roles if r["is_india"]]
    stats["urls"] = len(roles)
    return roles, {"india_roles": len(roles)}


def _collect_phenom(company, cfg, session, stats):
    """Phenom career sites (Adobe, Lowe's, Thermo Fisher, P&G, GSK, DaVita, PMI, BCG).

    The job-SEARCH page is a JavaScript shell that blocks plain scraping, but every INDIVIDUAL job
    page is server-rendered with schema.org JobPosting JSON-LD (for Google indexing) and is reachable
    by plain HTTP via the sitemap — the same JSON-LD pattern as Radancy. We pull all job URLs from the
    sitemap, read each posting, and keep the India ones (resolved from the posting's address/country)."""
    # Prefer the India-locale sitemap (/in/en/sitemap.xml) when present: its job URLs are already
    # India-scoped, so we fetch only those (fast + complete) instead of crawling the whole global book.
    india_urls = jobs.locale_sitemap_jobs(cfg["domain"], session, stats, prefix=cfg.get("india_prefix", "/in/en/"))
    prefiltered = bool(india_urls)
    if prefiltered:
        urls = india_urls
    else:
        # No India locale — crawl the global sitemap and filter by each posting's resolved location.
        # Fetch the whole book by default (Phenom URLs carry no location hint to pre-filter on);
        # PHENOM_CAP bounds pathologically huge books. Parallel fetching keeps it to a few minutes.
        urls = jobs._sitemap_jobs(cfg["domain"], session, stats)
    cap = cfg.get("cap", int(os.environ.get("PHENOM_CAP", "6000")))
    stats["urls"] = len(urls)
    roles = []
    for u, r in jobs.fetch_pages(session, urls[:cap], stats):
        p = jobs._jsonld_posting(r.text) if r is not None else None
        if not p:
            continue
        stats["fetched"] += 1
        role = _flatten_jsonld(company, p, u)
        if prefiltered or role["is_india"]:   # locale sitemap is already India; else filter by location
            roles.append(role)
    return roles, {"sitemap_total": len(urls), "india_roles": len(roles), "india_locale": prefiltered}


_GENERIC_EXTRACT = r"""() => {
  const out=[], seen=new Set();
  const isJob = h => /(\/job[\/s]|\/jobs?\/|\/positions?\/|\/vacanc|\/opening|\/requisition|\/role\/|\/careers?\/[0-9A-Za-z\-]{4,})/i.test(h);
  document.querySelectorAll('a[href]').forEach(a=>{
    let h=(a.href||'').split('?')[0]; if(!h||seen.has(h)) return;
    const title=(a.textContent||'').trim().replace(/\s+/g,' ');
    if(!isJob(h) || title.length<4 || title.length>140) return;
    seen.add(h);
    let loc=''; let row=a.closest('li,tr,article,div');
    for(let i=0;i<4 && row && !loc;i++){
      const el=row.querySelector("[class*='ocation'],[class*='ocality'],[data-location],[class*='city']");
      if(el) loc=(el.textContent||'').trim().replace(/\s+/g,' ').slice(0,80);
      row=row.parentElement;
    }
    out.push({href:h, title:title.slice(0,140), location:loc});
  });
  return out;
}"""


def _collect_browser(company, cfg, session, stats):
    """Generic, best-effort India scraper for CUSTOM / virtualized career sites that have no standard
    ATS adapter (Airbnb, AB InBev, Colt, Kellanova, Godrej ...). Drives the Bright Data remote browser,
    opens the (India-filtered) careers URL, scrolls to load lazy content, and harvests job tiles
    (title + location + url) generically — titles-only depth, like Indeed/SuccessFactors. Returns [] when
    the site exposes nothing recognisable (kept honestly blank, never faked)."""
    url = cfg.get("search_url") or cfg.get("url")
    scrolls = cfg.get("scrolls", 6)
    prefiltered = cfg.get("india_prefiltered", False)
    roles, seen = [], set()
    b = browser.new_browser()
    tiles = []
    try:
        _, pg = browser.page(b)
        pg.goto(url, wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(4000)
        for _ in range(scrolls):
            pg.mouse.wheel(0, 20000)
            pg.wait_for_timeout(1200)
        tiles = pg.evaluate(_GENERIC_EXTRACT)
        stats["fetched"] += 1
    except Exception:
        stats["fail"] += 1
    finally:
        try:
            b.close()
        except Exception:
            pass
    for t in tiles:
        h = t["href"]
        if h in seen:
            continue
        seen.add(h)
        loc = t.get("location") or ""
        india = prefiltered or classify.is_india(loc) or _india_url(h) or "india" in loc.lower()
        if not india:
            continue
        roles.append({
            "company": company["name"], "slug": company["slug"], "title": t["title"],
            "source_url": h, "location": loc or "India", "country": "India",
            "posted_date": "", "valid_through": "", "employment_type_raw": "",
            "job_id": "", "salary_value": "", "department_raw": "",
            "business_domain": "", "seniority": "", "experience_years": None,
            "skills": [], "team": "", "hiring_manager": "",
            "extraction_method": "browser",
            "is_india": classify.is_india(loc) or prefiltered or "india" in loc.lower(),
            "description_len": 0, "jsonld_keys": [], "_raw": {},
        })
    roles = [r for r in roles if r["is_india"]]
    stats["urls"] = len(roles)
    return roles, {"india_roles": len(roles), "url": url}


def _collect_nike(company, cfg, session, stats):
    """Nike careers (careers.nike.com). The site is a custom SPA whose /api/get-jobs JSON endpoint is
    Akamai-protected (403 to any replayed request), so we load the India-filtered page in the Bright Data
    browser and CAPTURE the page's own get-jobs responses while scrolling, until we have all `totalJob`
    roles. Full job descriptions are included, so this is full-JD depth."""
    url = cfg.get("url", "https://careers.nike.com/jobs?location_name=India&location_type=4")
    seen, total = {}, [None]
    b = browser.new_browser()
    try:
        _, pg = browser.page(b)

        def on_resp(r):
            if "/api/get-jobs" in r.url:
                try:
                    d = r.json()
                    if d.get("totalJob") is not None:
                        total[0] = d.get("totalJob")
                    for j in d.get("jobs", []):
                        key = j.get("requisitionID") or j.get("uniqueID")
                        if key:
                            seen[key] = j
                except Exception:
                    pass

        pg.on("response", on_resp)
        pg.goto(url, wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(5000)
        # Nike paginates via a "next / more" control (not infinite scroll), so scroll AND click it each
        # pass, capturing every get-jobs response, until we've collected all `totalJob` roles.
        stale = 0
        for _ in range(cfg.get("pages", 30)):
            before = len(seen)
            pg.mouse.wheel(0, 12000)
            pg.wait_for_timeout(900)
            try:
                pg.evaluate("""()=>{const b=[...document.querySelectorAll('a,button')]
                    .find(e=>/next|more|load/i.test((e.textContent||'')+(e.getAttribute('aria-label')||'')));
                    if(b) b.click();}""")
            except Exception:
                pass
            pg.wait_for_timeout(1500)
            if total[0] and len(seen) >= total[0]:
                break
            stale = stale + 1 if len(seen) == before else 0
            if stale >= 4:  # no new roles after several tries — stop
                break
        stats["fetched"] = len(seen)
    finally:
        try:
            b.close()
        except Exception:
            pass
    roles = []
    for j in seen.values():
        desc = re.sub("<[^>]+>", " ", j.get("description", "") or "")
        locs = j.get("locations") or []
        loc = (locs[0].get("locationName") if locs and isinstance(locs[0], dict) else "") or ""
        if not loc:
            toks = j.get("addressFormatTokens") or []
            loc = (toks[0].get("city") if toks and isinstance(toks[0], dict) else "") or "India"
        et = j.get("employmentType") or []
        title = (j.get("title") or "").strip()
        exp = classify.experience_years(desc)
        roles.append({
            "company": company["name"], "slug": company["slug"], "title": title,
            "source_url": j.get("applyURL") or f"https://careers.nike.com/jobs/{j.get('originalURL', '')}",
            "location": loc, "country": "India", "posted_date": "", "valid_through": "",
            "employment_type_raw": et[0] if isinstance(et, list) and et else (et if isinstance(et, str) else ""),
            "job_id": j.get("requisitionID") or "", "salary_value": "", "department_raw": "",
            "business_domain": classify.business_domain(title, desc),
            "seniority": classify.seniority(title, exp), "experience_years": exp,
            "skills": classify.detect_tech(f"{title} {desc}"),
            "team": classify.extract_team(desc), "hiring_manager": classify.extract_manager(desc),
            "extraction_method": "nike",
            "is_india": classify.is_india(loc) or "india" in loc.lower() or True,  # page is India-filtered
            "description_len": len(desc), "jsonld_keys": [], "_raw": {"description": j.get("description", "")},
        })
    stats["urls"] = len(roles)
    return roles, {"total": total[0], "india_roles": len(roles)}


_TITLE_KEYS = {"title", "jobtitle", "job_title", "name", "ml_job_title", "postingtitle", "positiontitle"}
_URL_KEYS = {"clickuri", "applyurl", "joburl", "url", "canonicalurl", "positionurl", "originalurl",
             "uri", "apply_url", "printableuri", "jobdetailurl", "detailurl", "seo_url"}
_LOC_KEYS = {"location", "city", "locationname", "primarylocation", "ml_city", "ml_state", "country",
             "region", "joblocation", "city_state", "locations", "cityname"}
_DESC_KEYS = {"description", "descriptionteaser", "jobdescription", "excerpt", "summary", "ml_description"}
_ID_KEYS = {"jobid", "jobseqno", "id", "uniqueid", "requisitionid", "reqid", "jobnumber", "ats_job_id"}
_JOBISH = _URL_KEYS | _LOC_KEYS | _DESC_KEYS | _ID_KEYS


def _pick(d, keys):
    for k, v in d.items():
        if k.lower() in keys and v not in (None, "", [], {}):
            return v
    return ""


def _as_text(v):
    if isinstance(v, str):
        return v
    if isinstance(v, list) and v:
        return _as_text(v[0])
    if isinstance(v, dict):
        for k in ("name", "locationName", "city", "label", "value", "descriptor"):
            if v.get(k):
                return str(v[k])
    return str(v) if v not in (None, "", [], {}) else ""


def _find_job_arrays(obj, depth=0, out=None):
    """All arrays of >=2 dicts whose items look like job records (a title-ish key AND a url/loc/id/desc
    key — so nav/facet/config arrays, which have title+link only, are excluded)."""
    if out is None:
        out = []
    if depth > 8:
        return out
    if isinstance(obj, list):
        dd = [x for x in obj if isinstance(x, dict)]
        if len(dd) >= 2:
            keys = set().union(*[{k.lower() for k in d} for d in dd[:6]])
            if (keys & _TITLE_KEYS) and (keys & _JOBISH):
                out.append(dd)
        for x in obj[:3]:
            _find_job_arrays(x, depth + 1, out)
    elif isinstance(obj, dict):
        for v in obj.values():
            _find_job_arrays(v, depth + 1, out)
    return out


def _collect_apicapture(company, cfg, session, stats):
    """Generic India scraper for SPA career sites (Coveo / Phenom / Zwayam / custom): load the
    India-filtered URL in the Bright Data browser and CAPTURE the JSON API responses that carry the job
    list, paging by scroll+next-click until no new jobs appear. Platform-agnostic — it finds the jobs
    array heuristically and maps common title/location/url/description fields. Titles (+ any description)
    depth. The URL is already India-filtered, so results are treated as India."""
    url = cfg["url"]
    prefiltered = cfg.get("prefiltered", True)
    responses = []
    b = browser.new_browser()
    try:
        _, pg = browser.page(b)

        def on_resp(r):
            ct = (r.headers or {}).get("content-type", "")
            if "json" not in ct.lower():
                return
            if any(s in r.url for s in ("analytics", "/collect", "gtm", "consent", "cookie")):
                return
            try:
                responses.append(r.json())
            except Exception:
                pass

        pg.on("response", on_resp)
        for attempt in range(2):  # Bright Data nav to heavy SPAs can be interrupted — one retry
            try:
                pg.goto(url, wait_until="domcontentloaded", timeout=45000)
                break
            except Exception:
                pg.wait_for_timeout(1500)
        pg.wait_for_timeout(4000)
        seen_count, stale = 0, 0
        for _ in range(cfg.get("pages", 6)):  # fast: most India books are a few pages
            pg.mouse.wheel(0, 12000)
            pg.wait_for_timeout(600)
            try:
                # Click only pagination BUTTONS (not <a>, which would navigate away and lose the SPA state)
                pg.evaluate("""()=>{const els=[...document.querySelectorAll("button,[role='button'],[class*='pagination'] *,[class*='next']")]
                    .filter(e=>/next|more|load|show more/i.test((e.textContent||'')+(e.getAttribute&&e.getAttribute('aria-label')||'')));
                    if(els[0]) els[0].click();}""")
            except Exception:
                pass
            pg.wait_for_timeout(900)
            cur = sum(len(a) for a in _find_job_arrays(responses))  # rough growth signal
            stale = stale + 1 if cur == seen_count else 0
            seen_count = cur
            if stale >= 2:  # no new jobs after 2 tries — stop fast
                break
    except Exception:
        stats["fail"] += 1
    finally:
        try:
            b.close()
        except Exception:
            pass

    # Merge the largest job arrays across all captured responses; dedupe by (title,url/id).
    best = {}
    for arr in _find_job_arrays(responses):
        for j in arr:
            title = _as_text(_pick(j, _TITLE_KEYS)).strip()
            if not title or len(title) < 3:
                continue
            u = _as_text(_pick(j, _URL_KEYS))
            jid = _as_text(_pick(j, _ID_KEYS))
            key = (title.lower(), (u or jid).lower())
            if key in best:
                continue
            loc = _as_text(_pick(j, _LOC_KEYS)) or ("India" if prefiltered else "")
            desc = re.sub("<[^>]+>", " ", _as_text(_pick(j, _DESC_KEYS)))
            best[key] = {"title": title, "location": loc, "url": u, "desc": desc, "jid": jid}
    stats["fetched"] = len(best)
    roles = []
    for j in best.values():
        india = prefiltered or classify.is_india(j["location"])
        if not india:
            continue
        title, desc = j["title"], j["desc"]
        exp = classify.experience_years(desc)
        roles.append({
            "company": company["name"], "slug": company["slug"], "title": title,
            "source_url": j["url"], "location": j["location"] or "India", "country": "India",
            "posted_date": "", "valid_through": "", "employment_type_raw": "",
            "job_id": j["jid"], "salary_value": "", "department_raw": "",
            "business_domain": classify.business_domain(title, desc),
            "seniority": classify.seniority(title, exp), "experience_years": exp,
            "skills": classify.detect_tech(f"{title} {desc}"),
            "team": classify.extract_team(desc), "hiring_manager": classify.extract_manager(desc),
            "extraction_method": "apicapture",
            "is_india": True, "description_len": len(desc), "jsonld_keys": [],
            "_raw": {"description": desc},
        })
    stats["urls"] = len(roles)
    return roles, {"india_roles": len(roles)}


def scrape_and_save(company, log=print):
    """Scrape one company's India hiring and write its discovery dump (the file india_run reads).
    Returns the India role count. Used by india_run.py's one-command pipeline.

    NON-DESTRUCTIVE: if the scrape got nothing AND hit request failures (blocked network / proxy, common
    on the office laptop), the existing dump is KEPT rather than overwritten with zeros — so a run on a
    restricted network never wipes good data. Pass FORCE_EMPTY=1 to override (write even empty results)."""
    roles, meta = collect(company, log=log)
    dump = OUT / f"{company['slug']}_roles_raw.json"
    # Never overwrite good data with an empty result — whether the cause is a blocked network, a site
    # that changed, or a generic-adapter miss. This protects both prior successful scrapes AND the
    # assisted Indeed dumps (which this scraper does not produce). Pass FORCE_EMPTY=1 to override.
    if not roles and os.environ.get("FORCE_EMPTY") != "1" and dump.exists():
        try:
            prev = json.loads(dump.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            prev = {}
        if prev.get("count", 0) > 0:
            log(f"  [keep] {company['name']}: scrape found 0 India roles — kept previous "
                f"{prev.get('count')} ({(prev.get('meta') or {}).get('source', 'scraped')})")
            return prev.get("count", 0)
    OUT.mkdir(parents=True, exist_ok=True)
    dump.write_text(
        json.dumps({"company": company["name"], "generated": now_stamp(), "count": len(roles),
                    "meta": {k: v for k, v in meta.items() if k != "stats"},
                    "stats": meta.get("stats"), "roles": roles}, indent=2, ensure_ascii=False),
        encoding="utf-8")
    return len(roles)


def collect(company, log=print):
    cfg = company.get("careers")
    session = jobs.make_session()
    stats = jobs._new_stats()
    kind = cfg["type"]
    if kind == "radancy":
        roles, extra = _collect_radancy(company, cfg, session, stats)
    elif kind == "workday":
        roles, extra = _collect_workday(company, cfg, session, stats)
    elif kind == "avature":
        roles, extra = _collect_avature(company, cfg, session, stats)
    elif kind == "phenom":
        roles, extra = _collect_phenom(company, cfg, session, stats)
    elif kind == "eightfold":
        roles, extra = _collect_eightfold(company, cfg, session, stats)
    elif kind == "successfactors":
        roles, extra = _collect_successfactors(company, cfg, session, stats)
    elif kind == "browser":
        roles, extra = _collect_browser(company, cfg, session, stats)
    elif kind == "nike":
        roles, extra = _collect_nike(company, cfg, session, stats)
    elif kind == "apicapture":
        roles, extra = _collect_apicapture(company, cfg, session, stats)
    else:
        return [], {}
    roles = [r for r in roles if r["is_india"]]  # safety net on resolved location
    log(f"  [discover] {company['name']}: {extra} | fetched {stats['fetched']}, "
        f"failed {stats['fail']} -> {len(roles)} India roles (all departments)")
    return roles, {"stats": stats, "extra": extra}


# ---------- coverage ----------
def _pct(n, d):
    return f"{(100.0 * n / d):.0f}%" if d else "-"


def _fill_table(roles):
    d = len(roles)
    lines = ["| field | filled | % |", "|---|---:|---:|"]
    for f in COVERAGE_FIELDS:
        n = sum(1 for r in roles if r.get(f) not in (None, "", [], 0))
        lines.append(f"| {f} | {n} | {_pct(n, d)} |")
    return "\n".join(lines)


def _counter_block(roles, key, top=12, listy=False):
    c = Counter()
    for r in roles:
        v = r.get(key)
        if listy:
            for x in (v or []):
                c[x] += 1
        elif v:
            c[v] += 1
    return "\n".join(f"- {k}: {n}" for k, n in c.most_common(top)) or "- (none)"


def _recency_block(roles):
    m = Month(settings.default_month())
    buckets = Counter()
    for r in roles:
        d = parse_date(r.get("posted_date", ""))
        if not d:
            buckets["no date"] += 1; continue
        age = (m.end - d).days
        if age < 0:
            buckets["after month"] += 1
        elif age <= 31:
            buckets["<=31d"] += 1
        elif age <= 90:
            buckets["32-90d"] += 1
        else:
            buckets[">90d"] += 1
    return "\n".join(f"- {k}: {n}" for k, n in buckets.most_common()) or "- (none)"


def _jsonld_keys_block(roles):
    c = Counter()
    for r in roles:
        for k in r.get("jsonld_keys", []):
            c[k] += 1
    d = len(roles)
    return "\n".join(f"- {k}: {_pct(n, d)}" for k, n in c.most_common())


def _company_section(name, roles):
    if not roles:
        return f"## {name}\n\n_No India roles collected._\n"
    return (f"## {name}  ({len(roles)} India roles)\n\n"
            f"**Field fill-rate**\n\n{_fill_table(roles)}\n\n"
            f"**Department (classified business_domain)**\n\n{_counter_block(roles, 'business_domain')}\n\n"
            f"**Top locations**\n\n{_counter_block(roles, 'location')}\n\n"
            f"**Seniority**\n\n{_counter_block(roles, 'seniority')}\n\n"
            f"**Employment type (raw)**\n\n{_counter_block(roles, 'employment_type_raw')}\n\n"
            f"**Posted-date recency (vs report month end)**\n\n{_recency_block(roles)}\n\n"
            f"**Top skills detected**\n\n{_counter_block(roles, 'skills', top=15, listy=True)}\n\n"
            f"**Raw JSON-LD fields present (% of roles)**\n\n{_jsonld_keys_block(roles)}\n")


def write_coverage(by_company, all_roles):
    OUT.mkdir(parents=True, exist_ok=True)
    parts = [f"# India discovery — coverage report\n\nGenerated {now_stamp()} · "
             f"{len(all_roles)} India roles across {len(by_company)} clients.\n\n"
             f"Fields counted as 'filled' when non-empty. 'department_raw'/'salary_value' come from the "
             f"portal's JSON-LD; most portals omit them, so department is derived from title+description.\n"]
    parts.append(_company_section("ALL CLIENTS", all_roles))
    for name, roles in by_company.items():
        parts.append(_company_section(name, roles))
    (OUT / "coverage.md").write_text("\n".join(parts), encoding="utf-8")
    return OUT / "coverage.md"


def main():
    ap = argparse.ArgumentParser(description="India-only discovery extractor (Phase 0).")
    ap.add_argument("--companies", default="", help="Comma-separated slugs (default: all).")
    args = ap.parse_args()
    only = {s.strip().lower() for s in args.companies.split(",") if s.strip()}
    companies = [c for c in settings.COMPANIES if not only or c["slug"] in only]

    OUT.mkdir(parents=True, exist_ok=True)
    by_company, all_roles = {}, []
    for company in companies:
        print(f"Collecting {company['name']} (India, all departments) ...")
        roles, meta = collect(company)
        by_company[company["name"]] = roles
        all_roles.extend(roles)
        (OUT / f"{company['slug']}_roles_raw.json").write_text(
            json.dumps({"company": company["name"], "generated": now_stamp(),
                        "count": len(roles), "meta": {k: v for k, v in meta.items() if k != "stats"},
                        "stats": meta.get("stats"), "roles": roles}, indent=2, ensure_ascii=False),
            encoding="utf-8")

    (OUT / "all_roles_raw.json").write_text(
        json.dumps({"generated": now_stamp(), "count": len(all_roles), "roles": all_roles},
                   indent=2, ensure_ascii=False), encoding="utf-8")
    cov = write_coverage(by_company, all_roles)
    print(f"\nDone. {len(all_roles)} India roles. Raw dumps + {cov.name} in {OUT}")


if __name__ == "__main__":
    main()
