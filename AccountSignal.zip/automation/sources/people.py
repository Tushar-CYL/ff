"""Stakeholder lookup via a licensed people-data provider (Explorium).

Given a client company, returns named India-based leaders/managers with their titles and departments —
the real stakeholders an account team would engage. This is COMPLIANT people data from a provider the
user holds a key for; it is NOT LinkedIn scraping. It returns people who hold these roles at the
company, not the owner of any specific job requisition (that is only ever known from the client).

Needs PEOPLEDATA_PROVIDER=explorium and PEOPLEDATA_API_KEY in the environment. Returns [] without a key.
"""
import requests

import settings

BASE = "https://api.explorium.ai/v2"
# Seniority levels worth engaging; Explorium job_level values.
LEADER_LEVELS = ["cxo", "vp", "director", "manager", "owner", "partner"]
# Prioritise the functions EY's tech-services alliance cares about when ordering results.
PRIORITY_DEPTS = ["it", "data", "engineering", "product", "strategy", "operations"]


def _headers():
    return {"api_key": settings.PEOPLEDATA_API_KEY, "Content-Type": "application/json"}


def enabled():
    return bool(settings.PEOPLEDATA_API_KEY) and settings.PEOPLEDATA_PROVIDER.lower() == "explorium"


def _match_business(company):
    body = {"businesses_to_match": [{"name": company["name"],
                                     "domain": company.get("domain", "")}]}
    try:
        r = requests.post(f"{BASE}/businesses/match", headers=_headers(), json=body, timeout=40)
        r.raise_for_status()
        matched = r.json().get("matched_businesses", [])
        return matched[0].get("business_id") if matched else None
    except (requests.RequestException, ValueError, KeyError, IndexError):
        return None


def stakeholders(company, country="in", limit=30, log=print):
    """Named India leaders/managers at the client. Best-effort; [] on any failure or no key."""
    if not enabled():
        return []
    bid = _match_business(company)
    if not bid:
        log(f"  [people] no business match for {company['name']}")
        return []
    body = {"mode": "full", "page_size": min(limit, 100),
            "filters": {"business_id": {"values": [bid]},
                        "job_level": {"values": LEADER_LEVELS},
                        "country_code": {"values": [country]}}}
    try:
        r = requests.post(f"{BASE}/prospects", headers=_headers(), json=body, timeout=60)
        if r.status_code == 403 and "credit" in r.text.lower():
            log(f"  [people] {company['name']}: Explorium OUT OF CREDITS — top up the account to fetch names.")
            return []
        r.raise_for_status()
        data = r.json().get("data", [])
    except (requests.RequestException, ValueError, KeyError):
        log(f"  [people] prospect fetch failed for {company['name']}")
        return []
    out = []
    for d in data:
        name = d.get("full_name") or " ".join(x for x in [d.get("first_name"), d.get("last_name")] if x)
        if not name:
            continue
        li = d.get("linkedin") or ""
        if li and not li.startswith("http"):
            li = "https://" + li.lstrip("/")
        out.append({
            "name": name.title(), "title": (d.get("job_title") or "").strip(),
            "department": d.get("job_department_main") or "", "level": d.get("job_level_main") or "",
            "city": (d.get("city") or "").title(), "linkedin": li,
        })

    def rank(p):
        dep = (p["department"] or "").lower()
        return PRIORITY_DEPTS.index(dep) if dep in PRIORITY_DEPTS else len(PRIORITY_DEPTS)
    out.sort(key=rank)
    log(f"  [people] {company['name']}: {len(out)} India leaders (Explorium)")
    return out
