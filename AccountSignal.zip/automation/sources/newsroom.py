"""Official company newsroom + investor-relations feeds.

First-party, dated announcements (partnerships, expansion, investments, financials, product launches,
leadership, vision) for the last-month insight window — authoritative sources that complement the global
news pool. Items are returned in the same shape the news classifier consumes ({title,url,published,
content}); `india_run` feeds them through `news._classify_pool` so they land in the 5 FIELDS, ranked
ahead of third-party coverage. Best-effort: returns [] when a company exposes no discoverable feed.

Per company we use, in order: an explicit `feeds`/`newsroom` in the company config, a small known-feed
registry, then auto-discovery of RSS/Atom `<link>`s on the company's newsroom/IR pages.
"""
import re
from urllib.parse import urljoin
from xml.etree import ElementTree as ET

import requests

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120 Safari/537.36",
      "Accept": "application/rss+xml, application/atom+xml, text/html, */*"}

# Confirmed direct feed URLs by slug (extend as verified). Most are auto-discovered instead.
FEEDS = {
    "microsoft": ["https://news.microsoft.com/feed/"],
}


def _candidates(company):
    dom = company.get("domain", "")
    urls = list(company.get("feeds") or FEEDS.get(company["slug"], []))
    if company.get("newsroom"):
        urls.append(company["newsroom"])
    if dom:
        # Direct WordPress-style feed guesses (parsed directly), then newsroom/IR pages (RSS auto-discovered).
        urls += [f"https://news.{dom}/feed/", f"https://www.{dom}/feed/", f"https://{dom}/feed/",
                 f"https://news.{dom}/", f"https://www.{dom}/news", f"https://www.{dom}/newsroom",
                 f"https://{dom}/news", f"https://www.{dom}/media-center", f"https://www.{dom}/media"]
    return urls


def _discover(page_url):
    """Find RSS/Atom feed links advertised on a newsroom / IR page."""
    try:
        r = requests.get(page_url, headers=UA, timeout=18, allow_redirects=True)
        if r.status_code != 200 or "xml" in r.headers.get("content-type", "") is True:
            pass
        html = r.text
    except requests.RequestException:
        return []
    feeds = re.findall(r'<link[^>]+type=["\']application/(?:rss|atom)\+xml["\'][^>]*href=["\']([^"\']+)["\']',
                       html, re.I)
    feeds += re.findall(r'href=["\']([^"\']*(?:/rss|/feed|rss\.xml|feed\.xml|atom\.xml)[^"\']*)["\']', html, re.I)
    out, seen = [], set()
    for f in feeds:
        full = urljoin(page_url, f)
        if full not in seen:
            seen.add(full); out.append(full)
    return out[:4]


def _text(el):
    return re.sub("<[^>]+>", " ", (el.text or "")).strip() if el is not None and el.text else ""


def _parse(url):
    try:
        r = requests.get(url, headers=UA, timeout=18)
        ct = r.headers.get("content-type", "")
        if r.status_code != 200 or not ("xml" in ct or r.text.lstrip().startswith("<?xml") or "<rss" in r.text[:200] or "<feed" in r.text[:200]):
            return []
        root = ET.fromstring(r.content)
    except (requests.RequestException, ET.ParseError):
        return []
    items = []
    for node in root.iter():
        tag = node.tag.lower().rsplit("}", 1)[-1]
        if tag not in ("item", "entry"):
            continue
        title = link = pub = desc = ""
        for ch in node:
            ctag = ch.tag.lower().rsplit("}", 1)[-1]
            if ctag == "title":
                title = _text(ch)
            elif ctag == "link":
                link = (ch.text or ch.get("href") or "").strip()
            elif ctag in ("pubdate", "published", "updated", "date"):
                pub = (ch.text or "").strip()
            elif ctag in ("description", "summary", "content", "encoded") and not desc:
                desc = re.sub("<[^>]+>", " ", (ch.text or "")).strip()[:500]
        if title:
            items.append({"title": title, "url": link, "published": pub, "content": desc})
    return items


def pool(company, month, max_items=60):
    """Return a raw article pool from the company's official newsroom / IR feeds (best-effort)."""
    cands = _candidates(company)
    direct = [u for u in cands if u.endswith(".xml") or "/rss" in u.lower() or "/feed" in u.lower()]
    pages = [u for u in cands if u not in direct]
    feeds, seen = list(direct), set(direct)
    for pg in pages[:4]:
        for f in _discover(pg):
            if f not in seen:
                seen.add(f); feeds.append(f)
    out = []
    for f in feeds[:6]:
        out += _parse(f)
        if len(out) >= max_items:
            break
    return out[:max_items]
