import re

import requests
from bs4 import BeautifulSoup

import settings
from timeframe import Month

SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik}.json"
INVESTEGATE_URL = "https://www.investegate.co.uk/company/{ticker}"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120 Safari/537.36"}
MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def _sec(cik, month):
    try:
        response = requests.get(SUBMISSIONS_URL.format(cik=cik),
                                headers={"User-Agent": f"client-intelligence {settings.CONTACT_EMAIL}"}, timeout=30)
        response.raise_for_status()
        recent = response.json()["filings"]["recent"]
    except (requests.RequestException, KeyError):
        return []
    results = []
    for i, filed in enumerate(recent.get("filingDate", [])):
        if month.contains(filed) is not True:
            continue
        accession = recent["accessionNumber"][i].replace("-", "")
        document = recent.get("primaryDocument", [""] * len(recent["form"]))[i]
        results.append({
            "form": recent["form"][i], "filed": filed,
            "description": recent.get("primaryDocDescription", [""] * len(recent["form"]))[i],
            "url": f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{accession}/{document}",
        })
    return results


def _investegate(ticker, month):
    try:
        response = requests.get(INVESTEGATE_URL.format(ticker=ticker), headers=UA, timeout=30)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "lxml")
    except requests.RequestException:
        return []
    results, seen = [], set()
    pattern = re.compile(r"(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(20\d{2})")
    for link in soup.select(f"a[href*='--{ticker.lower()}/']"):
        href = link.get("href", "")
        if "/announcement/rns/" not in href or href in seen:
            continue
        row = link.find_parent(["tr", "li", "div"])
        match = pattern.search(row.get_text(" ", strip=True)) if row else None
        if not match:
            continue
        filed = f"{match.group(3)}-{MONTHS[match.group(2)]:02d}-{int(match.group(1)):02d}"
        if month.contains(filed) is not True:
            continue
        seen.add(href)
        results.append({
            "form": "RNS", "filed": filed,
            "description": link.get_text(" ", strip=True),
            "url": "https://www.investegate.co.uk" + href,
        })
    return results


def collect(company, month: Month):
    if company.get("sec_cik"):
        return _sec(company["sec_cik"], month)
    if company.get("rns_ticker"):
        return _investegate(company["rns_ticker"], month)
    return []
