import re
import threading
import time
from datetime import timedelta
from urllib.parse import quote_plus
from xml.etree import ElementTree as ET

import requests

import settings
from analysis import relevance
from timeframe import Month

TAVILY_URL = "https://api.tavily.com/search"
GDELT_URL = "https://api.gdeltproject.org/api/v2/doc/doc"
GOOGLE_URL = "https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"

JUNK = re.compile(
    r"\b(market (size|share|trends?|report|growth|forecast|outlook|analysis)|sitemap|"
    r"coupon|promo code|discount code|buy the dip|price target 20)\b", re.I)
STOP = {"new", "company", "the", "and", "its", "plans", "targets"}


def _strip(text):
    return re.sub("<[^>]+>", " ", text or "").strip()


_last_gdelt = [0.0]
_gdelt_lock = threading.Lock()


def _gdelt_wait():
    # Hold the lock across the wait so parallel account workers still respect GDELT's ~1-call/6s limit.
    with _gdelt_lock:
        gap = time.time() - _last_gdelt[0]
        if gap < 6:
            time.sleep(6 - gap)
        _last_gdelt[0] = time.time()


def _gdelt_pool(company, month):
    query = "(" + " OR ".join(f'"{alias}"' for alias in company["aliases"]) + ")"
    params = {
        "query": query, "mode": "ArtList", "format": "json", "maxrecords": "250",
        "sort": "DateDesc",
        "startdatetime": month.start.strftime("%Y%m%d000000"),
        "enddatetime": month.end.strftime("%Y%m%d235959"),
    }
    for _ in range(4):
        _gdelt_wait()
        try:
            response = requests.get(GDELT_URL, params=params, headers={"User-Agent": UA}, timeout=45)
            if response.status_code == 429:
                time.sleep(20)
                continue
            response.raise_for_status()
            articles = response.json().get("articles", [])
        except (requests.RequestException, ValueError):
            time.sleep(8)
            continue
        pool = []
        for article in articles:
            if article.get("language", "English") != "English":
                continue
            seen = article.get("seendate", "")
            published = f"{seen[0:4]}-{seen[4:6]}-{seen[6:8]}" if len(seen) >= 8 else ""
            pool.append({
                "title": article.get("title", "").strip(),
                "url": article.get("url", ""),
                "published": published,
                "content": article.get("domain", ""),
            })
        return pool
    return []


def _google_pool(company, month):
    before = (month.end + timedelta(days=1)).isoformat()
    query = f'{company["name"]} after:{month.start.isoformat()} before:{before}'
    try:
        response = requests.get(GOOGLE_URL.format(query=quote_plus(query)),
                                headers={"User-Agent": UA}, timeout=40)
        if response.status_code != 200:
            return []
        root = ET.fromstring(response.content)
    except (requests.RequestException, ET.ParseError):
        return []
    return [{
        "title": (item.findtext("title") or "").strip(),
        "url": (item.findtext("link") or "").strip(),
        "published": item.findtext("pubDate") or "",
        "content": _strip(item.findtext("description"))[:400],
    } for item in list(root.iterfind(".//item"))[:100]]


def _field_keywords():
    return {
        key: [w for w in field["query"].replace("{company}", "").lower().split()
              if len(w) > 3 and w not in STOP]
        for key, field in settings.FIELDS.items()
    }


def _tavily_items(company, month, cap_per_field=25):
    items, seen = [], set()
    for field_key, field in settings.FIELDS.items():
        query = field["query"].format(company=company["name"])
        base = {"api_key": settings.TAVILY_API_KEY, "query": query, "topic": "news",
                "search_depth": "advanced", "max_results": cap_per_field,
                "start_date": month.start.isoformat(), "end_date": month.end.isoformat()}
        try:
            response = requests.post(TAVILY_URL, json=base, timeout=40)
            response.raise_for_status()
            results = response.json().get("results", [])
        except requests.RequestException:
            results = []
        for r in results:
            url, title = r.get("url", ""), r.get("title", "").strip()
            if not url or url in seen or not title or JUNK.search(title):
                continue
            within = month.contains(r.get("published_date", ""))
            if within is False:
                continue
            seen.add(url)
            items.append({"field": field_key, "title": title, "url": url,
                          "published": r.get("published_date", ""),
                          "content": (r.get("content") or "")[:600], "dated": within is True})
        time.sleep(0.4)
    return items


def _classify_pool(pool, month, cap_per_field=25, company=None, official=False):
    """Classify a raw article pool into the 5 FIELDS.

    When `company` is given, the pool is first ranked by correlation (analysis.relevance) so the per-field
    cap keeps the MOST relevant items rather than whatever arrived first. `official=True` marks items as
    first-party (newsroom / IR), which both boosts their rank and lets the UI/Excel lead with them.
    """
    if company is not None:
        for a in pool:
            a.setdefault("official", official)
        pool = relevance.rank(list(pool), company, month)
    keywords = _field_keywords()
    seen, items, counts = set(), [], {key: 0 for key in settings.FIELDS}
    for article in pool:
        title = article["title"]
        key = (article["url"] or title).lower()
        if not title or key in seen or JUNK.search(title):
            continue
        within = month.contains(article["published"])
        if within is False:
            continue
        seen.add(key)
        blob = (title + " " + article["content"]).lower()
        matched = [k for k in settings.FIELDS if any(w in blob for w in keywords[k])] or ["vision_strategy"]
        for field_key in matched:
            if counts[field_key] >= cap_per_field:
                continue
            counts[field_key] += 1
            items.append({
                "field": field_key, "title": title, "url": article["url"],
                "published": article["published"], "content": article["content"],
                "dated": within is True, "official": bool(article.get("official")),
                "score": article.get("score", 0),
            })
    return items


def strategy_research(company, max_results=5):
    """Targeted Tavily research on the client's strategy / tech direction (evergreen, not month-bound).
    Returns [{title, url, content}]. Empty without a Tavily key or on failure."""
    if not settings.TAVILY_API_KEY:
        return []
    queries = [f"{company['name']} strategy transformation priorities",
               f"{company['name']} technology AI cloud data India investment"]
    out, seen = [], set()
    for q in queries:
        try:
            r = requests.post(TAVILY_URL, json={"api_key": settings.TAVILY_API_KEY, "query": q,
                                                "topic": "news", "max_results": max_results}, timeout=40)
            r.raise_for_status()
            results = r.json().get("results", [])
        except (requests.RequestException, ValueError):
            continue
        for x in results:
            url, title = x.get("url", ""), (x.get("title") or "").strip()
            if url and url not in seen and title and not JUNK.search(title):
                seen.add(url)
                out.append({"title": title, "url": url, "content": (x.get("content") or "")[:400]})
    return out


def collect(company, month: Month):
    source = settings.NEWS_SOURCE
    if source == "tavily":
        return _tavily_items(company, month)
    pool = []
    if source in ("gdelt", "auto", "googlenews"):
        if source != "googlenews":
            pool += _gdelt_pool(company, month)
        time.sleep(1)
        pool += _google_pool(company, month)
    return _classify_pool(pool, month, company=company)
