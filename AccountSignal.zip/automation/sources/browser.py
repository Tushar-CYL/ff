"""Central Playwright browser — Bright Data Scraping Browser (remote, unblocked) when BRIGHTDATA_CDP is
set, else local chromium.

Why this is the engine that makes the pipeline FASTER on hard sites and OFFICE-LAPTOP-CAPABLE:
- Bright Data runs the real browser on ITS OWN servers (defeats bot-walls / CAPTCHAs / virtualized SPAs).
- It works from a RESTRICTED (office) network: the only outbound connection is the wss:// CDP endpoint
  (brd.superproxy.io:9222) — the career sites are fetched by Bright Data, not by this laptop. So the same
  `python india_run.py` scrapes fresh on the personal AND the office laptop.

THREAD-LOCAL by design: Playwright's sync API is thread-affine (an object made on one thread can't be used
on another). The scraper runs sites in parallel worker threads AND the HTTP fallback below can fire inside
those threads, so each thread keeps its OWN Playwright + browser session. That is what lets a blocked GET
on a restricted network fall back to Bright Data even during the parallel scrape.

Two ways it's used:
1) Browser-driven adapters (eightfold / successfactors / generic / nike) call `new_browser()` + `page()`.
2) The shared HTTP helper (sources/jobs._request) calls `fetch()` as a FALLBACK when a plain GET is
   blocked — so Radancy / Phenom sitemaps + JSON-LD job pages also work on a restricted network. Each
   thread keeps one fallback session, recycled when the domain changes.
"""
import threading
from urllib.parse import urlsplit

import settings

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/120 Safari/537.36")

_tl = threading.local()  # per-thread: .pw (Playwright), .fetch_browser, .fetch_host


def remote_enabled():
    """True when a Bright Data Scraping Browser endpoint is configured."""
    return bool(settings.BRIGHTDATA_CDP)


def _playwright():
    """This thread's Playwright instance (started lazily, one per thread)."""
    pw = getattr(_tl, "pw", None)
    if pw is None:
        from playwright.sync_api import sync_playwright
        pw = sync_playwright().start()
        _tl.pw = pw
    return pw


def new_browser():
    """A fresh browser session on THIS thread: a Bright Data remote session when configured, else (or if
    Bright Data is unreachable/suspended) a FREE local chromium. The caller owns it and must close it.

    The local fallback means a bad/suspended BRIGHTDATA_CDP never breaks scraping on an open network —
    it just uses the local browser (needs `python -m playwright install chromium` once)."""
    p = _playwright()
    if settings.BRIGHTDATA_CDP:
        try:
            return p.chromium.connect_over_cdp(settings.BRIGHTDATA_CDP, timeout=120000)
        except Exception:
            pass  # Bright Data unavailable (suspended / unreachable) → fall back to the local browser
    return p.chromium.launch(headless=True)


def page(browser, **ctx_kwargs):
    """Open a context (sane UA/locale/viewport) + page on the given browser. Returns (context, page)."""
    kwargs = dict(user_agent=UA, locale="en-US", viewport={"width": 1366, "height": 1000})
    kwargs.update(ctx_kwargs)
    ctx = browser.new_context(**kwargs)
    return ctx, ctx.new_page()


def fetch(url, timeout=60000, render_ms=600):
    """Fetch one URL through the remote browser and return (body_text, status_code). Uses the navigation
    RESPONSE body, so it works for XML sitemaps / JSON APIs as well as HTML pages. Keeps one session per
    thread, recycled when the domain changes (so Bright Data's per-session domain limit isn't hit).
    Returns (None, None) on failure or with no key configured."""
    if not settings.BRIGHTDATA_CDP:
        return None, None
    host = urlsplit(url).netloc
    for _ in range(2):  # one retry with a fresh session on any error
        fb = getattr(_tl, "fetch_browser", None)
        if fb is None or getattr(_tl, "fetch_host", None) != host:
            try:
                if fb is not None:
                    fb.close()
            except Exception:
                pass
            try:
                fb = new_browser()
            except Exception:
                _tl.fetch_browser = None
                return None, None
            _tl.fetch_browser, _tl.fetch_host = fb, host
        ctx = None
        try:
            ctx, pg = page(fb)
            resp = pg.goto(url, wait_until="domcontentloaded", timeout=timeout)
            if render_ms:
                pg.wait_for_timeout(render_ms)
            if resp is None:
                return pg.content(), 200
            try:
                return resp.text(), resp.status
            except Exception:
                return pg.content(), resp.status
        except Exception:
            try:
                if fb is not None:
                    fb.close()
            except Exception:
                pass
            _tl.fetch_browser = None  # force a fresh session on retry
        finally:
            if ctx is not None:
                try:
                    ctx.close()
                except Exception:
                    pass
    return None, None


def shutdown():
    """Close this thread's fallback session and stop its Playwright (worker threads' instances are freed
    on process exit)."""
    fb = getattr(_tl, "fetch_browser", None)
    pw = getattr(_tl, "pw", None)
    try:
        if fb is not None:
            fb.close()
    except Exception:
        pass
    try:
        if pw is not None:
            pw.stop()
    except Exception:
        pass
    _tl.fetch_browser = _tl.fetch_host = _tl.pw = None
