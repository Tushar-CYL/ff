"""Central Playwright browser — Bright Data Scraping Browser (remote, unblocked) when BRIGHTDATA_CDP is
set, else local chromium.

Why this is the engine that makes the pipeline both FASTER-on-hard-sites and OFFICE-LAPTOP-CAPABLE:
- Bright Data runs the real browser on ITS OWN servers and solves bot-walls / CAPTCHAs / virtualized
  SPAs, so career sites that block plain scraping become readable.
- It also works from a RESTRICTED (office) network, because the only outbound connection this machine
  makes is the wss:// CDP endpoint (brd.superproxy.io:9222) — the career sites are fetched by Bright
  Data, not by this laptop. So the same `python india_run.py` works on the personal AND office laptop.

Two Bright Data facts this module is built around:
1) Playwright's sync API forbids two live `sync_playwright` instances per process — so Playwright is
   started ONCE here and shared.
2) A single Scraping Browser SESSION has a limit on how many distinct domains it may navigate
   (navigate_domains_limit). So we open a FRESH session per company/domain and close it after, rather
   than reusing one browser for all 32 sites.

Two ways it's used:
1) Browser-driven adapters (eightfold / successfactors / generic `browser`) call `new_browser()` once
   per company, drive pages via `page(b)`, and close the browser in a finally.
2) The shared HTTP helper (sources/jobs._request) calls `fetch()` as a FALLBACK when a plain GET is
   blocked by the local network — so Radancy / Phenom sitemaps + JSON-LD job pages also work on a
   restricted network. `fetch()` keeps one session per domain and recycles it when the domain changes.

With no BRIGHTDATA_CDP key it uses a local chromium for the adapters and performs no HTTP fallback.
"""
import threading
from urllib.parse import urlsplit

import settings

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/120 Safari/537.36")

_lock = threading.RLock()
_pw = None


def remote_enabled():
    """True when a Bright Data Scraping Browser endpoint is configured."""
    return bool(settings.BRIGHTDATA_CDP)


def _playwright():
    """The one shared Playwright instance (started lazily)."""
    global _pw
    if _pw is None:
        from playwright.sync_api import sync_playwright
        _pw = sync_playwright().start()
    return _pw


def new_browser():
    """A FRESH browser session: a new Bright Data remote session (fresh domain budget) when configured,
    else a local chromium. The caller owns it and must close it (close ends the Bright Data session)."""
    p = _playwright()
    if settings.BRIGHTDATA_CDP:
        return p.chromium.connect_over_cdp(settings.BRIGHTDATA_CDP, timeout=120000)
    return p.chromium.launch(headless=True)


def page(browser, **ctx_kwargs):
    """Open a context (sane UA/locale/viewport) + page on the given browser. Returns (context, page)."""
    kwargs = dict(user_agent=UA, locale="en-US", viewport={"width": 1366, "height": 1000})
    kwargs.update(ctx_kwargs)
    ctx = browser.new_context(**kwargs)
    return ctx, ctx.new_page()


# ---- HTTP fallback: one session per domain, recycled when the domain changes ----
_fetch_browser = None
_fetch_host = None


def _recycle():
    global _fetch_browser, _fetch_host
    try:
        if _fetch_browser is not None:
            _fetch_browser.close()
    except Exception:
        pass
    _fetch_browser = _fetch_host = None


def fetch(url, timeout=60000, render_ms=600):
    """Fetch one URL through the remote browser and return (body_text, status_code).

    Uses the navigation RESPONSE body — so it works for XML sitemaps and JSON APIs as well as HTML job
    pages. Keeps a session alive while the domain is unchanged (fast for many pages of one site) and
    recycles it on a new domain so Bright Data's per-session domain limit is never hit. Returns
    (None, None) on failure or with no key configured."""
    global _fetch_browser, _fetch_host
    if not settings.BRIGHTDATA_CDP:
        return None, None
    host = urlsplit(url).netloc
    with _lock:
        for _ in range(2):  # one retry with a fresh session on any error
            try:
                if _fetch_browser is None or host != _fetch_host:
                    _recycle()
                    _fetch_browser = new_browser()
                    _fetch_host = host
                ctx = _fetch_browser.new_context(user_agent=UA, locale="en-US")
                try:
                    pg = ctx.new_page()
                    resp = pg.goto(url, wait_until="domcontentloaded", timeout=timeout)
                    if render_ms:
                        pg.wait_for_timeout(render_ms)
                    if resp is None:
                        return pg.content(), 200
                    try:
                        return resp.text(), resp.status
                    except Exception:
                        return pg.content(), resp.status
                finally:
                    try:
                        ctx.close()
                    except Exception:
                        pass
            except Exception:
                _recycle()
        return None, None


def shutdown():
    """Close any fallback session and stop Playwright (call once at end of a run)."""
    global _pw
    with _lock:
        _recycle()
        try:
            if _pw is not None:
                _pw.stop()
        except Exception:
            pass
        _pw = None
