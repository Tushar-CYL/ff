"""Shared HTTP / JSON-LD scraping helpers used by the discover.py career-portal adapters.

Not a scraper itself — just the reusable primitives: a retrying request wrapper, role enrichment,
schema.org JobPosting parsing, location resolution, and sitemap job-URL discovery. The per-portal
collectors (Radancy / Workday / Avature / Phenom / Eightfold / SuccessFactors) live in discover.py.
"""
import concurrent.futures as cf
import json
import os
import random
import re
import time
from datetime import date
from urllib.parse import urljoin  # re-exported: discover.py uses jobs.urljoin
from xml.etree import ElementTree as ET

import requests

from analysis import classify
from sources import browser
from timeframe import parse_date

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"}
AVATURE_CAP = 2000  # max listings to page through on a very large global careers site
MAX_TRIES = 4       # per-request attempts before giving up
BACKOFF_CAP = 20    # seconds
# Concurrent per-page fetches per site. The slow part of Radancy/Phenom/Workday/Avature is fetching each
# job page one at a time; fetching them in a small thread pool is ~4-5x faster (measured) with the same
# data. Tunable via PAGE_WORKERS; kept modest so one domain isn't hammered into 429s.
PAGE_WORKERS = int(os.environ.get("PAGE_WORKERS", "6"))


def _new_stats():
    # urls: job URLs seen · tech: tech-title matches fetched · fetched: pages parsed OK
    # · fail: requests that failed after all retries (silently dropped before)
    return {"urls": 0, "tech": 0, "fetched": 0, "fail": 0}


def make_session(pool=None):
    """A requests Session with a connection pool sized for concurrent page fetches + the UA header."""
    pool = pool or (PAGE_WORKERS + 4)
    s = requests.Session()
    s.headers.update(UA)
    adapter = requests.adapters.HTTPAdapter(pool_connections=pool, pool_maxsize=pool)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s


def fetch_pages(session, urls, stats, max_workers=None, retry_failed=True):
    """GET many URLs concurrently (thread pool), returning [(url, Response|None)] in the SAME order as
    `urls`. Only the network I/O is parallel — callers parse the results single-threaded, so stats and
    role lists stay consistent. Used by the JSON-LD adapters instead of a serial fetch loop.

    Self-healing: pages that fail in the parallel pass (often a transient 429/timeout triggered by the
    concurrency itself) are retried once, gently and sequentially, so a rate-limit blip never silently
    drops real roles. Bounded by RETRY_CAP so a hard-blocked site (every page 403) doesn't crawl forever
    — those keep last month's data via the non-destructive dump guard instead."""
    urls = list(urls)
    if not urls:
        return []
    workers = min(max_workers or PAGE_WORKERS, len(urls))
    results = [None] * len(urls)

    def one(i_u):
        i, u = i_u
        return i, u, _request(session, u, stats)

    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        for i, u, r in ex.map(one, enumerate(urls)):
            results[i] = (u, r)

    if retry_failed:
        failed = [i for i, (u, r) in enumerate(results) if r is None]
        cap = int(os.environ.get("RETRY_CAP", "400"))
        if failed and len(failed) <= cap:
            time.sleep(2)
            for i in failed:
                u = results[i][0]
                r = _request(session, u, stats)
                if r is not None:
                    stats["fail"] = max(0, stats.get("fail", 0) - 1)  # recovered
                    stats["recovered"] = stats.get("recovered", 0) + 1
                results[i] = (u, r)
                time.sleep(0.25)
    return results


def _wait(attempt, retry_after=None):
    if retry_after:
        try:
            time.sleep(min(float(retry_after), 60))
            return
        except (TypeError, ValueError):
            pass
    time.sleep(min(1.5 * (2 ** attempt) + random.random(), BACKOFF_CAP))


class _BrowserResp:
    """A minimal requests.Response stand-in wrapping HTML/XML/JSON fetched through the Bright Data
    remote browser, so callers that read .text / .content / .json() work unchanged."""

    def __init__(self, text, status):
        self.text = text or ""
        self.content = (text or "").encode("utf-8", "replace")
        self.status_code = status or 200
        self.headers = {}

    def json(self):
        return json.loads(self.text)

    def raise_for_status(self):
        return None


def _browser_get(url, stats):
    """Fallback a genuinely BLOCKED GET through the Bright Data remote browser (so Radancy/Phenom
    sitemaps + JSON-LD job pages work on a restricted office network — the page is fetched by Bright
    Data, not this laptop). Off with no key or NO_BROWSER_FALLBACK=1.

    Only runs on the MAIN thread: Playwright's sync API is thread-affine, so calling it from a scrape
    worker thread corrupts the shared browser. On an open network the parallel scrape never needs the
    fallback; on a restricted network run the scrape sequentially (SCRAPE_WORKERS=1) so this fires."""
    if os.environ.get("NO_BROWSER_FALLBACK") == "1" or not browser.remote_enabled():
        return None
    import threading
    if threading.current_thread() is not threading.main_thread():
        return None
    body, status = browser.fetch(url)
    if body and (status is None or status < 400):
        stats["browser"] = stats.get("browser", 0) + 1
        return _BrowserResp(body, status)
    return None


def _fail(url, method, stats, reason):
    # Fall back to the remote browser only for a genuine BLOCK (connection refused/timeout, or HTTP 403)
    # — never for rate-limiting (429/5xx), where opening a Bright Data session per page would exhaust the
    # session budget and break the browser-driven adapters.
    if method == "GET" and reason in ("conn", "block"):
        r = _browser_get(url, stats)
        if r is not None:
            return r
    stats["fail"] += 1
    return None


def _request(session, url, stats, method="GET", json_body=None, timeout=30, tries=MAX_TRIES):
    """GET/POST with retries. Retries timeouts, connection errors and HTTP 429/5xx
    (honouring Retry-After); returns the Response, or None after exhausting retries.
    A 4xx other than 429 is treated as permanent (no retry). Counts failures in stats.
    A GET that is truly BLOCKED (connection error or 403) is retried once through the Bright Data remote
    browser (see _browser_get); a rate-limited GET (429/5xx) is not."""
    for attempt in range(tries):
        try:
            if method == "POST":
                r = session.post(url, json=json_body, timeout=timeout)
            else:
                r = session.get(url, timeout=timeout)
        except requests.RequestException:
            if attempt < tries - 1:
                _wait(attempt)
                continue
            return _fail(url, method, stats, "conn")
        if r.status_code == 429 or r.status_code >= 500:
            if attempt < tries - 1:
                _wait(attempt, r.headers.get("Retry-After"))
                continue
            return _fail(url, method, stats, "rate")
        if 400 <= r.status_code < 500:  # 403 = blocked (try browser); 404/other = permanent
            return _fail(url, method, stats, "block" if r.status_code == 403 else "4xx")
        return r


def _aging(posted):
    d = parse_date(posted)
    return (date.today() - d).days if d else None


def _enrich(role):
    p = parse_date(role.pop("_posted", ""))
    role["posted_date"] = p.isoformat() if p else ""
    role["aging_days"] = _aging(role["posted_date"])
    role.setdefault("team", "")
    role.setdefault("hiring_manager", "")
    role.setdefault("employment_type", "")
    role["status"] = "Open"
    return classify.enrich_role(role)


def _jsonld_posting(html):
    for block in re.findall(r'<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>', html, re.S):
        try:
            data = json.loads(block)
        except ValueError:
            continue
        for item in (data if isinstance(data, list) else [data]):
            if isinstance(item, dict) and item.get("@type") == "JobPosting":
                return item
    return None


def _location_from(posting):
    loc = posting.get("jobLocation")
    entries = loc if isinstance(loc, list) else [loc] if loc else []
    for entry in entries:
        addr = (entry or {}).get("address", {}) if isinstance(entry, dict) else {}
        city, region = addr.get("addressLocality", ""), addr.get("addressRegion", "")
        country = addr.get("addressCountry", "")
        if city or region:
            return ", ".join(x for x in [city, region] if x), (country if isinstance(country, str) else (country or {}).get("name", ""))
    return "", ""


def _sitemap_jobs(domain, session, stats):
    """Collect /job/ URLs from a site's sitemap (Radancy / Phenom pattern), drilling one level into a
    sitemap index if the top level has none."""
    def locs(url):
        r = _request(session, url, stats)
        if r is None:
            return []
        try:
            root = ET.fromstring(r.content)
        except ET.ParseError:
            stats["fail"] += 1
            return []
        return [e.text for e in root.iter() if e.tag.endswith("loc") and e.text]
    top = locs(f"https://{domain}/sitemap.xml")
    jobs = [u for u in top if "/job/" in u]
    if not jobs:
        for sub in [u for u in top if u.endswith(".xml")][:15]:
            jobs += [u for u in locs(sub) if "/job/" in u]
    return jobs


def locale_sitemap_jobs(domain, session, stats, prefix="/in/en/"):
    """Job URLs from a country-locale sitemap (e.g. https://{domain}/in/en/sitemap.xml). Those URLs are
    already location-scoped to India, so no per-page India filtering is needed and far fewer pages are
    fetched. Returns [] when the site has no such locale sitemap (caller falls back to the global one)."""
    def locs(url):
        r = _request(session, url, stats)
        if r is None:
            return []
        try:
            root = ET.fromstring(r.content)
        except ET.ParseError:
            return []
        return [e.text for e in root.iter() if e.tag.endswith("loc") and e.text]

    top = locs(f"https://{domain}{prefix}sitemap.xml")
    job_urls = [u for u in top if f"{prefix}job/" in u]
    if not job_urls:  # locale sitemap might be an index
        for sub in [u for u in top if u.endswith(".xml")][:10]:
            job_urls += [u for u in locs(sub) if f"{prefix}job/" in u]
    return job_urls
