import json
import re

import requests

import settings
from analysis import fields as fieldmod

SYSTEM_PROMPT = (
    "You are a sharp corporate intelligence analyst preparing a client-facing monthly briefing for an "
    "IT-services firm's alliance team (think EY). Write specific, engaging one-sentence insights grounded "
    "ONLY in the evidence provided — always name the concrete detail (the company, the dollar figure, the "
    "partner, the platform, the technology). No vague corporate filler, no hedging, no generic phrases "
    "like 'continues to focus on its strategy'. Make each 'significance' a crisp, concrete read of what "
    "the development means for an IT-services alliance team's opportunity. Every field must list the "
    "source URLs you used. Return valid JSON only."
)

TEMPLATE = """Company: {company} ({sector}, {listing}) - {month_label}

EVIDENCE BY FIELD:
{evidence}

Return JSON exactly:
{{
  "direction": "Hiring | Expansion | Restructuring | Stable | Mixed",
  "key_development": "one sentence: the single most important development this month",
  "fields": {{
{fields_spec}
  }}
}}
For each field: "summary" = ONE clear, concise, self-contained factual sentence from the evidence;
"significance" = one neutral sentence on what it means for the firm; "sources" = list of the URLs (from
the evidence) that support it. If a field has no evidence, summary = "No material developments this
period.", significance = "", sources = []. For "hiring", summarise the role/competency numbers given.
IMPORTANT: each of the five fields must cover a DIFFERENT development — never restate the same event,
deal, or announcement in more than one field. Put each development in the single most relevant field
only; if a field has no distinct development of its own, use "No material developments this period.\""""


class EYQClient:
    def __init__(self):
        self.endpoint = settings.EYQ_ENDPOINT.rstrip("/")
        self.key = settings.EYQ_KEY
        self.model = settings.EYQ_MODEL
        self.api_version = settings.EYQ_API_VERSION

    @property
    def configured(self):
        return bool(self.endpoint and self.key)

    def chat(self, messages, temperature=0.3, max_tokens=4000):
        url = f"{self.endpoint}/openai/deployments/{self.model}/chat/completions"
        body = {"messages": messages}
        m = self.model.lower()
        if m.startswith("gpt-5") or m.startswith("o1") or m.startswith("o3") or m.startswith("o4"):
            # GPT-5 / o-series: use max_completion_tokens, default temperature only
            body["max_completion_tokens"] = max(max_tokens, 6000)
        else:
            body["max_tokens"] = max_tokens
            body["temperature"] = temperature
        r = requests.post(url, json=body, headers={"api-key": self.key},
                          params={"api-version": self.api_version}, timeout=180)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


def _evidence(bundle):
    lines, field_urls = [], {}
    for key, field in settings.FIELDS.items():
        lines.append(f"\n[{key}] {field['label']}")
        urls = []
        if key == "hiring":
            lines.append("  stats: " + fieldmod.hiring_stats_text(bundle))
            careers = (bundle["jobs"] or {}).get("careers_url", "")
            if careers:
                lines.append(f"  source: {careers}")
                urls.append(careers)
        for item in fieldmod.field_items(bundle, key):
            lines.append(f"  - {item['title']}  ({item['url']})")
            urls.append(item["url"])
        field_urls[key] = urls
    return "\n".join(lines), field_urls


def _fields_spec():
    return ",\n".join(
        f'    "{k}": {{"summary": "", "significance": "", "sources": []}}' for k in settings.FIELDS)


def _parse(text):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("no json")
    return json.loads(m.group(0))


def synthesize(bundle, client):
    evidence, field_urls = _evidence(bundle)
    data = None
    if client and client.configured:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": TEMPLATE.format(
                company=bundle["company"], sector=bundle["sector"], listing=bundle["listing"],
                month_label=bundle["month_label"], evidence=evidence, fields_spec=_fields_spec())},
        ]
        for _ in range(2):  # one retry — a big-evidence call can return truncated/invalid JSON once
            try:
                data = _parse(client.chat(messages, max_tokens=6000))
                break
            except (requests.RequestException, ValueError, KeyError):
                data = None
    return _normalise(data, bundle, field_urls)


def _normalise(data, bundle, field_urls):
    data = data or {}
    out_fields = {}
    for key in settings.FIELDS:
        entry = (data.get("fields", {}) or {}).get(key, {}) or {}
        summary = entry.get("summary") or _fallback_summary(bundle, key)
        valid = [u for u in (entry.get("sources") or []) if u in field_urls.get(key, [])]
        if not valid:
            valid = field_urls.get(key, [])[:2]
        out_fields[key] = {"summary": summary, "significance": entry.get("significance", ""), "sources": valid}
    return {
        "direction": data.get("direction") or _fallback_direction(bundle),
        "key_development": data.get("key_development") or _fallback_key(bundle),
        "fields": out_fields,
    }


def _fallback_summary(bundle, key):
    if key == "hiring":
        return fieldmod.hiring_stats_text(bundle)
    items = bundle["fields"].get(key, [])
    if not items:
        return "No material developments this period."
    return items[0]["title"] + ("; " + items[1]["title"] if len(items) > 1 else "")


def _fallback_direction(bundle):
    agg = bundle.get("jobs_agg")
    if agg and agg["total_open_roles"] > 150:
        return "Hiring"
    return "Mixed"


def _fallback_key(bundle):
    for key in ("partnerships", "money_metrics", "expansion"):
        items = bundle["fields"].get(key, [])
        if items:
            return items[0]["title"]
    return ""


SYSTEM_WHY = (
    "You are a corporate intelligence analyst for an IT-services alliance team. From the India hiring "
    "evidence (departments, role types, skills, sample titles, and any recent news), explain in 2-3 "
    "neutral factual sentences WHAT the company appears to be building or scaling in India and WHY it "
    "is hiring these roles. Ground every claim in the evidence provided. Do not infer budget or intent "
    "beyond the postings. Return JSON only.")


def why_hiring(company, agg, news_titles, client):
    """A JD-grounded 'why are they hiring' paragraph for one company. Falls back to a template."""
    if not agg:
        return ""
    depts = ", ".join(f"{d} ({n})" for d, n in agg.get("by_business_domain", [])[:6])
    roles = ", ".join(f"{r} ({n})" for r, n in agg.get("by_role_type", [])[:6] if r != "Other")
    skills = ", ".join(f"{s} ({n})" for s, n in agg.get("top_tech", [])[:10])
    themes = ", ".join(t for t, _ in agg.get("by_theme", [])[:5])
    evidence = (f"Company: {company['name']} (India)\nOpen roles: {agg.get('total_open_roles')}\n"
                f"Departments: {depts}\nRole types: {roles}\nTop skills: {skills}\n"
                f"Transformation themes: {themes}\nRecent news: {'; '.join(news_titles[:5]) or 'none'}")
    if client and client.configured:
        try:
            msgs = [{"role": "system", "content": SYSTEM_WHY},
                    {"role": "user", "content": evidence + '\n\nReturn JSON {"why": "..."}'}]
            why = _parse(client.chat(msgs, max_tokens=500)).get("why", "").strip()
            if why:
                return why
        except (requests.RequestException, ValueError, KeyError):
            pass
    lead_dept = (agg.get("by_business_domain") or [["", 0]])[0][0]
    lead_skills = ", ".join(s for s, _ in agg.get("top_tech", [])[:4])
    return (f"{company['name']} is hiring {agg.get('total_open_roles')} India roles concentrated in "
            f"{lead_dept}, with demand for {lead_skills or 'a mix of technologies'}, pointing to "
            f"capability build-up in those areas.")


SYSTEM_ACCOUNT = (
    "You are a corporate intelligence analyst supporting an IT-services firm's account team. From the "
    "India hiring evidence and any news, produce account-planning insight. Ground every statement ONLY "
    "in the evidence; do not invent names, budgets, or facts. Neutral, concise. Return JSON only with "
    'keys: "takeaways" (array of 3-4 SHORT, punchy, connect-the-dots insights — each ONE sentence that '
    'ties the hiring evidence to the recent news/strategy and names the specific technologies, numbers, '
    'or deals, ending in the EY angle; these are the headline insights a partner reads first, so be '
    'specific and non-generic, e.g. "Scaling Databricks/GenAI data engineering (27 roles) alongside an '
    'AI drug-development partnership — data-platform & MLOps opportunity."), '
    '"strategy" (1-2 sentences: the client\'s overall strategic direction, from the news/research '
    'and hiring focus), "why" (2 sentences: what they are building and why they are hiring these roles), '
    '"investments" (1-2 sentences: the technology investments / capability expansion these postings '
    'imply), "stakeholders" (1 sentence: which functions/seniority levels an account team should engage, '
    'based on where hiring concentrates — do NOT invent person names), '
    '"actions" (array of 2-3 short next-best-action strings for the account team), '
    '"current_state" (1 short sentence reading the client technology maturity from the hiring mix, '
    'e.g. "heavy ERP, maturing cloud/data, emerging GenAI"), '
    '"discovery_questions" (array of 4-5 SPECIFIC questions an EY team should ask in a discovery '
    'workshop, each grounded in the hiring/news evidence and naming the tool, number or deal, e.g. '
    '"You are hiring 14 SAP consultants - is this an S/4HANA migration, and what is the target date?").')


def account_insight(company, agg, news_titles, opportunities, client):
    """One grounded LLM call -> dict(why, investments, stakeholders, actions[]). Template fallback."""
    if not agg:
        return {"takeaways": [], "strategy": "", "why": "", "investments": "", "stakeholders": "",
                "actions": [], "current_state": "", "discovery_questions": []}
    depts = ", ".join(f"{d} ({n})" for d, n in agg.get("by_business_domain", [])[:6])
    roles = ", ".join(f"{r} ({n})" for r, n in agg.get("by_role_type", [])[:6] if r != "Other")
    skills = ", ".join(f"{s} ({n})" for s, n in agg.get("top_tech", [])[:10])
    themes = ", ".join(t for t, _ in agg.get("by_theme", [])[:5])
    seniority = ", ".join(f"{s} ({n})" for s, n in agg.get("by_seniority", []))
    opp = "; ".join(o["interpretation"] for o in opportunities) or "none detected"
    evidence = (f"Company: {company['name']} (India)\nOpen roles: {agg.get('total_open_roles')}\n"
                f"Departments: {depts}\nRole types: {roles}\nTop skills: {skills}\n"
                f"Transformation themes: {themes}\nSeniority: {seniority}\n"
                f"Opportunity signals: {opp}\nRecent news: {'; '.join(news_titles[:5]) or 'none'}")
    if client and client.configured:
        msgs = [{"role": "system", "content": SYSTEM_ACCOUNT}, {"role": "user", "content": evidence}]
        for _ in range(2):  # one retry — the endpoint occasionally drops a call
            try:
                data = _parse(client.chat(msgs, max_tokens=1200))
                actions = data.get("actions") or []
                if isinstance(actions, str):
                    actions = [actions]
                takeaways = data.get("takeaways") or []
                if isinstance(takeaways, str):
                    takeaways = [takeaways]
                dq = data.get("discovery_questions") or []
                if isinstance(dq, str):
                    dq = [dq]
                if data.get("why"):
                    return {"takeaways": [t for t in takeaways if t][:4],
                            "strategy": data.get("strategy", ""), "why": data.get("why", ""),
                            "investments": data.get("investments", ""),
                            "stakeholders": data.get("stakeholders", ""), "actions": actions[:3],
                            "current_state": data.get("current_state", ""),
                            "discovery_questions": [q for q in dq if q][:5]}
            except (requests.RequestException, ValueError, KeyError, TypeError):
                continue
    return _account_fallback(company, agg, opportunities)


def _account_fallback(company, agg, opportunities):
    lead_dept = (agg.get("by_business_domain") or [["", 0]])[0][0]
    lead_sen = (agg.get("by_seniority") or [["", 0]])[0][0]
    skills = ", ".join(s for s, _ in agg.get("top_tech", [])[:4])
    themes = ", ".join(t for t, _ in agg.get("by_theme", [])[:3]) or "technology modernization"
    actions = [f"Engage {o['interpretation'].lower()} with a point of view on {o['ey_response'].lower()}."
               for o in opportunities[:3]]
    if not actions:
        actions = [f"Open a conversation with {company['name']}'s India {lead_dept} leadership on {themes}."]
    takeaways = [f"{o['interpretation']} — {o['ey_response']}." for o in opportunities[:3]]
    if lead_dept and skills:
        takeaways.insert(0, f"Hiring concentrated in {lead_dept}, demanding {skills} — capability build-up to target.")
    return {
        "takeaways": takeaways[:4],
        "strategy": f"{company['name']} appears focused on {themes} based on its India hiring and market activity.",
        "why": (f"{company['name']} is hiring {agg.get('total_open_roles')} India roles concentrated in "
                f"{lead_dept}, with demand for {skills or 'a mix of technologies'}."),
        "investments": f"Hiring in {skills or 'these skills'} implies investment in {themes}.",
        "stakeholders": (f"Engage {lead_dept} leadership; hiring skews {lead_sen}, so target "
                         f"programme owners and delivery leads in that function."),
        "actions": actions,
        "current_state": f"Hiring mix points to active work in {themes}.",
        "discovery_questions": _fallback_questions(agg),
    }


_PROG = {
    "SAP": "an SAP S/4HANA / ERP transformation", "SAP S/4HANA": "an SAP S/4HANA migration",
    "ABAP": "an SAP programme", "Databricks": "a data-platform build", "Snowflake": "a data-platform build",
    "data governance": "a data-governance programme", "AWS": "a cloud migration",
    "Microsoft Azure": "an Azure cloud migration", "Google Cloud": "a Google Cloud migration",
    "Kubernetes": "a platform-engineering / containerisation effort", "Terraform": "a cloud platform build",
    "GenAI": "a GenAI initiative", "LLM": "a GenAI initiative", "ServiceNow": "a ServiceNow / ITSM rollout",
    "Power BI": "a BI / analytics modernisation", "Tableau": "a BI / analytics modernisation",
    "Salesforce": "a Salesforce / CRM programme", "Apache Kafka": "an event-streaming / data-integration build",
}


def _fallback_questions(agg):
    """Specific, data-grounded discovery questions (no LLM) built from the real hiring numbers."""
    top = agg.get("top_tech", []) or []
    bdz = agg.get("by_business_domain", []) or []
    q = []
    if top:
        prog = _PROG.get(top[0][0], f"a {top[0][0]}-led initiative")
        q.append(f"{top[0][1]} open roles call for {top[0][0]} — is {prog} underway, and what is the target timeline?")
    if len(top) >= 3:
        q.append(f"You are also hiring for {top[1][0]} and {top[2][0]} — is this one connected programme or "
                 f"separate initiatives, and who owns it?")
    if bdz:
        q.append(f"{bdz[0][0]} has the most openings ({bdz[0][1]} roles) — is this a funded transformation or "
                 f"business-as-usual growth?")
    q.append("Are these roles a permanent build-out, and would you consider contract / consulting delivery to accelerate?")
    return q[:5]


SYSTEM_THEMES = ("You are a corporate intelligence analyst. From the per-company summaries, give the "
                 "cross-company themes an alliance team should note. Neutral language. JSON only.")


def synthesize_themes(report, client):
    overview = "\n".join(f"- {c['name']} ({c['direction']}): {c['key_development']}" for c in report["companies"])
    if client and client.configured:
        try:
            msgs = [{"role": "system", "content": SYSTEM_THEMES},
                    {"role": "user", "content": f"Developments for {report['month_label']}:\n{overview}\n\n"
                     'Return JSON {"themes":[{"title":"","detail":""}]} with 2-3 themes.'}]
            themes = _parse(client.chat(msgs, max_tokens=800)).get("themes", [])
            if themes:
                return [{"title": t.get("title", ""), "detail": t.get("detail", "")} for t in themes[:3]]
        except (requests.RequestException, ValueError, KeyError):
            pass
    hiring = [c["name"] for c in report["companies"] if c["direction"] in ("Hiring", "Expansion")]
    return [{"title": "Active hiring", "detail": f"Notable hiring/expansion at {', '.join(hiring) or 'several clients'}."},
            {"title": "Technology modernisation", "detail": "Cloud, AI and SAP activity recurs across the client base."}]
