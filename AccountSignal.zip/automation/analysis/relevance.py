"""News correlation ranking.

Scores each news / newsroom item by how strongly it CORRELATES to the account and to a genuine
strategic signal, so the most relevant items lead each field and feed the LLM synthesis + Excel. This
is an INTERNAL processing step — it changes which items are kept and in what order, never the dashboard
layout (no new UI element).

A higher score means: the company is actually named (not an incidental mention), a tracked vendor /
partnership / vision cue is present, the item is recent within the window, and it is first-party
(official newsroom / IR) rather than third-party noise.
"""
import re

from analysis import strategic
from timeframe import parse_date


def _company_tokens(company):
    names = [company.get("name", "")] + list(company.get("aliases") or [])
    toks = set()
    for n in names:
        for t in re.findall(r"[a-z0-9]+", (n or "").lower()):
            if len(t) > 2 and t not in {"the", "inc", "ltd", "plc", "group", "international"}:
                toks.add(t)
    return toks


def score(item, company, month=None):
    """Correlation score for one item dict ({title, content, published, official?}). Pure, no network."""
    title = (item.get("title") or "")
    content = (item.get("content") or "")
    t_low, c_low = title.lower(), content.lower()
    s = 0.0

    # 1) On-company: the account must actually be named. Title mention counts far more than body.
    toks = _company_tokens(company)
    if any(tok in t_low for tok in toks):
        s += 3.0
    elif any(tok in c_low for tok in toks):
        s += 1.0

    # 2) Strategic weight: tracked vendors / partnership verbs / vision verbs are the high-value items.
    blob = f"{title} {content}"
    if strategic._vendors_in(blob):
        s += 2.0
    if strategic.PARTNER_CUES.search(blob):
        s += 2.0
    if strategic.VISION_CUES.search(blob):
        s += 1.0

    # 3) Recency within the window (newer first); a real parsed date beats an undated item.
    d = parse_date(item.get("published", ""))
    if d:
        s += 1.0
        if month is not None:
            try:
                age = (month.end - d).days
                if age <= 7:
                    s += 2.0
                elif age <= 15:
                    s += 1.0
                elif age <= 31:
                    s += 0.5
            except Exception:
                pass

    # 4) First-party (official newsroom / investor relations) is authoritative.
    if item.get("official"):
        s += 1.5

    return s


def rank(items, company, month=None):
    """Return items sorted by descending correlation score (stable), each annotated with `score`."""
    for it in items:
        it["score"] = round(score(it, company, month), 2)
    return sorted(items, key=lambda x: x.get("score", 0), reverse=True)
