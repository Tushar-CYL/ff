import settings


def _role_blob(role):
    return (role.get("role_title", "") + " " + " ".join(role.get("skills", []))).lower()


def detect(roles):
    """Return opportunity hypotheses for one client from its roles. Hypotheses, not facts."""
    blobs = [_role_blob(r) for r in roles]
    hyps = []
    for rule in settings.OPPORTUNITY_RULES:
        hits = sum(1 for b in blobs if any(trig in b for trig in rule["triggers"]))
        if hits >= rule["min"]:
            hyps.append({
                "interpretation": rule["interpretation"],
                "ey_response": rule["ey_response"],
                "evidence": f"{hits} matching roles ({', '.join(rule['triggers'][:3])}…)",
                "weight": hits,
            })
    return sorted(hyps, key=lambda h: -h["weight"])


def radar(companies):
    """Cross-client opportunity radar: for each rule, which clients trigger it."""
    rows = []
    for rule in settings.OPPORTUNITY_RULES:
        firing = [c["name"] for c in companies
                  if any(h["interpretation"] == rule["interpretation"] for h in c.get("opportunities", []))]
        if firing:
            rows.append({"signal": rule["interpretation"], "ey_response": rule["ey_response"],
                         "clients": firing})
    return rows
