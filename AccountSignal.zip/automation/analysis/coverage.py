"""Provenance + coverage status for each account's hiring data.

Lets the dashboard and the BI Excel tell apart, honestly:
  full_jd       live India roles WITH a captured job description (full depth: skills, team, critical)
  titles_only   live India roles but titles only (a fallback source such as Indeed — no JD depth)
  signals_only  no hiring portal wired yet → global strategic signals only, hiring intentionally blank
  failed        a portal IS wired but returned no India roles → worth a look (likely a scrape issue)

This is the blueprint's data-discipline rule: never present a failed scrape as "0 hiring", and never
treat a title-only record as full-depth. Deterministic + tolerant, so the exporters can compute it at
write time off an already-generated report (no re-scrape), mirroring how strategic signals are derived.
"""

# Hiring extraction method → a short human label for the UI / Excel.
METHOD_LABEL = {
    "radancy": "Radancy", "workday": "Workday", "avature": "Avature", "phenom": "Phenom",
    "eightfold": "Eightfold", "successfactors": "SuccessFactors", "nike": "Nike careers",
    "browser": "Browser (assisted)", "brightdata": "Bright Data (assisted)",
    "indeed": "Indeed (titles only)", "": "—",
}
# Methods that only ever yield titles (no job description) → coverage caps at titles_only.
TITLES_ONLY_METHODS = {"indeed"}


def extraction_method(company, roles=None):
    """The hiring source for this account. Prefer the wired ATS config; otherwise fall back to the
    method stamped on the roles themselves (e.g. Indeed-sourced roles for accounts with no portal)."""
    cfg = company.get("careers") or {}
    m = cfg.get("type", "") or company.get("hiring_source", "")
    if m:
        return m
    if roles:
        from collections import Counter
        rms = [r.get("extraction_method") for r in roles if r.get("extraction_method")]
        if rms:
            return Counter(rms).most_common(1)[0][0]
    return ""


def method_label(method):
    return METHOD_LABEL.get(method or "", method or "—")


def description_captured(role):
    """True when a role carries a real captured JD (so skills/team/critical are grounded, not guessed)."""
    if role.get("description_captured") is not None:
        return bool(role["description_captured"])
    # Fallback for older cached roles: skills/team can only come from a JD we actually read.
    return bool(role.get("skills")) or bool(role.get("team"))


def coverage_status(company, roles):
    """One of full_jd / titles_only / signals_only / failed for this account's hiring."""
    method = extraction_method(company, roles)
    if roles:
        if method in TITLES_ONLY_METHODS or not any(description_captured(r) for r in roles):
            return "titles_only"
        return "full_jd"
    return "failed" if method else "signals_only"


STATUS_LABEL = {
    "full_jd": "Full JD", "titles_only": "Titles only",
    "signals_only": "Signals only", "failed": "Check source",
}


def provenance(company, roles):
    """Compact provenance block for an account, for the report / exports / dashboard badge."""
    roles = roles or []
    method = extraction_method(company, roles)
    status = coverage_status(company, roles)
    return {
        "extraction_method": method,
        "method_label": method_label(method),
        "coverage_status": status,
        "coverage_label": STATUS_LABEL.get(status, status),
        "roles": len(roles),
        "roles_full_jd": sum(1 for r in roles if description_captured(r)),
    }
