import re
import unicodedata
from collections import Counter
from itertools import combinations

import settings


def _norm_location(loc):
    if not loc:
        return loc
    loc = "".join(c for c in unicodedata.normalize("NFKD", loc) if not unicodedata.combining(c))
    for variant, canon in settings.LOCATION_CANON.items():
        loc = re.sub(variant, canon, loc, flags=re.I)
    return loc.strip()

# Real hiring-manager NAME only (e.g. "reporting to Jane Smith"). Public postings almost never carry
# this, so it is usually blank — we show what is genuinely there, never a placeholder.
_MANAGER_RE = re.compile(
    r"(?:reporting to|reports to|report to|hiring manager[:\s]+)\s+"
    r"((?:Mr\.?|Ms\.?|Mrs\.?|Dr\.?\s)?[A-Z][a-z]+\s+[A-Z][a-z]+)")
# Real team / function, required to end in a team-ish noun so we only capture genuine names.
_TEAM_RES = [
    re.compile(r"(?:you(?:'ll| will)?\s+(?:join|be (?:part|a member) of|work within)|part of|within|"
               r"join(?:ing)?|member of|sits? within|reports? into)\s+(?:the\s+|our\s+)?"
               r"([A-Z][A-Za-z0-9 &/\-]{2,45}?\s+(?:team|group|function|practice|unit|CoE|COE|"
               r"Center of Excellence|Centre of Excellence|chapter|squad|pod))"),
    re.compile(r"About (?:the|our) ([A-Z][A-Za-z0-9 &/\-]{2,45}?\s+(?:team|function|group))"),
]
# Manager ROLE/title the posting reports into (a personal name is almost never printed; a title is).
_REPORTS_RE = re.compile(
    r"reports?\s+(?:to|into)\s+(?:the\s+|a\s+|an\s+|our\s+)?"
    r"([A-Z][A-Za-z&/ \-]{3,50}?(?:Lead|Leader|Manager|Head|Director|VP|Vice President|"
    r"President|Officer|Chief|Architect|Owner))")
_GENERIC_TEAM = {"small team", "product team", "regional team", "agile team", "the team",
                 "our team", "global team", "peer team", "scrum team", "wider team", "a team",
                 "delivery team", "project team", "cross-functional team", "core team"}
_EXP_RE = re.compile(r"(\d{1,2})\+?\s*(?:years|yrs)\b", re.I)


def _score(text, keywords):
    return sum(1 for kw in keywords if kw in text)


# ---------- Level 1: extraction ----------
def normalize_tech(raw):
    return settings.VENDOR_CANON.get(raw.lower(), raw)


def detect_tech(text):
    found = []
    low = f" {text.lower()} "
    for term in settings.TECH_TERMS:
        t = term.lower()
        pattern = r"\b" + re.escape(t) + r"\b" if re.match(r"^[a-z0-9 ]+$", t) else re.escape(t)
        if re.search(pattern, low):
            found.append(normalize_tech(term))
    # dedupe, keep order
    seen, out = set(), []
    for t in found:
        if t not in seen:
            seen.add(t); out.append(t)
    return out


def experience_years(text):
    years = [int(m) for m in _EXP_RE.findall(text or "")]
    return max(years) if years else None


# ---------- Level 2: classification ----------
def competency(title, desc):
    t, d = f" {title.lower()} ", f" {desc.lower()} "
    best, best_score = "Other", 0
    for cluster, kws in settings.COMPETENCY_CLUSTERS.items():
        score = _score(t, kws) * 3 + _score(d, kws)
        if score > best_score:
            best, best_score = cluster, score
    return best if best_score >= 2 else "Other"


def role_family(title):
    t = f" {title.lower()} "
    best, best_score = "Other", 0
    for rt, kws in settings.ROLE_TYPES.items():
        s = _score(t, kws)
        if s > best_score:
            best, best_score = rt, s
    return best if best_score > 0 else "Other"


def business_domain(title, desc):
    t, d = f" {title.lower()} ", f" {desc.lower()} "
    best, best_score = "General / Other", 0
    for dom, kws in settings.BUSINESS_DOMAINS.items():
        score = _score(t, kws) * 2 + _score(d, kws)
        if score > best_score:
            best, best_score = dom, score
    return best if best_score >= 1 else "General / Other"


def seniority(title, years):
    t = f" {title.lower()} "
    for level, kws in settings.SENIORITY.items():
        if _score(t, kws):
            return level
    if years is not None:
        if years >= 8:
            return "Manager/Lead"
        if years >= 4:
            return "Senior"
        if years <= 1:
            return "Junior/Entry"
    return "Mid"


def themes(text):
    # text = title + extracted skills (precise), so boilerplate in the JD doesn't inflate themes
    blob = f" {text.lower()} "
    return [theme for theme, kws in settings.TRANSFORMATION_THEMES.items() if _score(blob, kws) >= 1]


def heatmap_domains(text):
    blob = f" {text.lower()} "
    return [dom for dom, kws in settings.HEATMAP_DOMAINS.items() if _score(blob, kws) >= 1]


def extract_team(desc):
    for rx in _TEAM_RES:
        m = rx.search(desc or "")
        if m:
            team = m.group(1).strip()
            if team.lower() not in _GENERIC_TEAM and len(team) >= 5:
                return team
    return ""


def extract_reports_to(desc):
    """The manager's ROLE/title this role reports into (not a personal name — those aren't public)."""
    m = _REPORTS_RE.search(desc or "")
    if not m:
        return ""
    title = re.sub(r"\s+", " ", m.group(1)).strip()
    # Drop single generic words like "Director"/"Manager" with no qualifier.
    if len(title.split()) < 2 and title.lower() in {"director", "manager", "lead", "head", "leader"}:
        return ""
    return title


def extract_manager(desc):
    m = _MANAGER_RE.search(desc or "")
    return m.group(1).strip() if m else ""


# Niche / high-value skills that make a requirement "critical" (hard to fill, strategic).
CRITICAL_SKILLS = {"GenAI", "LLM", "NLP", "data governance", "SAP S/4HANA", "Kubernetes", "Databricks",
                   "Snowflake", "Terraform", "Apache Kafka"}
CRITICAL_TITLE = ["architect", "principal", "head of", "chief", "staff ", "director", "vp ",
                  "distinguished", "lead engineer", "lead data", "tech lead", "platform lead"]


def employment_category(emp_raw, title, desc):
    """Permanent vs contract — the manager's staffing-opportunity signal. Career-portal postings are
    mostly direct/permanent hires; contract/temp/intern are flagged when the posting says so."""
    t = f" {emp_raw} {title} {desc} ".lower()
    if any(w in t for w in ["internship", "intern ", "graduate trainee", "apprentice", "trainee program"]):
        return "Internship"
    if any(w in t for w in ["contract", "contractor", "fixed term", "fixed-term", "temporary",
                            " temp ", "c2h", "contract to hire", "months contract"]):
        return "Contract"
    return "Permanent"


def is_critical(role):
    """A critical requirement: executive leadership, a niche high-value skill, or a hard-to-fill
    senior/architect title — the roles an account team should pay most attention to."""
    if role.get("seniority") == "Executive":
        return True
    if set(role.get("skills", [])) & CRITICAL_SKILLS:
        return True
    t = f" {(role.get('role_title') or '').lower()} "
    return any(w in t for w in CRITICAL_TITLE)


def work_mode(text):
    t = f" {(text or '').lower()} "
    if "hybrid" in t:
        return "Hybrid"
    if "fully remote" in t or "work from home" in t or " wfh " in t or " remote " in t:
        return "Remote"
    if "on-site" in t or "onsite" in t or "in office" in t or "in-office" in t:
        return "Onsite"
    return ""


# Word-boundary match so "India" is detected but the US state "Indiana" / "Indianapolis" is NOT
# (a plain substring test tagged every US-Indiana job as India — a real data-quality bug).
_INDIA_RE = re.compile(r"\b(" + "|".join(re.escape(h) for h in settings.INDIA_HINTS) + r")\b")


def is_india(location):
    return bool(_INDIA_RE.search((location or "").lower()))


def enrich_role(role):
    title = role.get("role_title", "")
    desc = role.get("_description", "")
    role["skills"] = detect_tech(f"{title} {desc}")
    role["competency_cluster"] = competency(title, desc)
    role["location"] = _norm_location(role.get("location", ""))
    role["role_type"] = role_family(title)
    if role["role_type"] == "Other" and role["competency_cluster"] != "Other":
        role["role_type"] = settings.COMPETENCY_FAMILY.get(role["competency_cluster"], "Other")
    role["business_domain"] = business_domain(title, desc)
    role["experience_years"] = experience_years(desc)
    role["seniority"] = seniority(title, role["experience_years"])
    precise = title + " " + " ".join(role["skills"])
    role["themes"] = themes(precise)
    role["heatmap"] = heatmap_domains(precise)
    if not role.get("team"):
        role["team"] = extract_team(desc)
    if not role.get("hiring_manager"):
        role["hiring_manager"] = extract_manager(desc)
    role["reports_to"] = extract_reports_to(desc)
    role["work_mode"] = work_mode(f"{title} {desc}")
    role["employment_category"] = employment_category(role.get("employment_type", ""), title, desc)
    role["critical"] = is_critical(role)
    role.pop("_description", None)
    return role


# ---------- Aggregations (Level 3 inputs) ----------
def aggregate_company(roles, total_roles=None):
    by_comp = Counter(r["competency_cluster"] for r in roles)
    by_family = Counter(r["role_type"] for r in roles)
    by_domain = Counter(r["business_domain"] for r in roles)
    by_seniority = Counter(r["seniority"] for r in roles)
    by_location = Counter(r["location"] for r in roles if r.get("location"))
    theme_counter = Counter()
    tech_counter = Counter()
    heat = Counter()
    for r in roles:
        theme_counter.update(r.get("themes", []))
        tech_counter.update(r.get("skills", []))
        heat.update(r.get("heatmap", []))
    india = sum(1 for r in roles if is_india(r.get("location", "")))

    cluster_detail = {}
    for cluster in by_comp:
        members = [r for r in roles if r["competency_cluster"] == cluster]
        rt = Counter(r["role_type"] for r in members)
        sk = Counter()
        for r in members:
            sk.update(r.get("skills", []))
        cluster_detail[cluster] = {"roles": len(members), "top_role_types": rt.most_common(3),
                                   "top_skills": sk.most_common(5)}
    return {
        "total_open_roles": len(roles),
        "all_roles": total_roles if total_roles is not None else len(roles),
        "india_roles": india,
        "by_competency": by_comp.most_common(), "by_role_type": by_family.most_common(10),
        "by_business_domain": by_domain.most_common(), "by_seniority": by_seniority.most_common(),
        "by_theme": theme_counter.most_common(), "top_locations": by_location.most_common(10),
        "top_tech": tech_counter.most_common(15), "heatmap": dict(heat),
        "cluster_detail": cluster_detail,
    }


def cross_client(all_roles):
    by_family = Counter(r["role_type"] for r in all_roles)
    cloud = {"AWS", "Microsoft Azure", "Google Cloud"}
    key = cloud | {"Python", "SQL", "Power BI", "Tableau", "SAP", "Snowflake", "Databricks"}
    skill_split = {}
    for rt, _ in by_family.most_common(8):
        members = [r for r in all_roles if r["role_type"] == rt]
        c = Counter()
        for r in members:
            for s in r.get("skills", []):
                if s in key:
                    c[s] += 1
        skill_split[rt] = {"roles": len(members), "skills": c.most_common(6)}
    tech = Counter()
    for r in all_roles:
        tech.update(r.get("skills", []))
    # technology combinations (co-occurrence of top techs within a role)
    top = {t for t, _ in tech.most_common(12)}
    combos = Counter()
    for r in all_roles:
        present = sorted(set(r.get("skills", [])) & top)
        for a, b in combinations(present, 2):
            combos[f"{a} + {b}"] += 1
    return {"total_roles": len(all_roles), "by_role_type": by_family.most_common(12),
            "skill_split": skill_split, "top_tech": tech.most_common(15),
            "tech_combos": combos.most_common(8)}


def snapshot(companies_agg):
    """Compact per-company per-month snapshot for month-over-month comparison."""
    out = {}
    for slug, agg in companies_agg.items():
        if not agg:
            continue
        out[slug] = {
            "total": agg["total_open_roles"],
            "heatmap": agg["heatmap"],
            "competency": dict(agg["by_competency"]),
            "tech": dict(agg["top_tech"]),
            "locations": dict(agg["top_locations"]),
        }
    return out
