from collections import Counter

import settings


def _global_tech(snap):
    tech = Counter()
    for data in snap.values():
        tech.update(data.get("tech", {}))
    return tech


def what_changed(snap_now, snap_prev):
    """Month-over-month deltas. snap_prev may be None (baseline month)."""
    if not snap_prev:
        return {"has_prior": False, "rising": [], "declining": [], "new_tech": [], "role_movers": [], "new_locations": []}
    now, prev = _global_tech(snap_now), _global_tech(snap_prev)
    rising, declining, new_tech = [], [], []
    for tech, n in now.most_common():
        p = prev.get(tech, 0)
        if p == 0 and n >= 2:
            new_tech.append((tech, n))
        elif n - p >= 2 and p > 0:
            rising.append((tech, n, p, n - p))
        elif p - n >= 2:
            declining.append((tech, n, p, n - p))
    role_movers = []
    for slug in snap_now:
        n = snap_now[slug]["total"]
        p = (snap_prev.get(slug) or {}).get("total", 0)
        if abs(n - p) >= 5:
            role_movers.append((slug, n, p, n - p))
    new_locations = []
    now_locs = Counter()
    prev_locs = Counter()
    for d in snap_now.values():
        now_locs.update(d.get("locations", {}))
    for d in snap_prev.values():
        prev_locs.update(d.get("locations", {}))
    for loc, n in now_locs.most_common(20):
        if loc not in prev_locs and n >= 2:
            new_locations.append((loc, n))
    return {"has_prior": True, "rising": rising[:8], "declining": declining[:6],
            "new_tech": new_tech[:8], "role_movers": sorted(role_movers, key=lambda x: -abs(x[3]))[:6],
            "new_locations": new_locations[:8]}


def heatmap(companies, snap_prev):
    """Client x technology-domain heatmap: role-demand COUNT per cell (meaningful from day one),
    with a month-over-month trend arrow when a prior month exists."""
    domains = list(settings.HEATMAP_DOMAINS)
    rows = []
    for c in companies:
        agg = c["jobs_agg"]
        prev = (snap_prev or {}).get(c["slug"], {}).get("heatmap", {}) if snap_prev else None
        cells = {}
        for dom in domains:
            if agg is None:
                cells[dom] = {"n": None, "trend": None}
                continue
            now = agg.get("heatmap", {}).get(dom, 0)
            trend = None
            if prev is not None:
                p = prev.get(dom, 0)
                if p == 0 and now > 0:
                    trend = "new"
                elif now > p * 1.15:
                    trend = "up"
                elif now < p * 0.85:
                    trend = "down"
                else:
                    trend = "flat"
            cells[dom] = {"n": now, "trend": trend}
        rows.append({"company": c["name"], "cells": cells})
    return {"domains": domains, "rows": rows, "has_prior": snap_prev is not None}


def tech_radar(cross):
    """#17 Technology Radar: group detected technologies into platform/vendor categories with
    adoption counts (how many roles demand each group) and the leading members."""
    if not cross:
        return []
    tech = dict(cross["top_tech"])
    # include the full tech counter if present
    rows = []
    for group, members in settings.TECH_RADAR_GROUPS.items():
        present = [(m, tech.get(m, 0)) for m in members if tech.get(m, 0)]
        total = sum(n for _, n in present)
        if total:
            rows.append({"group": group, "adoption": total,
                         "members": sorted(present, key=lambda x: -x[1])[:6]})
    return sorted(rows, key=lambda r: -r["adoption"])


def tech_demand(cross):
    """Page 3 inputs: top categories, emerging skills, vendor mentions, combinations."""
    if not cross:
        return None
    return {"top_tech": cross["top_tech"], "tech_combos": cross["tech_combos"]}


def sector_intelligence(companies):
    sectors = {}
    for c in companies:
        agg = c["jobs_agg"]
        entry = sectors.setdefault(c["sector"], {"companies": [], "themes": Counter(), "competency": Counter()})
        entry["companies"].append(c["name"])
        if agg:
            entry["themes"].update(dict(agg["by_theme"]))
            entry["competency"].update(dict(agg["by_competency"]))
    out = []
    for sector, d in sectors.items():
        out.append({"sector": sector, "companies": d["companies"],
                    "top_themes": d["themes"].most_common(3),
                    "top_competency": [c for c, _ in d["competency"].most_common(3) if c != "Other"]})
    return out


def talent_intelligence(all_roles, cross):
    if not all_roles:
        return None
    locations = Counter(r["location"] for r in all_roles if r.get("location"))
    hybrid = Counter()
    for r in all_roles:
        if len(r.get("heatmap", [])) >= 2:
            hybrid["+".join(sorted(r["heatmap"])[:2])] += 1
    hard = [(rt, n) for rt, n in cross["by_role_type"] if rt not in ("Other", "Software Engineer")][:6]
    return {"concentrated_locations": locations.most_common(8),
            "hybrid_profiles": hybrid.most_common(6),
            "in_demand_role_families": hard,
            "skill_combos": cross["tech_combos"][:6]}
