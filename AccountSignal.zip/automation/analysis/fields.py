from collections import defaultdict

import settings
from analysis import classify


def build_bundle(company, news_items, filings, jobs_data, month):
    grouped = defaultdict(list)
    for item in news_items:
        grouped[item["field"]].append(item)
    for items in grouped.values():
        # Lead with first-party, then correlation score, then dated/recent (news ranking is internal —
        # it changes ordering, not the UI layout).
        items.sort(key=lambda x: (x.get("official", False), x.get("score", 0),
                                  x.get("dated", False), x.get("published", ""), x["title"]), reverse=True)

    roles = jobs_data["roles"] if jobs_data else []
    jobs_agg = classify.aggregate_company(roles, (jobs_data or {}).get("total_roles")) if roles else None

    return {
        "company": company["name"],
        "slug": company["slug"],
        "sector": company["sector"],
        "listing": company["listing"],
        "month": month.key,
        "month_label": month.label,
        "fields": {key: grouped.get(key, []) for key in settings.FIELDS},
        "filings": filings,
        "jobs": jobs_data,
        "jobs_agg": jobs_agg,
    }


def hiring_stats_text(bundle):
    agg = bundle["jobs_agg"]
    if not agg:
        return "No job-board data available for this client (careers portal not accessible)."
    parts = [f"{agg['total_open_roles']} IT/digital roles posted in the last {settings.JOB_RECENCY_DAYS} days "
             f"(of {agg['all_roles']} total open); {agg['india_roles']} in India."]
    parts.append("By competency: " + ", ".join(f"{c} {n}" for c, n in agg["by_competency"]) + ".")
    parts.append("Top role types: " + ", ".join(f"{r} {n}" for r, n in agg["by_role_type"][:5]) + ".")
    parts.append("Top skills: " + ", ".join(f"{s} {n}" for s, n in agg["top_tech"][:6]) + ".")
    return " ".join(parts)


def field_items(bundle, field_key, limit=6):
    rows = bundle["fields"].get(field_key, [])[:limit]
    out = [{"title": r["title"], "url": r["url"], "published": r.get("published", "")} for r in rows]
    if field_key == "money_metrics":
        for f in bundle["filings"][:4]:
            out.append({"title": f"[{f['form']}] {f['description']}".strip(), "url": f["url"], "published": f["filed"]})
    return out
