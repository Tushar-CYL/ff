"""Strategic account signals: partnerships, change-of-vision, and tool-gravitation.

These are the "true insights" an account manager reads first — WHO a client is partnering with,
WHERE its strategy is shifting, and WHICH platforms/vendors it is gravitating toward (e.g.
"Cargill -> Neo4j"). Signals are evidence-grounded: a vendor only surfaces when it is actually
named in the hiring skills, the news/filings, or the strategy research. Each signal carries the
source and the matching EY opportunity so a manager can act without re-reading everything.

Hiring is India-only (filtered upstream); partnership / vision / tool signals are GLOBAL — a
client's alliances and platform bets are set globally, not per-GCC. The functions here accept a
simple evidence blob [{text, url}] so they work BOTH from the live pipeline (raw news/filings) and
from an already-generated report_<month>.json (field summaries), with no mandatory LLM call."""
import html
import re
from collections import Counter

# Canonical vendor/platform -> the EY angle it implies. The partnership-relevant names an alliance
# team watches (graph, data, AI, automation, ERP, cloud, CRM, process...).
VENDOR_EY = {
    "Neo4j": "Graph / knowledge-graph data modelling and implementation",
    "Palantir": "Foundry data-integration and operational-analytics delivery",
    "Databricks": "Lakehouse data-platform build and MLOps",
    "Snowflake": "Cloud data-platform and analytics modernization",
    "Microsoft Fabric": "Fabric analytics migration and BI transformation",
    "Power BI": "BI / analytics modernization",
    "Tableau": "BI / analytics modernization",
    "SAP": "SAP S/4HANA / ERP transformation and data migration",
    "SAP S/4HANA": "S/4HANA migration, data quality and reconciliation",
    "Salesforce": "Salesforce / CRM programme delivery",
    "ServiceNow": "ServiceNow / ITSM and workflow automation",
    "Workday": "Workday HCM / finance deployment and integration",
    "Oracle": "Oracle ERP / Fusion transformation",
    "Microsoft Azure": "Azure cloud migration and platform engineering",
    "AWS": "AWS cloud migration and platform engineering",
    "Google Cloud": "Google Cloud migration and data engineering",
    "UiPath": "Intelligent-automation operating model and delivery",
    "Dataiku": "Data-science platform enablement and MLOps",
    "Informatica": "Data integration, governance and master-data design",
    "Collibra": "Data-governance and catalog operating model",
    "Confluent": "Event-streaming / real-time data-integration build",
    "Apache Kafka": "Event-streaming / real-time data-integration build",
    "MongoDB": "Modern application-data platform engineering",
    "Celonis": "Process-mining and operational-excellence delivery",
    "OpenAI": "Enterprise GenAI strategy, architecture and governance",
    "Anthropic": "Enterprise GenAI strategy, architecture and governance",
    "NVIDIA": "AI infrastructure and accelerated-computing enablement",
    "IBM": "Platform migration and enterprise integration",
    "Google": "Cloud, data and AI programme delivery",
    "Microsoft": "Cloud, data and AI programme delivery",
    "GenAI": "Enterprise GenAI strategy, architecture and governance",
    "Data governance": "Data office, stewardship and MDM design",
    "Kubernetes": "Platform-engineering and containerisation delivery",
}

# Detection terms (lowercase, surrounded by spaces when matched) -> canonical vendor. Longer terms
# are tested first so "sap s/4hana" wins over "sap", "google cloud" over "google".
VENDOR_TERMS = {
    "neo4j": "Neo4j", "palantir": "Palantir", "foundry": "Palantir",
    "databricks": "Databricks", "snowflake": "Snowflake",
    "microsoft fabric": "Microsoft Fabric", "ms fabric": "Microsoft Fabric",
    "power bi": "Power BI", "powerbi": "Power BI", "tableau": "Tableau",
    "sap s/4hana": "SAP S/4HANA", "s/4hana": "SAP S/4HANA", "s4hana": "SAP S/4HANA", "sap": "SAP",
    "salesforce": "Salesforce", "servicenow": "ServiceNow", "workday": "Workday",
    "oracle": "Oracle", "microsoft azure": "Microsoft Azure", "azure": "Microsoft Azure",
    "aws": "AWS", "amazon web services": "AWS", "google cloud": "Google Cloud", "gcp": "Google Cloud",
    "uipath": "UiPath", "dataiku": "Dataiku", "informatica": "Informatica", "collibra": "Collibra",
    "confluent": "Confluent", "kafka": "Apache Kafka", "mongodb": "MongoDB", "celonis": "Celonis",
    "openai": "OpenAI", "anthropic": "Anthropic", "nvidia": "NVIDIA",
    "generative ai": "GenAI", "genai": "GenAI", "data governance": "Data governance",
    "kubernetes": "Kubernetes",
}
_TERMS_SORTED = sorted(VENDOR_TERMS.items(), key=lambda kv: -len(kv[0]))

# Words that mark a sentence as a real partnership / alliance / platform-bet (not generic news).
PARTNER_CUES = re.compile(
    r"\b(partner(?:s|ship|ed|ing)?|alliance|collaborat\w+|tie-?up|joins? forces|teams? up|"
    r"selects?|chose|chosen|adopts?|deploys?|migrat\w+|powered by|standardi[sz]es? on|"
    r"rolls? out|signs?|deal|agreement|integrat\w+ with)\b", re.I)
VISION_CUES = re.compile(
    r"\b(strateg(?:y|ic)|transformation|restructur\w+|reorganis\w+|reorganiz\w+|pivot|"
    r"roadmap|invests?|investment|expands?|expansion|launches?|bets? on|"
    r"double[-\s]?down|digital[-\s]?first|ai[-\s]?first)\b", re.I)


def _vendors_in(text):
    """Canonical vendors named in a blob of text (deduped, longest-match preferred)."""
    low = " " + re.sub(r"[^a-z0-9/+ ]", " ", (text or "").lower()) + " "
    found = []
    for term, canon in _TERMS_SORTED:
        if f" {term} " in low or f" {term}," in low or f" {term}." in low:
            if canon not in found:
                found.append(canon)
    return found


def _clean(text):
    """Un-escape HTML entities, drop tags, strip a trailing ' - Publisher' / ' | Publisher' news
    suffix, and collapse whitespace — so Google-News variants of one headline look identical."""
    t = html.unescape(re.sub(r"<[^>]+>", " ", text or ""))
    t = t.replace("\xa0", " ")
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"\s+[-|–]\s+[A-Z][\w.&' ]{2,40}$", "", t)  # trailing " - Reuters" / " | Yahoo Finance"
    t = re.sub(r"\s*(?:\.\.\.|…)\s*$", "", t)              # drop a trailing truncation ellipsis
    return t.strip()


# Stop-words so two sentences describing the SAME event (reworded) are detected as duplicates.
_SIG_STOP = {"the", "and", "for", "with", "from", "that", "this", "was", "were", "have", "has", "its",
             "into", "will", "been", "their", "they", "are", "our", "inc", "ltd", "plc", "per", "via",
             "amid", "over", "than", "then", "said", "reported", "announced", "widely", "also", "new",
             "company", "companies", "including", "coverage", "multiple", "outlets", "separately"}


def _sig_tokens(sent):
    return {w for w in re.findall(r"[a-z0-9$]+", (sent or "").lower())
            if len(w) > 3 and w not in _SIG_STOP}


def _too_similar(toks, kept_sets):
    """True if `toks` restates an already-kept signal (high word overlap / near-subset)."""
    for kt in kept_sets:
        if not toks or not kt:
            continue
        inter = len(toks & kt)
        if inter and inter / len(toks | kt) >= 0.5:
            return True
        if inter >= 0.8 * min(len(toks), len(kt)):  # one is largely contained in the other
            return True
    return False


# Publishers / geographies that are NOT the "other party" of a deal — excluded from entity dedup.
_NOT_ENTITY = {"reuters", "bloomberg", "stat", "cnbc", "yahoo", "forbes", "england", "britain", "india",
               "europe", "america", "china", "japan", "nyse", "nasdaq", "lse", "rns", "sec", "the",
               "group", "news", "plc", "inc", "ltd", "company", "global", "international"}
# A person's role/bio line (e.g. "Director, … at AstraZeneca") — not a company development.
_BIO = re.compile(r"^(director|head|manager|vp|vice president|chief|lead|senior|principal|associate|"
                  r"global|regional|country|president|officer)\b", re.I)


def _entities(sent, company):
    """Outside parties named in the sentence (first token of each proper noun), minus the company itself
    and minus publishers/geographies — so two sentences about the SAME counterparty collapse."""
    own = {w for n in [company.get("name", "")] + list(company.get("aliases") or [])
           for w in re.findall(r"[a-z]+", n.lower())}
    ents = set()
    for m in re.findall(r"\b([A-Z][A-Za-z&.]{2,}(?:\s+[A-Z][A-Za-z&.]+){0,3})\b", sent or ""):
        head = re.sub(r"[^a-z]", "", m.split()[0].lower())
        if head and head not in own and head not in _NOT_ENTITY and len(head) > 2:
            ents.add(head)
    return ents


_ROLE_WORD = re.compile(r"\b(lead|head|director|manager|officer|analyst|associate|specialist|"
                        r"engineer|consultant|president|vp|partner|intern|recruiter|advisor)\b", re.I)


def _is_bio(sent, company=None):
    s = (sent or "").strip()
    if _BIO.match(s) and " at " in s:
        return True
    # A person's affiliation line: "<role words> ... at <Company>" with no development verb.
    if company and _ROLE_WORD.search(s):
        for a in [company.get("name", "")] + list(company.get("aliases") or []):
            if a and re.search(r"\bat\s+" + re.escape(a) + r"\b\s*$", s, re.I):
                return True
    return False


# Don't split a sentence at these abbreviation periods ("Dr. Reddy's", "U.S.", "Inc.").
_ABBR = ["Dr", "Mr", "Mrs", "Ms", "Prof", "Inc", "Corp", "Co", "Ltd", "St", "Jr", "Sr", "vs", "No", "U.S", "U.K"]
_ABBR_RE = re.compile(r"\b(" + "|".join(a.replace(".", r"\.") for a in _ABBR) + r")\.")


def _sentences(text):
    protected = _ABBR_RE.sub(lambda m: m.group(1) + "\x00", text or "")
    parts = re.split(r"(?<=[.!?])\s+|\n+", protected)
    return [s for s in (_clean(p.replace("\x00", ".")) for p in parts) if len(s) > 20]


def _dedup_key(sent):
    """Alphanumeric prefix — collapses headline variants (' - Reuters' vs '&nbsp; Reuters')."""
    return re.sub(r"[^a-z0-9]", "", sent.lower())[:60]


def _canon_skill(skill):
    """Map a JD skill string to a VENDOR_EY vendor if it is one we track for gravitation."""
    s = (skill or "").strip()
    if s in VENDOR_EY:
        return s
    v = _vendors_in(s)
    return v[0] if v else None


def tool_gravitation(agg, evidence, top=6):
    """Which platforms/vendors a client is gravitating toward, from BOTH the demand side (hiring
    skills) and the market side (global news/strategy mentions). evidence = [{text, url}].
    Returns [{vendor, hiring, mentions, ey_angle, source}] ranked by combined weight."""
    hiring = Counter()
    if agg:
        for skill, n in agg.get("top_tech", []):
            canon = _canon_skill(skill)
            if canon:
                hiring[canon] += n
    mentions, src = Counter(), {}
    for ev in evidence or []:
        for v in _vendors_in(ev.get("text", "")):
            mentions[v] += 1
            src.setdefault(v, ev.get("url", ""))
    rows = []
    for v in set(hiring) | set(mentions):
        rows.append({
            "vendor": v, "hiring": hiring.get(v, 0), "mentions": mentions.get(v, 0),
            "ey_angle": VENDOR_EY.get(v, "Platform enablement and delivery"),
            "source": src.get(v, ""),
            "_w": hiring.get(v, 0) + mentions.get(v, 0) * 3,  # a named market bet outweighs a JD skill
        })
    rows.sort(key=lambda r: -r["_w"])
    for r in rows:
        r.pop("_w", None)
    return rows[:top]


def partnership_signals(company, evidence, max_signals=6):
    """Named partnerships / vision shifts / platform bets. evidence = [{text, url}] from the GLOBAL
    partnership + vision + expansion + financial fields, filings, and strategy research. Each signal:
    {type, headline, vendor, source, ey_opportunity}. Evidence-grounded, deduped, partnerships first."""
    out, seen, kept_tokens, kept_entities = [], set(), [], []
    # Build a company entity vocabulary from the capitalized proper nouns across ALL evidence, so a party
    # named lower-case in one headline (e.g. "kenvue") is still matched to "Kenvue" elsewhere and the
    # duplicate collapses (news feeds are inconsistently cased).
    vocab = set()
    for ev in evidence or []:
        for sent in _sentences(ev.get("text", "")):
            vocab |= _entities(sent, company)

    def ents_of(sent):
        return {w for w in re.findall(r"[a-z0-9]+", sent.lower()) if w in vocab}

    for ev in evidence or []:
        url = ev.get("url", "")
        for sent in _sentences(ev.get("text", "")):
            if _is_bio(sent, company) or len(sent.split()) < 6:  # job-title / short heading fragment — not a development
                continue
            is_partner = bool(PARTNER_CUES.search(sent))
            is_vision = bool(VISION_CUES.search(sent))
            if not (is_partner or is_vision):
                continue
            vendors = _vendors_in(sent)
            key = _dedup_key(sent)
            toks = _sig_tokens(sent)
            ents = ents_of(sent)
            # Skip if it's an exact dupe, a reworded dupe, OR names the same outside party as a kept
            # signal (e.g. five variants of the AstraZeneca–Summit deal collapse to one).
            same_party = bool(ents) and any(ents & ke for ke in kept_entities)
            if key in seen or _too_similar(toks, kept_tokens) or same_party:
                continue
            if is_partner:                        # a named alliance/deal — vendor-tagged when present
                stype, vend = "Partnership", (vendors[0] if vendors else "")
            elif vendors:                         # a platform named without an explicit partner verb
                stype, vend = "Tool gravitation", vendors[0]
            elif is_vision:                       # strategy shift, no vendor named
                stype, vend = "Vision / change", ""
            else:
                continue
            if vend:
                ey = VENDOR_EY.get(vend, "Platform enablement and delivery")
            elif stype == "Partnership":
                ey = "Explore where EY can enable or extend this partnership"
            else:
                ey = "Shape a point of view aligned to the stated direction"
            seen.add(key)
            kept_tokens.append(toks)
            kept_entities.append(ents)
            out.append({"type": stype, "headline": tidy_summary(sent[:220]), "vendor": vend,
                        "source": url, "ey_opportunity": ey})
    rank = {"Partnership": 0, "Tool gravitation": 1, "Vision / change": 2}
    out.sort(key=lambda s: rank.get(s["type"], 9))
    return out[:max_signals]


# ---- Evidence builders (so Excel + signals run off either live data or a stored report) ----

# Evidence for partnership / vision / tool signals is drawn ONLY from the GLOBAL market record, and
# specifically from the CLEAN synthesized field summaries + external strategy-source headlines — NOT raw
# news/web content (which carries job-description boilerplate, bios and taglines that mis-tag as
# "Partnership") and NOT the hiring-derived takeaways/strategy paragraph (which describe India hiring).

def _evidence_from_fields(fields, strategy_sources):
    ev = []
    for key in ("partnerships", "vision_strategy", "expansion", "money_metrics"):
        f = fields.get(key) or {}
        summ, srcs = f.get("summary") or "", f.get("sources") or []
        if summ and summ != "No material developments this period.":
            ev.append({"text": summ, "url": srcs[0] if srcs else ""})
    for s in strategy_sources or []:
        if isinstance(s, dict) and s.get("title"):
            ev.append({"text": s["title"], "url": s.get("url", "")})
    return ev


def evidence_from_live(synthesis, strategy_sources):
    """During a pipeline run: use the CLEAN synthesized field summaries (synthesize() output) plus the
    external strategy-source headlines. Same shape/quality as the stored-report path below."""
    return _evidence_from_fields((synthesis or {}).get("fields") or {}, strategy_sources)


_FIELD_PRIORITY = ["hiring", "partnerships", "money_metrics", "expansion", "vision_strategy"]


def strip_signals_from_fields(fields, signals, company=None):
    """Remove from the market-intelligence field summaries any sentence that is already shown in the
    'strategic signals' card, so the same line never appears in two places on the dashboard. The signals
    card keeps the deals/vendor-bets/vision; Market intelligence keeps the synthesis + any OTHER context.
    A field whose only sentence was a signal becomes 'No material developments this period.'."""
    if not fields or not signals:
        return fields
    company = company or {}
    sig_toks = [_sig_tokens(s.get("headline", "")) for s in signals]
    sig_ents = [_entities(s.get("headline", ""), company) for s in signals]
    for k, f in fields.items():
        if k == "hiring":
            continue
        summ = (f or {}).get("summary") or ""
        if not summ or summ == "No material developments this period.":
            continue
        kept = []
        for s in _sentences(summ):
            toks, ents = _sig_tokens(s), _entities(s, company)
            dup = any(st and toks and len(toks & st) / len(toks | st) >= 0.45 for st in sig_toks) \
                or any(ents and se and not (ents - se) for se in sig_ents)
            if dup:
                continue
            kept.append(s)
        f = dict(f)
        f["summary"] = " ".join(kept) if kept else "No material developments this period."
        fields[k] = f
    return fields


def tidy_summary(s):
    """Tidy a field summary that fell back to a raw news headline: keep the first substantive clause (not
    a '; '-joined pile of titles), drop a '- Publisher' / '| Publisher' tag and any trailing ellipsis,
    and end it as a sentence. A clean LLM sentence passes through essentially unchanged."""
    if not s or s == "No material developments this period.":
        return s
    parts = [p.strip() for p in re.split(r";\s+", s) if p.strip()]
    s = parts[0] if parts else s
    s = _clean(s)                                          # strips trailing ' - Publisher' / ellipsis
    s = re.sub(r"\s+[-–|]\s+\S*\.\w{2,4}\b.*$", "", s)     # strip trailing ' - domain.com …' (any case)
    s = re.sub(r"\s+[-–|]\s+[A-Za-z][\w.&' ]{2,30}$", "", s).strip()  # strip trailing publisher (any case)
    if s and s[0].islower():                               # some feeds arrive all-lowercase
        s = s[0].upper() + s[1:]
    if s and s[-1] not in ".!?":
        s += "."
    return s


def dedupe_field_summaries(fields, company=None):
    """De-duplicate the 5 market-intelligence field summaries so the SAME development isn't restated in
    several fields (the LLM often puts one big event into Vision + Partnerships + Financial + Expansion).
    A sentence is dropped only when every named party in it is already covered by a higher-priority
    field — so a pure restatement is removed, but a sentence that adds a NEW party/fact (e.g. a separate
    regulatory milestone) is kept. A field left with nothing becomes 'No material developments…'."""
    if not fields:
        return fields
    company = company or {}
    seen_ents, seen_toks = set(), []
    for k in [f for f in _FIELD_PRIORITY if f in fields] + [f for f in fields if f not in _FIELD_PRIORITY]:
        f = fields.get(k) or {}
        summ = f.get("summary") or ""
        if k == "hiring" or not summ or summ == "No material developments this period.":
            continue  # hiring is distinct stats — never dedupe it against the news fields
        summ = tidy_summary(summ)  # clean raw-headline fallbacks before de-duplicating
        kept = []
        for s in _sentences(summ):
            if len(s.split()) < 4:
                continue
            ents = _entities(s, company)
            toks = _sig_tokens(s)
            same_party = bool(ents) and not (ents - seen_ents)          # only already-covered parties
            reworded = any(st and toks and len(toks & st) / len(toks | st) >= 0.3 for st in seen_toks)
            if same_party or reworded:                                  # a restatement of a covered event
                continue
            seen_ents |= ents
            seen_toks.append(toks)
            kept.append(s)
        f = dict(f)
        f["summary"] = " ".join(kept) if kept else "No material developments this period."
        fields[k] = f
    return fields


def evidence_from_report_company(c):
    """Build the evidence blob from an ALREADY-GENERATED report company (its field summaries + external
    strategy-source headlines). Lets Excel + signals run off report_<month>.json with no re-scrape."""
    return _evidence_from_fields(c.get("fields") or {}, c.get("strategy_sources"))
