from calendar import monthrange
from datetime import datetime, date, timezone
from email.utils import parsedate_to_datetime


class Month:
    def __init__(self, value):
        self.year, self.month = (int(p) for p in value.split("-"))
        self.start = date(self.year, self.month, 1)
        self.end = date(self.year, self.month, monthrange(self.year, self.month)[1])

    @property
    def key(self):
        return f"{self.year:04d}-{self.month:02d}"

    @property
    def label(self):
        return self.start.strftime("%B %Y")

    def contains(self, value):
        parsed = parse_date(value)
        if parsed is None:
            return None
        return self.start <= parsed <= self.end


def parse_date(value):
    if not value:
        return None
    text = str(value).strip()
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()
    except ValueError:
        pass
    try:
        return parsedate_to_datetime(text).date()
    except (TypeError, ValueError):
        return None


def now_stamp():
    return datetime.now(timezone.utc).date().isoformat()
