import os
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "output"


def _load_env():
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env()

NEWS_SOURCE = os.environ.get("NEWS_SOURCE", "gdelt")
# Only keep job postings published within this many days (fresh / "last month" hiring).
JOB_RECENCY_DAYS = int(os.environ.get("JOB_RECENCY_DAYS", "31"))
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY", "")
EYQ_ENDPOINT = os.environ.get("EYQ_INCUBATOR_ENDPOINT", "")
EYQ_KEY = os.environ.get("EYQ_INCUBATOR_KEY", "")
EYQ_MODEL = os.environ.get("EYQ_MODEL", "gpt-5.2")
EYQ_API_VERSION = os.environ.get("EYQ_API_VERSION", "2023-05-15")
CONTACT_EMAIL = os.environ.get("CONTACT_EMAIL", "client-intelligence@example.com")
# Bright Data Scraping Browser (CDP endpoint) — routes Playwright scraping through an unblocked,
# CAPTCHA-handling remote browser for bot-walled / virtualized career sites. Empty = use local chromium.
BRIGHTDATA_CDP = os.environ.get("BRIGHTDATA_CDP", "")
PEOPLEDATA_PROVIDER = os.environ.get("PEOPLEDATA_PROVIDER", "")
PEOPLEDATA_API_KEY = os.environ.get("PEOPLEDATA_API_KEY", "")
TINYFISH_API_KEY = os.environ.get("TINYFISH_API_KEY", "")

# EY GCC hub regions (from the account book). A client's India delivery centre sits in one of these.
REGIONS = {"BLR": "Bengaluru", "Hyd": "Hyderabad", "West": "West (Mumbai / Pune)", "": "—"}

COMPANIES = [
    {"name": "Unilever", "slug": "unilever", "sector": "Consumer Products", "listing": "LSE and NYSE",
     "region": "", "aliases": ["Unilever", "Hindustan Unilever", "HUL"], "sec_cik": "0000217410",
     "domain": "unilever.com",
     # careers.unilever.com is a Radancy-style site with full JSON-LD JDs — more India coverage than the
     # Workday experienced-professionals API, which only surfaced ~9 India roles.
     "careers": {"type": "radancy", "domain": "careers.unilever.com", "url": "https://careers.unilever.com"}},
    {"name": "Cargill", "slug": "cargill", "sector": "Agriculture & Food", "listing": "privately held",
     "region": "BLR", "aliases": ["Cargill"], "sec_cik": None, "domain": "cargill.com",
     "careers": {"type": "radancy", "domain": "careers.cargill.com", "url": "https://careers.cargill.com"}},
    {"name": "Takeda", "slug": "takeda", "sector": "Pharmaceuticals", "listing": "NYSE (TAK)",
     "region": "BLR", "aliases": ["Takeda"], "sec_cik": "0001395064", "domain": "takeda.com",
     "careers": {"type": "radancy", "domain": "jobs.takeda.com", "url": "https://jobs.takeda.com"}},
    {"name": "Tesco", "slug": "tesco", "sector": "Retail", "listing": "LSE",
     "region": "BLR", "aliases": ["Tesco"], "sec_cik": None, "rns_ticker": "TSCO", "domain": "tesco.com",
     # Avature, filtered to the "Tesco India" (Bengaluru GCC) facet so we get the relevant tech
     # roles directly instead of paging Tesco's huge global retail board.
     "careers": {"type": "avature", "base": "https://careers.tesco.com", "path": "/en_GB/careers",
                 "search": "SearchJobs/?12328=%5B587056%5D&12328_format=7246&listFilterMode=1",
                 "url": "https://www.tesco-careers.com"}},
    {"name": "Nike", "slug": "nike", "sector": "Consumer / Apparel", "listing": "NYSE (NKE)",
     "region": "BLR", "aliases": ["Nike"], "sec_cik": "0000320187", "domain": "nike.com",
     # careers.nike.com custom SPA: capture its India-filtered /api/get-jobs responses (full JD). Its
     # Workday board surfaced 0 India via the cxs API, but the public site exposes 80 India roles.
     "careers": {"type": "nike",
                 "url": "https://careers.nike.com/jobs?location_name=India&location_type=4"}},
    {"name": "BP", "slug": "bp", "sector": "Energy", "listing": "LSE / NYSE",
     "region": "West", "aliases": ["BP", "bp plc"], "sec_cik": None, "domain": "bp.com",
     "careers": {"type": "workday", "tenant": "bpinternational", "pod": "wd3", "site": "bpCareers",
                 "url": "https://careers.bp.com"}},
    {"name": "TIAA", "slug": "tiaa", "sector": "Financial Services", "listing": "privately held",
     "region": "West", "aliases": ["TIAA"], "sec_cik": None, "domain": "tiaa.org",
     "careers": {"type": "workday", "tenant": "tiaa", "pod": "wd1", "site": "Search",
                 "url": "https://careers.tiaa.org"}},
    {"name": "Carrier", "slug": "carrier", "sector": "HVAC / Industrial", "listing": "NYSE (CARR)",
     "region": "", "aliases": ["Carrier", "Carrier Global"], "sec_cik": "0001783180", "domain": "carrier.com",
     "careers": {"type": "workday", "tenant": "carrier", "pod": "wd5", "site": "jobs",
                 "url": "https://jobs.carrier.com"}},
    {"name": "Diageo", "slug": "diageo", "sector": "Beverages", "listing": "LSE / NYSE (DEO)",
     "region": "BLR", "aliases": ["Diageo", "United Spirits", "USL"], "sec_cik": None,
     "rns_ticker": "DGE", "domain": "diageo.com",
     "careers": {"type": "workday", "tenant": "diageo", "pod": "wd3", "site": "Diageo_Careers",
                 "url": "https://careers.diageo.com"}},
    {"name": "Adobe", "slug": "adobe", "sector": "Technology / Software", "listing": "NASDAQ (ADBE)",
     "region": "BLR", "aliases": ["Adobe", "Adobe Systems"], "sec_cik": "0000796343", "domain": "adobe.com",
     "careers": {"type": "phenom", "domain": "careers.adobe.com", "url": "https://careers.adobe.com"}},
    {"name": "Lowe's", "slug": "lowes", "sector": "Retail", "listing": "NYSE (LOW)",
     "region": "BLR", "aliases": ["Lowe's", "Lowes"], "sec_cik": "0000060667", "domain": "lowes.com",
     "careers": {"type": "phenom", "domain": "talent.lowes.com", "url": "https://talent.lowes.com"}},
    {"name": "Thermo Fisher", "slug": "thermo-fisher", "sector": "Life Sciences / Instruments",
     "listing": "NYSE (TMO)", "region": "BLR", "aliases": ["Thermo Fisher", "Thermo Fisher Scientific"],
     "sec_cik": "0000097745", "domain": "thermofisher.com",
     "careers": {"type": "phenom", "domain": "jobs.thermofisher.com", "url": "https://jobs.thermofisher.com"}},
    {"name": "Procter & Gamble", "slug": "pg", "sector": "Consumer Goods", "listing": "NYSE (PG)",
     "region": "Hyd", "aliases": ["Procter & Gamble", "P&G"], "sec_cik": "0000080424", "domain": "pg.com",
     "careers": {"type": "phenom", "domain": "www.pgcareers.com", "url": "https://www.pgcareers.com"}},
    {"name": "GSK", "slug": "gsk", "sector": "Pharmaceuticals", "listing": "LSE / NYSE (GSK)",
     "region": "BLR", "aliases": ["GSK", "GlaxoSmithKline"], "sec_cik": None, "rns_ticker": "GSK",
     "domain": "gsk.com",
     "careers": {"type": "phenom", "domain": "jobs.gsk.com", "url": "https://jobs.gsk.com"}},
    {"name": "DaVita", "slug": "davita", "sector": "Healthcare", "listing": "NYSE (DVA)",
     "region": "BLR", "aliases": ["DaVita"], "sec_cik": "0000927066", "domain": "davita.com",
     "careers": {"type": "phenom", "domain": "careers.davita.com", "url": "https://careers.davita.com"}},
    {"name": "AstraZeneca", "slug": "astrazeneca", "sector": "Pharmaceuticals", "listing": "LSE / NASDAQ (AZN)",
     "region": "BLR", "aliases": ["AstraZeneca"], "sec_cik": None, "rns_ticker": "AZN", "domain": "astrazeneca.com",
     "careers": {"type": "radancy", "domain": "careers.astrazeneca.com", "url": "https://careers.astrazeneca.com"}},
    {"name": "Chevron", "slug": "chevron", "sector": "Energy", "listing": "NYSE (CVX)",
     "region": "BLR", "aliases": ["Chevron"], "sec_cik": "0000093410", "domain": "chevron.com",
     "careers": {"type": "radancy", "domain": "careers.chevron.com", "url": "https://careers.chevron.com"}},
    {"name": "Flex", "slug": "flex", "sector": "Electronics Manufacturing", "listing": "NASDAQ (FLEX)",
     "region": "BLR", "aliases": ["Flex", "Flextronics"], "sec_cik": "0000866374", "domain": "flex.com",
     "careers": {"type": "workday", "tenant": "flextronics", "pod": "wd1", "site": "Careers",
                 "url": "https://flex.com/careers"}},
    {"name": "7-Eleven", "slug": "7-eleven", "sector": "Retail", "listing": "privately held (SEI)",
     "region": "BLR", "aliases": ["7-Eleven", "7-Eleven Inc"], "sec_cik": None, "domain": "7-eleven.com",
     "careers": {"type": "radancy", "domain": "careers.7-eleven.com", "url": "https://careers.7-eleven.com"}},
    {"name": "Qualcomm", "slug": "qualcomm", "sector": "Semiconductors", "listing": "NASDAQ (QCOM)",
     "region": "Hyd", "aliases": ["Qualcomm"], "sec_cik": "0000804328", "domain": "qualcomm.com",
     "careers": {"type": "eightfold", "host": "careers.qualcomm.com", "domain": "qualcomm.com",
                 "url": "https://careers.qualcomm.com"}},
    {"name": "Applied Materials", "slug": "applied-materials", "sector": "Semiconductors / Equipment",
     "listing": "NASDAQ (AMAT)", "region": "BLR", "aliases": ["Applied Materials"],
     "sec_cik": "0000006951", "domain": "appliedmaterials.com",
     "careers": {"type": "eightfold", "host": "careers.appliedmaterials.com", "domain": "appliedmaterials.com",
                 "url": "https://careers.appliedmaterials.com"}},
    {"name": "Colgate-Palmolive", "slug": "colgate", "sector": "Consumer Goods", "listing": "NYSE (CL)",
     "region": "West", "aliases": ["Colgate-Palmolive", "Colgate"], "sec_cik": "0000021665", "domain": "colgatepalmolive.com",
     "careers": {"type": "successfactors", "base": "https://jobs.colgate.com", "url": "https://jobs.colgate.com"}},
    {"name": "Alstom", "slug": "alstom", "sector": "Rail / Transport", "listing": "Euronext (ALO)",
     "region": "BLR", "aliases": ["Alstom"], "sec_cik": None, "domain": "alstom.com",
     "careers": {"type": "successfactors", "base": "https://jobsearch.alstom.com", "url": "https://jobsearch.alstom.com"}},
    {"name": "BCG", "slug": "bcg", "sector": "Management Consulting", "listing": "privately held",
     "region": "West", "aliases": ["BCG", "Boston Consulting Group"], "sec_cik": None, "domain": "bcg.com",
     "careers": {"type": "phenom", "domain": "careers.bcg.com", "url": "https://careers.bcg.com"}},
    {"name": "Microsoft", "slug": "microsoft", "sector": "Technology / Software", "listing": "NASDAQ (MSFT)",
     "region": "Hyd", "aliases": ["Microsoft"], "sec_cik": "0000789019", "domain": "microsoft.com",
     "careers": {"type": "eightfold", "host": "apply.careers.microsoft.com", "domain": "microsoft.com",
                 "url": "https://careers.microsoft.com"}},
    {"name": "Estee Lauder", "slug": "estee-lauder", "sector": "Consumer / Beauty", "listing": "NYSE (EL)",
     "region": "BLR", "aliases": ["Estee Lauder", "The Estee Lauder Companies", "ELC"], "sec_cik": "0001001250",
     "domain": "elcompanies.com",
     "careers": {"type": "eightfold", "host": "careers.elcompanies.com", "domain": "elcompanies.com",
                 "url": "https://careers.elcompanies.com"}},
    {"name": "Novo Nordisk", "slug": "novo-nordisk", "sector": "Pharmaceuticals", "listing": "NYSE (NVO)",
     "region": "BLR", "aliases": ["Novo Nordisk"], "sec_cik": None, "domain": "novonordisk.com",
     "careers": {"type": "successfactors", "base": "https://careers.novonordisk.com", "url": "https://careers.novonordisk.com"}},
]

# ---- The full account book (region-tagged). COMPANIES above is the subset wired to a working ATS
# (deep hiring data); every account below shows in the roster/Excel and gets global strategic signals
# as its ATS config is added. slug must be unique; sector is best-effort EY-style classification. ----
ACCOUNTS = [
    {"name": "Tesco", "slug": "tesco", "sector": "Retail", "region": "BLR"},
    {"name": "Takeda", "slug": "takeda", "sector": "Pharmaceuticals", "region": "BLR"},
    {"name": "Diageo", "slug": "diageo", "sector": "Beverages", "region": "BLR"},
    {"name": "Airbnb", "slug": "airbnb", "sector": "Technology / Travel", "region": "West"},
    {"name": "Nike", "slug": "nike", "sector": "Consumer / Apparel", "region": "BLR"},
    {"name": "Kimberly-Clark", "slug": "kimberly-clark", "sector": "Consumer Products", "region": "BLR"},
    {"name": "BCG", "slug": "bcg", "sector": "Management Consulting", "region": "West"},
    {"name": "Alstom", "slug": "alstom", "sector": "Industrial / Rail", "region": "BLR"},
    {"name": "BP", "slug": "bp", "sector": "Energy", "region": "West"},
    {"name": "DTICI (Daimler Truck)", "slug": "dtici", "sector": "Automotive", "region": "BLR"},
    {"name": "AB InBev", "slug": "abinbev", "sector": "Beverages", "region": "BLR"},
    {"name": "Cargill", "slug": "cargill", "sector": "Agriculture & Food", "region": "BLR"},
    {"name": "Colgate-Palmolive", "slug": "colgate", "sector": "Consumer Products", "region": "West"},
    {"name": "Colt Technology", "slug": "colt", "sector": "Telecom", "region": "West"},
    {"name": "AstraZeneca", "slug": "astrazeneca", "sector": "Pharmaceuticals", "region": "BLR"},
    {"name": "Merck", "slug": "merck", "sector": "Pharmaceuticals", "region": "BLR"},
    {"name": "Flex", "slug": "flex", "sector": "Electronics Manufacturing", "region": "BLR"},
    {"name": "Applied Materials", "slug": "applied-materials", "sector": "Semiconductors", "region": "BLR"},
    {"name": "Novo Nordisk", "slug": "novo-nordisk", "sector": "Pharmaceuticals", "region": "BLR"},
    {"name": "7-Eleven", "slug": "7-eleven", "sector": "Retail", "region": "BLR"},
    {"name": "Adobe", "slug": "adobe", "sector": "Technology / Software", "region": "BLR"},
    {"name": "Caterpillar", "slug": "caterpillar", "sector": "Industrial / Heavy Equipment", "region": "BLR"},
    {"name": "Henny Penny", "slug": "henny-penny", "sector": "Foodservice Equipment", "region": "West"},
    {"name": "Chevron", "slug": "chevron", "sector": "Energy", "region": "BLR"},
    {"name": "Kellogg's", "slug": "kelloggs", "sector": "Consumer / Food", "region": "West"},
    {"name": "Kohler", "slug": "kohler", "sector": "Manufacturing", "region": "West"},
    {"name": "Levi's", "slug": "levis", "sector": "Apparel", "region": "Hyd"},
    {"name": "Thermo Fisher", "slug": "thermo-fisher", "sector": "Life Sciences", "region": "BLR"},
    {"name": "Magnum ICC", "slug": "magnum-icc", "sector": "Industrial", "region": "West"},
    {"name": "Magnum International", "slug": "magnum-int", "sector": "Industrial", "region": "West"},
    {"name": "Estee Lauder", "slug": "estee-lauder", "sector": "Consumer / Beauty", "region": "BLR"},
    {"name": "HCLTech", "slug": "hcl", "sector": "IT Services", "region": "BLR"},
    {"name": "Microsoft", "slug": "microsoft", "sector": "Technology / Software", "region": "Hyd"},
    {"name": "Baker Hughes", "slug": "bhi", "sector": "Energy Services", "region": "BLR"},
    {"name": "North Star", "slug": "north-star", "sector": "Industrial", "region": "West"},
    {"name": "DaVita", "slug": "davita", "sector": "Healthcare", "region": "BLR"},
    {"name": "PepsiCo", "slug": "pepsico", "sector": "Food & Beverage", "region": "Hyd"},
    {"name": "Procter & Gamble", "slug": "pg", "sector": "Consumer Products", "region": "Hyd"},
    {"name": "Godrej", "slug": "godrej", "sector": "Conglomerate", "region": "BLR"},
    {"name": "Qualcomm", "slug": "qualcomm", "sector": "Semiconductors", "region": "Hyd"},
    {"name": "Rio Tinto", "slug": "rio-tinto", "sector": "Mining & Metals", "region": "West"},
    {"name": "SLB (Schlumberger)", "slug": "slb", "sector": "Energy Services", "region": "West"},
    {"name": "GSK", "slug": "gsk", "sector": "Pharmaceuticals", "region": "BLR"},
    {"name": "Lowe's", "slug": "lowes", "sector": "Retail", "region": "BLR"},
    {"name": "MBRDI (Mercedes-Benz R&D)", "slug": "mbrdi", "sector": "Automotive", "region": "BLR"},
    {"name": "TIAA", "slug": "tiaa", "sector": "Financial Services", "region": "West"},
    {"name": "Unilever", "slug": "unilever", "sector": "Consumer Products", "region": ""},
    {"name": "ZS Associates", "slug": "zs", "sector": "Consulting / Analytics", "region": "West"},
    {"name": "Philip Morris International", "slug": "pmi", "sector": "Consumer / Tobacco", "region": "BLR"},
    {"name": "Carrier", "slug": "carrier", "sector": "HVAC / Industrial", "region": ""},
]

# ---- Extra career portals for accounts NOT in COMPANIES: custom / virtualized sites with no standard
# ATS, scraped best-effort (titles only) via the Bright Data remote browser (type "browser"). An empty
# result is kept honestly blank (never faked) and never overwrites a prior good / Indeed dump. ----
CAREERS_EXTRA = {
    # Kellanova (Kellogg's) runs SuccessFactors — use the proven SF adapter, not the generic one.
    "kelloggs": {"type": "successfactors", "base": "https://careers.kellanova.com",
                 "url": "https://careers.kellanova.com"},
    # Hand-built / virtualized sites: best-effort generic browser scrape (titles only). Many expose no
    # parseable job tiles and stay honestly blank — kept here so one command still ATTEMPTS all of them.
    "airbnb": {"type": "browser", "url": "https://careers.airbnb.com/",
               "search_url": "https://careers.airbnb.com/positions/", "scrolls": 4},
    "abinbev": {"type": "browser", "url": "https://www.ab-inbev.com/careers/",
                "search_url": "https://www.ab-inbev.com/careers/", "scrolls": 3},
    "colt": {"type": "browser", "url": "https://www.colt.net/careers/",
             "search_url": "https://www.colt.net/careers/job-search/", "scrolls": 3},
    "godrej": {"type": "browser", "url": "https://www.godrejcareers.com/",
               "search_url": "https://www.godrejcareers.com/", "scrolls": 3},
}

# ---- News (the 5 market-intelligence fields) ----
FIELDS = {
    "hiring": {"label": "Hiring", "query": "{company} hiring jobs recruitment roles careers workforce"},
    "vision_strategy": {"label": "Vision & strategy", "query": "{company} strategy leadership reorganisation restructuring vision"},
    "partnerships": {"label": "Partnerships", "query": "{company} partnership alliance technology cloud AI vendor deal"},
    "money_metrics": {"label": "Financial performance", "query": "{company} results earnings profit revenue funding acquisition"},
    "expansion": {"label": "Expansion", "query": "{company} expansion new facility investment India GCC capability centre"},
}

# ---- Level 2: technology domain (EY-style competency clusters) ----
COMPETENCY_CLUSTERS = {
    "SAP / ERP": ["sap", "s/4hana", "s4hana", "abap", "fico", "ariba", "successfactors", "mdg", "ewm", "oracle erp", "erp"],
    "Data & Analytics": ["data analyst", "data scientist", "data engineer", "analytics", "power bi", "tableau",
                         "looker", "qlik", "etl", "snowflake", "databricks", "bigquery", "data warehouse",
                         "business intelligence", "data platform", "fabric", "data governance", "master data"],
    "AI & Automation": ["artificial intelligence", "machine learning", " ai ", "genai", "generative ai", "llm",
                        "mlops", "rpa", "uipath", "automation anywhere", "blue prism", "nlp", "computer vision"],
    "Microsoft & Azure": ["azure", ".net", "dynamics 365", "power platform", "power apps", "power automate",
                         "sharepoint", "m365", "microsoft fabric"],
    "Salesforce / CRM": ["salesforce", "apex", "lightning", "veeva", "crm"],
    "Cybersecurity": ["cyber", "cybersecurity", "infosec", "soc analyst", "iam", "identity access",
                     "vulnerability", "penetration", "threat intel", "zero trust"],
    "Cloud & Engineering": ["aws", "gcp", "google cloud", "kubernetes", "docker", "devops", "terraform",
                          "software engineer", "developer", "full stack", "backend", "frontend", "react",
                          "node", "microservices", "cloud engineer", "site reliability", "java", "python"],
}

# ---- Level 2: job family / role type ----
ROLE_TYPES = {
    "Data Scientist": ["data scientist", "applied scientist", "research scientist"],
    "Data Engineer": ["data engineer", "etl developer", "big data"],
    "AI/ML Engineer": ["machine learning engineer", "ml engineer", "ai engineer", "mlops", "genai engineer"],
    "Data Analyst": ["data analyst", "bi analyst", "analytics analyst", "business intelligence analyst"],
    "SAP Consultant": ["sap", "abap", "functional consultant"],
    "BI / Power BI Developer": ["power bi", "powerbi", "tableau", "qlik", "bi developer"],
    "Cloud/DevOps Engineer": ["devops", "cloud engineer", "sre", "site reliability", "platform engineer"],
    "Solution Architect": ["architect"],
    "Project/Program Manager": ["project manager", "program manager", "product manager", "delivery manager",
                                "scrum master", "program lead"],
    "Software Engineer": ["software engineer", "developer", "full stack", "backend", "frontend", "programmer"],
    "Cyber Specialist": ["cybersecurity", "cyber security", "soc analyst", "infosec",
                         "security engineer", "security analyst", "penetration", "iam engineer"],
}

# ---- Level 2: business / value-chain domain ----
BUSINESS_DOMAINS = {
    "Finance": ["finance", "fp&a", "accounting", "treasury", "tax", "controller", "audit"],
    "Supply Chain": ["supply chain", "logistics", "procurement", "planning", "warehouse", "distribution", "sourcing"],
    "Clinical / R&D": ["clinical", "r&d", "research", "regulatory", "pharmacovigilance", "trial", "medical"],
    "Risk & Compliance": ["risk", "compliance", "governance", "quality", "regulatory affairs"],
    "Manufacturing": ["manufacturing", "production", "plant", "operations", "engineering", "maintenance"],
    "Commercial & Marketing": ["marketing", "sales", "commercial", "brand", "ecommerce", "customer", "category"],
    "HR & People": ["human resources", "hr ", "talent", "people", "recruiter"],
    "Technology / IT": ["software", "data", "cloud", "it ", "digital", "platform", "cyber", "sap", "analytics"],
}

# ---- Level 2: transformation theme ----
TRANSFORMATION_THEMES = {
    "GenAI & AI": ["genai", "generative ai", "artificial intelligence", "machine learning", " ai ", "llm"],
    "Cloud Modernization": ["cloud", "aws", "azure", "gcp", "kubernetes", "migration", "devops"],
    "Data & Governance": ["data governance", "master data", "mdm", "data quality", "data platform", "lakehouse", "analytics"],
    "ERP Transformation": ["sap", "s/4hana", "erp", "oracle erp", "dynamics 365"],
    "Cybersecurity": ["cyber", "security", "iam", "zero trust", "soc"],
    "Intelligent Automation": ["rpa", "uipath", "automation anywhere", "blue prism", "automation"],
    "Digital Engineering": ["software engineer", "full stack", "microservices", "api", "platform engineering"],
}

# ---- Level 2: seniority (title keywords; experience years can override) ----
SENIORITY = {
    "Executive": ["chief", "vp ", "vice president", "director", "head of", "cxo"],
    "Manager/Lead": ["manager", "lead", "principal", "staff", "head"],
    "Senior": ["senior", "sr.", "sr ", "specialist iii"],
    "Mid": ["associate", "analyst", "engineer", "consultant", "developer", "executive"],
    "Junior/Entry": ["intern", "graduate", "trainee", "apprentice", "junior", "entry"],
}

# ---- Normalization: variant -> canonical technology/vendor ----
VENDOR_CANON = {
    "pbi": "Power BI", "powerbi": "Power BI", "power bi": "Power BI", "power-bi": "Power BI",
    "aws": "AWS", "amazon web services": "AWS", "gcp": "Google Cloud", "google cloud": "Google Cloud",
    "gcp cloud": "Google Cloud", "azure": "Microsoft Azure", "ms azure": "Microsoft Azure",
    "s/4hana": "SAP S/4HANA", "s4hana": "SAP S/4HANA", "s4 hana": "SAP S/4HANA", "sap": "SAP",
    "adf": "Azure Data Factory", "fabric": "Microsoft Fabric", "ms fabric": "Microsoft Fabric",
    "o365": "Microsoft 365", "m365": "Microsoft 365", "snowflake": "Snowflake", "databricks": "Databricks",
    "tableau": "Tableau", "qlik": "Qlik", "looker": "Looker", "salesforce": "Salesforce",
    "servicenow": "ServiceNow", "uipath": "UiPath", "python": "Python", "sql": "SQL", "java": "Java",
    "kubernetes": "Kubernetes", "k8s": "Kubernetes", "terraform": "Terraform", "spark": "Apache Spark",
    "kafka": "Apache Kafka", "airflow": "Apache Airflow", "dynamics 365": "Dynamics 365", "d365": "Dynamics 365",
}

# Technologies to detect (matched against text, then normalized via VENDOR_CANON)
TECH_TERMS = [
    "SAP", "S/4HANA", "ABAP", "Azure", "AWS", "GCP", "Google Cloud", "Power BI", "PBI", "Tableau",
    "Looker", "Qlik", "Python", "Java", "SQL", "Snowflake", "Databricks", "Spark", "Kafka", "Airflow",
    "Kubernetes", "K8s", "Terraform", "Salesforce", "ServiceNow", "Dynamics 365", "Fabric", "SharePoint",
    "React", "Node", ".NET", "SAS", "UiPath", "MDM", "data governance", "GenAI", "LLM", "NLP",
]

# ---- Heatmap domains (Page 2): role contributes to a column if keywords hit ----
HEATMAP_DOMAINS = {
    "AI": ["artificial intelligence", "machine learning", "genai", "generative ai", " ai ", "llm", "nlp"],
    "Data": ["data engineer", "data scientist", "data analyst", "analytics", "power bi", "tableau",
             "snowflake", "databricks", "data governance", "master data", "fabric"],
    "Cloud": ["aws", "azure", "gcp", "google cloud", "kubernetes", "cloud", "devops", "terraform"],
    "Cyber": ["cyber", "security", "iam", "soc", "zero trust", "vulnerability"],
    "ERP": ["sap", "s/4hana", "erp", "oracle erp", "dynamics 365"],
    "Automation": ["rpa", "uipath", "automation anywhere", "blue prism", "automation"],
    "Digital Eng.": ["software engineer", "full stack", "microservices", "api", "developer", "platform engineer"],
}

# ---- Technology Radar (#17): group detected technologies into platform/vendor categories. ----
TECH_RADAR_GROUPS = {
    "Cloud & Platform": ["AWS", "Microsoft Azure", "Google Cloud", "Kubernetes", "Terraform", "Docker"],
    "Data & Analytics": ["SQL", "Databricks", "Snowflake", "Power BI", "Tableau", "Qlik", "Looker",
                         "SAS", "Apache Kafka", "Apache Spark", "Apache Airflow", "data governance",
                         "Azure Data Factory", "MDM"],
    "AI & GenAI": ["GenAI", "LLM", "NLP"],
    "ERP & Enterprise Apps": ["SAP", "SAP S/4HANA", "ABAP", "ServiceNow", "Salesforce", "Dynamics 365"],
    "Engineering & Languages": ["Python", "Java", "React", "Node", ".NET"],
    "Microsoft & Workplace": ["Microsoft 365", "SharePoint", "Microsoft Fabric"],
}

# ---- Level 4: opportunity radar (signal pattern -> interpretation -> EY response). Hypotheses. ----
# Each rule: if ANY trigger term appears in the company's demanded skills/role titles with >= min_count.
OPPORTUNITY_RULES = [
    {"triggers": ["genai", "generative ai", "llm", "ai architect"], "min": 2,
     "interpretation": "Enterprise AI capability build-up",
     "ey_response": "AI strategy, architecture and governance"},
    {"triggers": ["data governance", "data steward", "master data", "mdm"], "min": 2,
     "interpretation": "Governance / master-data operating-model expansion",
     "ey_response": "Data office, stewardship and MDM design"},
    {"triggers": ["fabric", "power bi", "tableau", "looker"], "min": 3,
     "interpretation": "Analytics / BI modernization",
     "ey_response": "Fabric migration and BI transformation"},
    {"triggers": ["s/4hana", "sap", "erp", "abap"], "min": 3,
     "interpretation": "ERP transformation activity",
     "ey_response": "ERP data migration, quality and reconciliation"},
    {"triggers": ["cyber", "security", "iam", "zero trust"], "min": 3,
     "interpretation": "Security capability build / remediation",
     "ey_response": "Cybersecurity assessment and remediation"},
    {"triggers": ["aws", "azure", "gcp", "kubernetes", "cloud engineer"], "min": 4,
     "interpretation": "Cloud modernization programme",
     "ey_response": "Cloud modernization and platform engineering"},
    {"triggers": ["rpa", "uipath", "automation"], "min": 2,
     "interpretation": "Intelligent-automation adoption",
     "ey_response": "Automation operating model and delivery"},
]

# When a role's title doesn't match a specific job family but it IS a tech role, name the family
# from its competency so it doesn't fall into "Other".
COMPETENCY_FAMILY = {
    "SAP / ERP": "SAP Consultant",
    "Data & Analytics": "Data & Analytics",
    "AI & Automation": "AI/ML Engineer",
    "Microsoft & Azure": "Microsoft / Azure",
    "Salesforce / CRM": "Salesforce / CRM",
    "Cybersecurity": "Cyber Specialist",
    "Cloud & Engineering": "Software / Cloud Engineer",
}

# Merge common location spellings (accents are stripped separately).
LOCATION_CANON = {"bengaluru": "Bangalore", "gurugram": "Gurgaon", "bombay": "Mumbai"}

INDIA_HINTS = ["india", "bengaluru", "bangalore", "mumbai", "chennai", "gurgaon", "gurugram",
               "hyderabad", "pune", "delhi", "noida", "kolkata"]

EMPLOYMENT_TYPES = {"FULL_TIME": "Full-time", "PART_TIME": "Part-time", "CONTRACTOR": "Contract",
                    "TEMPORARY": "Temporary", "INTERN": "Internship"}


def default_month():
    today = date.today()
    y, m = (today.year - 1, 12) if today.month == 1 else (today.year, today.month - 1)
    return f"{y:04d}-{m:02d}"


def prev_month(month_key):
    y, m = int(month_key[:4]), int(month_key[5:7])
    y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    return f"{y:04d}-{m:02d}"
