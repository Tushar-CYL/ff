# Setup on another laptop

The full **India Account Intelligence** project: Python data pipeline + Next.js dashboard +
the already-generated data and a **pre-built static site** (so you can view it with zero build).

---

## Option A — Just VIEW the dashboard  (easiest · Python only · no internet, no Node)

The dashboard is already built into `webapp/out/`. To open it:

1. Install **Python 3.11+** (if not already).
2. Open a terminal in the project's **`webapp`** folder.
3. Run:
   ```
   python serve_nocache.py
   ```
4. Open **http://localhost:3000** in your browser.

No Node, no npm, no internet needed — it serves the pre-built dashboard with the current data.
*(If port 3000 is busy, edit `PORT` at the top of `serve_nocache.py`.)*

---

## Option B — Run / edit the dashboard  (Node)

1. Install **Node.js 20+**.
2. ```
   cd webapp
   npm install
   npm run dev          # live, http://localhost:3000
   # or
   npm run build        # rebuilds the static site in webapp/out/
   ```

---

## Option C — REGENERATE the data  (Python pipeline · needs internet + the API keys)

> Your office network may block some sources (Tavily, etc.). Google News + filings usually work.

1. Install **Python 3.11+**.
2. In the **project root** (the `automation` folder):
   ```
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   pip install pip-system-certs      # only on a corporate SSL-inspecting proxy
   ```
3. The included `.env` already has the API keys.
4. ```
   python discover.py     # scrape India roles (all departments, full JDs)
   python india_run.py     # build the report + webapp/public/data.json
   ```
5. View the refreshed data via **Option A** or **Option B** (re-run `npm run build` for Option A).

---

## BI Excel (for Power BI)
Every pipeline run also writes **`output_india/<month>/account_intelligence_<month>.xlsx`** — a flat,
pivot-friendly workbook (Accounts · Hiring · Insights · Skill demand) you can upload straight into
Power BI if managers prefer a BI dashboard over the web app. No code needed to refresh it: re-run
`python india_run.py` and the `.xlsx` is regenerated alongside `data.json`.

## Scaling to the full account book
`settings.ACCOUNTS` holds the full ~50-client, region-tagged roster; `settings.COMPANIES` is the subset
with a working career-portal scraper (currently 4) that gets deep hiring data. To add a client's hiring:
add it to `COMPANIES` with its ATS config. A large multi-client run is heavy (network, LLM and Explorium
credits) — run it **in batches**. Clients without an ATS config still appear in the dashboard + Excel
with their global strategic signals and blank hiring (never fabricated).

## Notes
- **`.env` contains live API keys** (Tavily, EYQ/LLM, Explorium, TinyFish) — keep this zip private.
- To refresh the view after regenerating data in Option A: `cd webapp && npm run build`, then
  `python serve_nocache.py` again. (Option B's `npm run dev` picks up data changes on reload.)
- `README.md` documents the code structure (data collection → processing → UI).
