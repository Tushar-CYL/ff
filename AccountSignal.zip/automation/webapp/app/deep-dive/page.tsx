"use client";
import { useMemo, useState } from "react";
import {
  useReactTable, getCoreRowModel, getSortedRowModel, getFilteredRowModel,
  flexRender, createColumnHelper, SortingState,
} from "@tanstack/react-table";
import { useData, allRoles, RoleRow } from "@/lib/data";
import type { Company } from "@/lib/types";
import { SectionTitle, ConfBadge, PriorityBadge } from "@/components/ui";
import Echart from "@/components/Echart";

function agg(cos: Company[], key: "departments" | "skills" | "seniority" | "employment") {
  const m = new Map<string, number>();
  cos.forEach((c) => (c[key] || []).forEach(([k, v]) => m.set(k, (m.get(k) || 0) + v)));
  return [...m.entries()].sort((a, b) => b[1] - a[1]);
}

// India career portals report locations in many formats ("Bangalore, India", "Bangalore,IND",
// "India, Karnataka, Bangalore"…). Normalise to the canonical city so the chart is meaningful.
const CITY_RULES: [RegExp, string][] = [
  [/bengaluru|bangalore|bangaluru/, "Bengaluru"], [/hyderabad/, "Hyderabad"], [/mumbai/, "Mumbai"],
  [/pune/, "Pune"], [/chennai/, "Chennai"], [/gurgaon|gurugram/, "Gurugram"], [/noida/, "Noida"],
  [/new delhi|delhi/, "Delhi"], [/kolkata/, "Kolkata"], [/ahmedabad/, "Ahmedabad"],
  [/coimbatore/, "Coimbatore"], [/kochi|cochin/, "Kochi"], [/jaipur/, "Jaipur"], [/indore/, "Indore"],
  [/chandigarh/, "Chandigarh"], [/thiruvananthapuram|trivandrum/, "Thiruvananthapuram"],
  [/visakhapatnam|vizag/, "Visakhapatnam"], [/nagpur/, "Nagpur"], [/remote/, "Remote (India)"],
];
function cityAgg(cos: Company[]) {
  const m = new Map<string, number>();
  cos.forEach((c) => (c.locations || []).forEach(([loc, v]) => {
    const s = (loc || "").toLowerCase();
    const hit = CITY_RULES.find(([re]) => re.test(s));
    const name = hit ? hit[1] : "Other India";
    m.set(name, (m.get(name) || 0) + v);
  }));
  return [...m.entries()].sort((a, b) => b[1] - a[1]);
}
function hbar(data: [string, number][], n = 10) {
  const d = data.slice(0, n).reverse();
  return {
    grid: { left: 130, right: 34, top: 6, bottom: 6 },
    xAxis: { type: "value", show: false },
    yAxis: { type: "category", data: d.map((x) => x[0]), axisTick: { show: false }, axisLine: { show: false }, axisLabel: { color: "#747480", fontSize: 11 } },
    series: [{ type: "bar", data: d.map((x) => x[1]), barWidth: 13, itemStyle: { color: "#ffe600", borderRadius: 4 }, label: { show: true, position: "right", color: "#e9e9ee", fontWeight: 800, fontSize: 11 } }],
  };
}
function pie(data: [string, number][]) {
  return {
    tooltip: { trigger: "item" },
    legend: { bottom: 0, textStyle: { fontSize: 11, color: "#c7c7d0" } },
    series: [{ type: "pie", radius: ["45%", "72%"], center: ["50%", "44%"], label: { show: false },
      data: data.map((x, i) => ({ name: x[0], value: x[1], itemStyle: { color: ["#2e2e38", "#35a4e8", "#27acaa", "#ff6d00", "#9c82d4", "#57e188", "#747480", "#f3c300"][i % 8] } })) }],
  };
}

const col = createColumnHelper<RoleRow>();

export default function DeepDive() {
  const { data, error } = useData();
  const [client, setClient] = useState("all");
  const [dept, setDept] = useState("all");
  const [critOnly, setCritOnly] = useState(false);
  const [q, setQ] = useState("");
  const [sorting, setSorting] = useState<SortingState>([{ id: "priority", desc: false }]);

  const cos = useMemo(() => (!data ? [] : client === "all" ? data.companies : data.companies.filter((c) => c.slug === client)), [data, client]);
  const rows = useMemo(() => {
    if (!data) return [];
    return allRoles(data).filter((r) =>
      (client === "all" || r.slug === client) &&
      (dept === "all" || r.business_domain === dept) &&
      (!critOnly || r.critical) &&
      (!q || (r.role_title + " " + (r.skills || []).join(" ") + " " + (r.team || "") + " " + r.location).toLowerCase().includes(q.toLowerCase()))
    );
  }, [data, client, dept, critOnly, q]);

  const columns = useMemo(() => [
    col.accessor("client", { header: "Client", cell: (i) => <span className="font-semibold">{i.getValue()}</span> }),
    col.accessor("role_title", { header: "Role", cell: (i) => <span>{i.getValue()}{i.row.original.critical && <span className="chip !text-[9px] !px-1.5 ml-1.5 text-ey-red bg-red-100 font-extrabold">CRITICAL</span>}</span> }),
    col.accessor("business_domain", { header: "Department" }),
    col.accessor("employment_category", { header: "Type" }),
    col.accessor((r) => r.priority, {
      id: "priority", header: "Priority",
      sortingFn: (a, b) => ({ High: 0, Medium: 1, Low: 2 }[a.original.priority] - { High: 0, Medium: 1, Low: 2 }[b.original.priority]),
      cell: (i) => <PriorityBadge p={i.getValue() as string} />,
    }),
    col.accessor((r) => r.likely_manager?.name || "Unknown", {
      id: "manager", header: "Likely manager",
      cell: (i) => {
        const m = i.row.original.likely_manager;
        if (!m || m.name === "Unknown") return <span className="text-ey-faint">Unknown</span>;
        return <div><span className="font-semibold">{m.name}</span> <ConfBadge c={m.confidence} />{m.profile && <> <a href={m.profile} target="_blank" rel="noopener" className="text-blue-700 text-[11px]">profile</a></>}<div className="text-ey-faint text-[11px]">{(m.title || "").slice(0, 34)}</div></div>;
      },
    }),
    col.accessor((r) => r.likely_manager?.title || "", { id: "reports", header: "Reports to", cell: (i) => i.row.original.reports_to || <span className="text-ey-faint">—</span> }),
    col.accessor("location", { header: "Location" }),
    col.accessor("seniority", { header: "Seniority" }),
    col.accessor((r) => (r.skills || []).slice(0, 4).join(", "), { id: "skills", header: "Skills", enableSorting: false }),
    col.accessor("posted_date", { header: "Posted" }),
    col.accessor("source_url", { header: "", enableSorting: false, cell: (i) => i.getValue() ? <a href={i.getValue() as string} target="_blank" rel="noopener" className="text-blue-700">open</a> : null }),
  ], []);

  const table = useReactTable({
    data: rows, columns, state: { sorting }, onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(), getFilteredRowModel: getFilteredRowModel(),
  });

  if (error) return <div className="mt-10 text-ey-red">Could not load data.json — {error}</div>;
  if (!data) return <div className="mt-10 text-ey-faint">Loading…</div>;
  const depts = agg(cos, "departments"), skills = agg(cos, "skills"), sen = agg(cos, "seniority");
  const cities = cityAgg(cos), emp = agg(cos, "employment");
  const empTotal = emp.reduce((s, x) => s + x[1], 0);
  const tr = data.tech_radar || [];
  const rad = data.opportunity_radar.filter((o) => client === "all" || o.clients.includes(data.names[client]));

  return (
    <div>
      <div className="flex items-center gap-2 flex-wrap mt-5">
        <h1 className="text-xl font-extrabold m-0">Deep dive</h1>
        <div className="ml-auto flex gap-2 flex-wrap items-center">
          <select value={client} onChange={(e) => setClient(e.target.value)} className="bg-white border border-[#2b2b38] rounded-lg px-3 py-2 text-[13px]"><option value="all">All clients</option>{data.companies.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
          <select value={dept} onChange={(e) => setDept(e.target.value)} className="bg-white border border-[#2b2b38] rounded-lg px-3 py-2 text-[13px]"><option value="all">All departments</option>{[...new Set(allRoles(data).map((r) => r.business_domain))].sort().map((d) => <option key={d}>{d}</option>)}</select>
          <label className="flex items-center gap-1.5 text-[13px] text-ey-muted"><input type="checkbox" checked={critOnly} onChange={(e) => setCritOnly(e.target.checked)} /> Critical only</label>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search role / skill / location" className="bg-white border border-[#2b2b38] rounded-lg px-3 py-2 text-[13px] min-w-[220px]" />
        </div>
      </div>

      <SectionTitle title="Demand landscape" note="department · seniority · technology" />
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card p-4"><div className="sub mb-2">Departments</div><Echart option={hbar(depts) as any} height={Math.max(150, depts.slice(0, 10).length * 26)} /></div>
        <div className="card p-4"><div className="sub mb-2">Seniority mix</div><Echart option={pie(sen) as any} height={210} /></div>
        <div className="card p-4"><div className="sub mb-2">Top technologies</div><Echart option={hbar(skills, 12) as any} height={Math.max(150, skills.slice(0, 12).length * 24)} /></div>
      </div>

      <SectionTitle title="Where & how they hire" note="India locations · permanent vs contract staffing signal" />
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-4">
          <div className="sub mb-2">Hiring by India location</div>
          {cities.length ? <Echart option={hbar(cities, 10) as any} height={Math.max(150, cities.slice(0, 10).length * 26)} />
            : <p className="text-ey-faint text-sm py-8 text-center">No India location data for this selection.</p>}
        </div>
        <div className="card p-4">
          <div className="sub mb-2">Permanent vs contract vs internship</div>
          {empTotal ? <>
            <Echart option={pie(emp) as any} height={210} />
            <p className="text-[11px] text-ey-faint mt-1 text-center">
              {emp.map(([k, v]) => `${k} ${Math.round((v / empTotal) * 100)}%`).join(" · ")} — a low permanent share signals heavy contractor/staffing demand.
            </p>
          </> : <p className="text-ey-faint text-sm py-8 text-center">No employment-type data for this selection.</p>}
        </div>
      </div>

      <SectionTitle title="Technology radar" note="platforms & vendors by adoption" />
      <div className="card p-4"><Echart option={hbar(tr.map((g) => [g.group, g.adoption] as [string, number]), 8) as any} height={180} /></div>

      <SectionTitle title="Opportunity map" note="hiring signal → suggested EY response (hypotheses)" />
      <div className="card p-0 overflow-hidden">
        <table className="w-full text-xs"><thead><tr className="bg-ey-black text-white text-left"><th className="p-2.5">Signal</th><th className="p-2.5">Suggested EY response</th><th className="p-2.5">Clients</th></tr></thead>
          <tbody>{rad.length ? rad.map((o, i) => <tr key={i} className="border-b border-[#2b2b38] hover:bg-[#23232e]"><td className="p-2.5 font-bold">{o.signal}</td><td className="p-2.5">{o.ey_response}</td><td className="p-2.5">{o.clients.join(", ")}</td></tr>) : <tr><td className="p-2.5 text-ey-faint" colSpan={3}>None.</td></tr>}</tbody>
        </table>
      </div>

      <SectionTitle title="Open roles" note={`${rows.length} roles · sort any column`} />
      <div className="card p-3 text-[11.5px] text-ey-muted mb-2">
        <b>Likely manager</b> = matched department leader (named, confidence-rated), a research estimate — not the confirmed requisition owner, which is private. <b>High</b> = named in the posting; <b>Medium/Low</b> = inferred.
      </div>
      <div className="card p-0 overflow-auto max-h-[640px]">
        <table className="w-full text-xs">
          <thead className="sticky top-0">
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id} className="bg-ey-black text-white text-left">
                {hg.headers.map((h) => (
                  <th key={h.id} onClick={h.column.getToggleSortingHandler()} className="p-2.5 text-[11px] cursor-pointer select-none whitespace-nowrap">
                    {flexRender(h.column.columnDef.header, h.getContext())}
                    {{ asc: " ▲", desc: " ▼" }[h.column.getIsSorted() as string] ?? ""}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="border-b border-[#2b2b38] hover:bg-[#23232e] align-top">
                {row.getVisibleCells().map((cell) => <td key={cell.id} className="p-2.5">{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>)}
              </tr>
            ))}
            {rows.length === 0 && <tr><td className="p-2.5 text-ey-faint" colSpan={12}>No roles match.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
