"use client";
import { useEffect, useMemo, useState } from "react";
import { useData } from "@/lib/data";
import type { Company, Provenance } from "@/lib/types";
import { SectionTitle, Tag } from "@/components/ui";
import SalesJourney from "@/components/SalesJourney";
import Echart from "@/components/Echart";

function CountUp({ value }: { value: number }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now(), dur = 900;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <>{n.toLocaleString()}</>;
}

function kpis(cos: Company[]) {
  const sum = (f: (c: Company) => number) => cos.reduce((s, c) => s + f(c), 0);
  const perm = sum((c) => (c.employment || []).filter((e) => e[0] === "Permanent").reduce((a, e) => a + e[1], 0));
  const deptSet = new Set<string>();
  cos.forEach((c) => c.departments.forEach((d) => deptSet.add(d[0])));
  const tot = sum((c) => c.total);
  return [
    { v: tot, l: "Open India roles", s: "all departments", accent: "text-white" },
    { v: sum((c) => c.critical), l: "Critical requirements", s: "senior / niche / hard-to-fill", accent: "text-[#ff8a7a]" },
    { v: perm, l: "Permanent openings", s: "~6–7 contractors follow each", accent: "text-[#57e188]" },
    { v: deptSet.size, l: "Departments hiring", s: "cross-functional demand", accent: "text-white" },
    { v: sum((c) => (c.people || []).length), l: "Named leaders mapped", s: "via Explorium", accent: "text-[#ffe600]" },
  ];
}

const REGION_LABEL: Record<string, string> = { BLR: "Bengaluru", Hyd: "Hyderabad", West: "West (Mumbai / Pune)" };

const DONUT_COLORS = ["#ffe600", "#35a4e8", "#27acaa", "#9c82d4", "#57e188", "#9b9ba5"];
function shareOption(intensity: [string, number][]) {
  const total = intensity.reduce((s, x) => s + x[1], 0) || 1;
  return {
    tooltip: { trigger: "item", formatter: "{b}: {c} roles ({d}%)" },
    legend: {
      orient: "vertical", right: 2, top: "middle", icon: "circle", itemWidth: 9, itemHeight: 9,
      itemGap: 8, textStyle: { fontSize: 11.5, color: "#c7c7d0" },
      formatter: (name: string) => {
        const it = intensity.find((x) => x[0] === name);
        return `${name}   ${it ? Math.round((it[1] / total) * 100) : 0}%`;
      },
    },
    series: [{
      type: "pie", radius: ["52%", "78%"], center: ["27%", "50%"], avoidLabelOverlap: true,
      label: { show: false }, labelLine: { show: false },
      itemStyle: { borderColor: "#1a1a24", borderWidth: 2 },
      data: intensity.map((x, i) => ({ name: x[0], value: x[1], itemStyle: { color: DONUT_COLORS[i % DONUT_COLORS.length] } })),
    }],
  };
}

function SplitBar({ emp }: { emp: [string, number][] }) {
  const t = emp.reduce((s, e) => s + e[1], 0) || 1;
  const g = (k: string) => (emp.find((e) => e[0] === k)?.[1] || 0);
  const seg = (w: number, c: string) => <span style={{ width: `${(w / t) * 100}%`, background: c }} className="h-full block" />;
  return (
    <div className="flex h-2.5 w-[160px] rounded overflow-hidden bg-white/15 mt-1">
      {seg(g("Permanent"), "#57e188")}{seg(g("Contract"), "#ffe600")}{seg(g("Internship"), "#9b9ba5")}
    </div>
  );
}

function signalStream(c: Company) {
  const h = c.hotspot;
  const perm = (c.employment || []).filter((e) => e[0] === "Permanent").reduce((a, e) => a + e[1], 0);
  const items: { color: string; tag: string; title: string; sub: string }[] = [];
  if (h) items.push({ color: "#f3c300", tag: `${h.roles} ROLES`, title: `Hiring concentrated in ${h.field}`, sub: (h.skills || []).slice(0, 4).join(" · ") });
  if (c.critical) items.push({ color: "#ff5a46", tag: `${c.critical} CRITICAL`, title: "Critical requirements open", sub: "senior / niche / hard-to-fill" });
  if (perm) items.push({ color: "#57e188", tag: `${perm} PERMANENT`, title: "Permanent openings", sub: "~6–7 contractors typically follow each hire" });
  (c.opportunities || []).slice(0, 4).forEach((o) => items.push({ color: "#35a4e8", tag: "EY OPPORTUNITY", title: o.interpretation, sub: o.ey_response }));
  return items.slice(0, 6);
}

function NewsOnlyCard({ c }: { c: Company }) {
  const sig = (c.strategic_signals || []).slice(0, 3);
  const grav = (c.tool_gravitation || []).filter((g) => g.vendor).slice(0, 6);
  return (
    <div className="mb-5 animate-in card overflow-hidden">
      <div className="p-5" style={{ background: "linear-gradient(120deg,#20202c,#171720)" }}>
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-xl flex-none grid place-items-center text-ey-black font-extrabold text-lg" style={{ background: "#5fb0f0" }}>{c.name[0]}</div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <h3 className="text-xl font-extrabold m-0 text-white">{c.name}</h3>
              <span className="text-[11px] text-gray-400">{c.sector}</span>
              {c.region && <span className="chip bg-white/10 text-gray-200">📍 {REGION_LABEL[c.region] || c.region}</span>}
            </div>
            <div className="mt-1.5 inline-flex items-center gap-1.5 text-[12px] font-semibold px-2.5 py-1 rounded-full" style={{ background: "#5fb0f018", color: "#5fb0f0" }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#5fb0f0" }} /> Strategic signals · India hiring portal not yet wired
            </div>
          </div>
        </div>
        {c.narrative && <div className="mt-3 text-[15px] text-gray-200"><b className="text-ey-yellow">Latest:</b> {c.narrative}</div>}
      </div>
      <div className="p-5 border-t border-[#2b2b38]">
        {sig.length > 0 ? (
          <>
            <div className="sub mb-2">Partnerships, vision & tool bets</div>
            <ul className="space-y-1.5 mb-3">
              {sig.map((s, i) => {
                const m = SIGNAL_META[s.type] || SIGNAL_META["Vision / change"];
                return (
                  <li key={i} className="flex gap-2.5 text-[13.5px] leading-snug text-gray-200">
                    <span className="text-[10px] font-extrabold uppercase mt-[3px] flex-none" style={{ color: m.color }}>{m.icon} {s.type.split(" ")[0]}</span>
                    <span>{s.headline}{s.vendor && <b className="text-ey-yellow"> · {s.vendor}</b>}</span>
                  </li>
                );
              })}
            </ul>
          </>
        ) : <p className="text-gray-500 text-sm mb-2">No strategic signals captured this period.</p>}
        {grav.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {grav.map((g) => <span key={g.vendor} className="chip bg-white/10 text-gray-100" title={g.ey_angle}>{g.vendor}</span>)}
          </div>
        )}
        <div className="text-[11px] text-gray-500 mt-3">Full market intelligence for {c.name} in the sections below. India hiring will populate once its career portal is added.</div>
      </div>
    </div>
  );
}

const COVERAGE_META: Record<string, { color: string }> = {
  full_jd: { color: "#57e188" },
  titles_only: { color: "#f0c24b" },
  signals_only: { color: "#5fb0f0" },
  failed: { color: "#ff8a7a" },
};
function CoverageBadge({ p }: { p?: Provenance }) {
  if (!p) return null;
  const m = COVERAGE_META[p.coverage_status] || COVERAGE_META.signals_only;
  const src = p.method_label && p.method_label !== "—" ? ` · ${p.method_label}` : "";
  return (
    <span className="chip" style={{ background: `${m.color}1e`, color: m.color }}
      title={`${p.roles_full_jd}/${p.roles} India roles with a full job description`}>
      {p.coverage_label}{src}
    </span>
  );
}

function ClientCard({ c }: { c: Company }) {
  if (!c.total) return <NewsOnlyCard c={c} />;
  const h = c.hotspot;
  const total = (c.intensity || []).reduce((s, x) => s + x[1], 0) || 1;
  const topPct = c.intensity?.length ? Math.round((c.intensity[0][1] / total) * 100) : 0;
  return (
    <div className="mb-5 animate-in card overflow-hidden">
      {/* hero */}
      <div className="p-5" style={{ background: "linear-gradient(120deg,#20202c,#171720)" }}>
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-xl flex-none grid place-items-center text-ey-black font-extrabold text-lg" style={{ background: "#ffe600" }}>
            {c.name[0]}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <h3 className="text-xl font-extrabold m-0 text-white">{c.name}</h3>
              <span className="text-[11px] text-gray-400">{c.sector} · {c.listing}</span>
              {c.region && <span className="chip bg-white/10 text-gray-200">📍 {REGION_LABEL[c.region] || c.region}</span>}
              <CoverageBadge p={c.provenance} />
            </div>
            <div className="mt-1.5 inline-flex items-center gap-1.5 text-[12px] font-semibold px-2.5 py-1 rounded-full" style={{ background: "#57e18818", color: "#57e188" }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#57e188" }} /> Strong {c.direction.toLowerCase()} activity detected
            </div>
          </div>
        </div>
        <div className="mt-3 text-[15px] text-gray-200">
          {h ? <><b className="text-ey-yellow">{h.field}</b> is the hotspot — {h.roles} roles{h.leader && <>, led by <b className="text-ey-yellow">{h.leader}</b></>}</> : "India hiring snapshot"}
        </div>
        {h?.skills?.length ? <div className="mt-2 flex flex-wrap gap-1.5">{h.skills.slice(0, 6).map((s) => <span key={s} className="chip bg-white/10 text-gray-100">{s}</span>)}</div> : null}
        <div className="flex gap-7 flex-wrap mt-4">
          <div><div className="text-[22px] font-extrabold leading-none text-white"><CountUp value={c.total} /></div><div className="text-[10px] text-gray-400 uppercase">Open reqs</div></div>
          <div><div className="text-[22px] font-extrabold leading-none text-[#ff8a7a]"><CountUp value={c.critical} /></div><div className="text-[10px] text-gray-400 uppercase">Critical</div></div>
          <div><div className="text-[10px] text-gray-400 uppercase">Permanent vs contract</div><SplitBar emp={c.employment || []} /><div className="text-[10px] text-gray-400 mt-1">{(c.employment || []).map((e) => `${e[0]} ${e[1]}`).join(" · ")}</div></div>
          <div><div className="text-[22px] font-extrabold leading-none text-ey-yellow"><CountUp value={(c.people || []).length} /></div><div className="text-[10px] text-gray-400 uppercase">Leaders mapped</div></div>
        </div>
      </div>
      {/* body */}
      <div className="p-5 border-t border-[#2b2b38]">
        {c.takeaways?.length > 0 && (
          <div className="mb-4">
            <div className="sub mb-2">Key takeaways — the connect-the-dots insights</div>
            <ul className="space-y-1.5">
              {c.takeaways.map((t, i) => (
                <li key={i} className="flex gap-2.5 text-[13.5px] leading-snug text-gray-200">
                  <span className="mt-[7px] w-1.5 h-1.5 rounded-full flex-none" style={{ background: "#ffe600" }} /><span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <div className="sub mb-1">What they&apos;re hiring for</div>
            {c.intensity?.length ? (
              <>
                <p className="text-[13px] mb-1 text-gray-200 leading-snug"><b className="text-white">{c.intensity[0][0]}</b> is the biggest focus — <b className="text-ey-yellow">{topPct}%</b> of their technology hiring.</p>
                <Echart option={shareOption(c.intensity) as any} height={190} />
                <div className="text-[11px] text-gray-500">share of open roles by technology area (a role can span several)</div>
              </>
            ) : <p className="text-gray-500 text-sm">No data.</p>}
          </div>
          <div>
            <div className="sub mb-2">What stands out</div>
            <div className="flex flex-col gap-2.5">
              {signalStream(c).map((s, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="w-9 h-9 rounded-lg flex-none grid place-items-center text-ey-black font-extrabold text-[13px]" style={{ background: s.color }}>
                    {s.tag.match(/\d+/)?.[0] ?? "EY"}
                  </span>
                  <div className="min-w-0">
                    <div className="font-semibold text-[13px] leading-tight text-gray-100">{s.title}</div>
                    <div className="text-[11px] text-gray-400">{s.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <details className="mt-3 border-t border-[#2b2b38] pt-2">
          <summary className="cursor-pointer text-xs font-bold text-[#5fb0f0] list-none">▸ Full rationale, stakeholders &amp; next-best actions</summary>
          <div className="mt-2 space-y-2 text-[13px] leading-relaxed text-gray-300">
            {c.strategy && <p><b className="text-white">Strategic direction:</b> {c.strategy}</p>}
            {c.why && <p className="bg-[#2a2718] border border-[#4a431f] rounded-lg p-3"><b className="text-white">Why they&apos;re hiring:</b> {c.why}</p>}
            {c.investments && <p><b className="text-white">Inferred tech investment:</b> {c.investments}</p>}
            {c.stakeholders && <p><b className="text-white">Who to engage:</b> {c.stakeholders}</p>}
            {c.actions?.length > 0 && <div className="bg-[#16271a] border border-[#274d2c] rounded-lg p-3"><b className="text-white">Next-best actions:</b><ul className="list-disc ml-5 mt-1">{c.actions.map((a, i) => <li key={i}>{a}</li>)}</ul></div>}
            {c.recruiters?.length > 0 && <div><b className="text-white">Recruiter / hiring contacts:</b> {c.recruiters.slice(0, 6).map((p, i) => <span key={i}>{p.name} — {p.title}{p.linkedin && <> (<a href={p.linkedin} target="_blank" rel="noopener" className="text-[#5fb0f0]">profile</a>)</>}; </span>)}</div>}
            {c.people?.length > 0 && <div><b className="text-white">Named leaders:</b> {c.people.slice(0, 8).map((p, i) => <span key={i}>{p.name} — {p.title}{p.linkedin && <> (<a href={p.linkedin} target="_blank" rel="noopener" className="text-[#5fb0f0]">profile</a>)</>}; </span>)}</div>}
          </div>
        </details>
      </div>
    </div>
  );
}

const SIGNAL_META: Record<string, { color: string; icon: string }> = {
  "Partnership": { color: "#27acaa", icon: "🤝" },
  "Tool gravitation": { color: "#35a4e8", icon: "⚙" },
  "Vision / change": { color: "#9c82d4", icon: "🎯" },
};
function StrategicSignals({ cos }: { cos: Company[] }) {
  const has = cos.some((c) => (c.strategic_signals || []).length || (c.tool_gravitation || []).length);
  if (!has) return <p className="text-gray-500 text-sm">No strategic signals captured this period.</p>;
  return (
    <div className="space-y-5">
      {cos.map((c) => {
        const sig = (c.strategic_signals || []);
        const grav = (c.tool_gravitation || []).filter((g) => g.vendor);
        if (!sig.length && !grav.length) return null;
        return (
          <div key={c.slug} className="animate-in">
            <div className="font-extrabold text-[15px] mb-2 text-white">{c.name}</div>
            {sig.length > 0 && (
              <div className="grid md:grid-cols-2 gap-3 mb-3">
                {sig.map((s, i) => {
                  const m = SIGNAL_META[s.type] || SIGNAL_META["Vision / change"];
                  return (
                    <div key={i} className="card p-3.5">
                      <div style={{ borderLeft: `4px solid ${m.color}` }} className="pl-3">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10.5px] font-extrabold uppercase tracking-wide" style={{ color: m.color }}>{m.icon} {s.type}</span>
                          {s.vendor && <span className="chip" style={{ background: `${m.color}22`, color: m.color }}>{s.vendor}</span>}
                        </div>
                        <p className="text-[13px] my-1 leading-snug text-gray-200">{s.headline}</p>
                        <div className="text-[11.5px] text-[#ffe600]">→ {s.ey_opportunity}</div>
                        {s.source && <a href={s.source} target="_blank" rel="noopener" className="text-[11px] text-[#5fb0f0]">source</a>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            {grav.length > 0 && (
              <div>
                <div className="sub mb-1.5">Gravitating toward <span className="text-gray-500 normal-case">— platforms rising in hiring &amp; market signals</span></div>
                <div className="flex flex-wrap gap-1.5">
                  {grav.map((g) => (
                    <span key={g.vendor} className="chip bg-white/10 text-gray-100" title={g.ey_angle}>
                      {g.vendor}<span className="text-gray-500"> · {g.hiring + g.mentions}</span>
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

const SIG_META: Record<string, { label: string; color: string }> = {
  vision_strategy: { label: "Strategy & initiatives", color: "#9c82d4" },
  partnerships: { label: "Partnerships & tie-ups", color: "#27acaa" },
  money_metrics: { label: "Investment & financials", color: "#57e188" },
  expansion: { label: "Expansion", color: "#ff8a4a" },
};
function trim(t: string) { const d = t.indexOf(". "); if (d > 40 && d < 170) return t.slice(0, d + 1); return t.length > 170 ? t.slice(0, 168) + "…" : t; }
function MarketSignals({ cos }: { cos: Company[] }) {
  return (
    <div className="space-y-4">
      {cos.map((c) => {
        const cards: { color: string; label: string; text: string; src: string[] }[] = [];
        if (c.strategy) cards.push({ color: "#ffe600", label: "Strategic direction", text: c.strategy, src: [] });
        ["vision_strategy", "partnerships", "money_metrics", "expansion"].forEach((k) => {
          const e = c.fields?.[k];
          if (e?.summary && !e.summary.startsWith("No material")) cards.push({ color: SIG_META[k].color, label: SIG_META[k].label, text: trim(e.summary), src: e.sources || [] });
        });
        return (
          <div key={c.slug} className="animate-in">
            <div className="font-extrabold text-[15px] mb-2 text-white">{c.name}</div>
            {cards.length ? (
              <div className="grid md:grid-cols-2 gap-3">
                {cards.map((s, i) => (
                  <div key={i} className="card p-3.5">
                    <div style={{ borderLeft: `4px solid ${s.color}` }} className="pl-3">
                      <div className="text-[10.5px] font-extrabold uppercase tracking-wide" style={{ color: s.color }}>{s.label}</div>
                      <p className="text-[13px] my-1 leading-snug text-gray-200">{s.text}</p>
                      {s.src.slice(0, 2).map((u, j) => <a key={j} href={u} target="_blank" rel="noopener" className="text-[11px] text-[#5fb0f0] mr-2">source</a>)}
                    </div>
                  </div>
                ))}
              </div>
            ) : <p className="text-gray-500 text-sm">No market signals captured this period.</p>}
          </div>
        );
      })}
    </div>
  );
}

export default function InsightSummary() {
  const { data, error } = useData();
  const [client, setClient] = useState("all");
  const [region, setRegion] = useState("all");
  const cos = useMemo(() => {
    if (!data) return [];
    return data.companies
      .filter((c) => client === "all" || c.slug === client)
      .filter((c) => region === "all" || (c.region || "") === region);
  }, [data, client, region]);
  if (error) return <div className="mt-10 text-[#ff8a7a]">Could not load data.json — {error}</div>;
  if (!data) return <div className="mt-10 text-gray-500">Loading…</div>;

  return (
    <div>
      <div className="flex items-center gap-3 flex-wrap mt-5">
        <div>
          <h1 className="text-xl font-extrabold m-0 text-white">Insight summary</h1>
          <div className="text-gray-500 text-xs">{data.month_label} · as of {data.generated}</div>
        </div>
        <select value={region} onChange={(e) => setRegion(e.target.value)} className="ml-auto rounded-lg px-3 py-2 text-[13px]">
          <option value="all">All regions</option>
          {Object.entries(data.regions).filter(([k]) => k).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <select value={client} onChange={(e) => setClient(e.target.value)} className="rounded-lg px-3 py-2 text-[13px]">
          <option value="all">All clients</option>
          {data.companies.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
        </select>
      </div>

      <div className="mt-3 text-[12px] text-gray-500">
        Account book: <b className="text-gray-300">{data.accounts.length}</b> clients tracked ·
        <b className="text-[#57e188]"> {data.accounts.filter((a) => a.has_data).length}</b> with live India hiring ·
        <b className="text-[#5fb0f0]"> {data.accounts.filter((a) => a.has_signals).length}</b> with global strategic signals.
        <span className="block mt-0.5">India hiring needs each client&apos;s career portal wired; partnerships, vision &amp; tool signals come from global news and cover the whole book.</span>
      </div>

      <SectionTitle title="Where this fits in the sales journey" note="stages 1–3 are powered by live data" />
      <SalesJourney stages={data.sales_journey} />

      <SectionTitle title="Overview" note={client === "all" ? "all clients" : data.names[client]} />
      <div className="grid gap-3.5 grid-cols-2 md:grid-cols-5">
        {kpis(cos).map((k, i) => (
          <div key={i} className="card p-4 relative overflow-hidden animate-in" style={{ animationDelay: `${i * 0.07}s` }}>
            <span className="absolute left-0 top-0 bottom-0 w-1 bg-ey-yellow" />
            <div className={`text-[29px] font-extrabold leading-none ${k.accent}`}><CountUp value={k.v} /></div>
            <div className="text-gray-300 text-xs mt-1.5 font-semibold">{k.l}</div>
            <div className="text-gray-500 text-[11px] mt-0.5">{k.s}</div>
          </div>
        ))}
      </div>

      <SectionTitle title="Client snapshots" note="hotspot, capability focus and what stands out" />
      {cos.map((c) => <ClientCard key={c.slug} c={c} />)}

      <SectionTitle title="Partnerships, tool bets & strategic signals" note="who they're partnering with and the platforms they're moving to — the EY angle on each" />
      <StrategicSignals cos={cos} />

      <SectionTitle title="Market intelligence" note="what each client is doing beyond hiring — good-to-know context" />
      <MarketSignals cos={cos} />

      <footer className="text-gray-500 text-[11px] mt-8 pt-3.5 border-t border-[#2b2b38]">
        Real data: client career portals, SEC/RNS filings, news, Explorium (licensed people data).
        &quot;Likely manager&quot; is the matched department leader (confidence-rated), not the confirmed requisition owner. EY internal use.
      </footer>
    </div>
  );
}
