export interface Manager {
  name: string;
  title?: string;
  profile?: string;
  confidence: "High" | "Medium" | "Low" | "Unknown";
  evidence?: string;
}

export interface Role {
  role_title: string;
  business_domain: string;
  team: string | null;
  reports_to: string | null;
  location: string;
  seniority: string;
  skills: string[];
  posted_date: string;
  aging_days: number | null;
  source_url: string;
  critical: boolean;
  employment_category: string;
  likely_manager: Manager | null;
  priority: "High" | "Medium" | "Low";
  hiring_manager?: string;
  work_mode?: string;
  extraction_method?: string;
  description_captured?: boolean;
}

export type CoverageStatus = "full_jd" | "titles_only" | "signals_only" | "failed";

export interface Provenance {
  extraction_method: string;
  method_label: string;
  coverage_status: CoverageStatus;
  coverage_label: string;
  roles: number;
  roles_full_jd: number;
}

export interface Person {
  name: string;
  title: string;
  department?: string;
  level?: string;
  city?: string;
  linkedin?: string;
}

export interface Field {
  summary: string;
  significance?: string;
  sources?: string[];
}

export interface Hotspot {
  field: string;
  roles: number;
  critical: number;
  skills: string[];
  leader: string;
}

export interface StrategicSignal {
  type: "Partnership" | "Tool gravitation" | "Vision / change";
  headline: string;
  vendor: string;
  source: string;
  ey_opportunity: string;
}

export interface ToolGravitation {
  vendor: string;
  hiring: number;
  mentions: number;
  ey_angle: string;
  source: string;
}

export interface Account {
  name: string;
  slug: string;
  sector: string;
  region: string;
  has_data: boolean;
  has_signals: boolean;
  coverage_status: CoverageStatus;
  coverage_label: string;
}

export interface Company {
  slug: string;
  name: string;
  sector: string;
  listing: string;
  region: string;
  provenance?: Provenance;
  strategic_signals: StrategicSignal[];
  tool_gravitation: ToolGravitation[];
  direction: string;
  narrative?: string;
  total: number;
  critical: number;
  employment: [string, number][];
  hotspot: Hotspot | null;
  intensity: [string, number][];
  takeaways: string[];
  current_state: string;
  discovery_questions: string[];
  strategy: string;
  why: string;
  investments: string;
  stakeholders: string;
  actions: string[];
  people: Person[];
  recruiters: Person[];
  departments: [string, number][];
  skills: [string, number][];
  seniority: [string, number][];
  locations: [string, number][];
  opportunities: { interpretation: string; ey_response: string; evidence?: string }[];
  fields: Record<string, Field>;
  filings: number;
}

export interface TechRadarGroup {
  group: string;
  adoption: number;
  members: [string, number][];
}

export interface JourneyStage {
  n: number;
  name: string;
  covered: boolean;
  desc: string;
  metric: string;
  count: number | null;
}

export interface Data {
  generated: string;
  month_label: string;
  window: string;
  names: Record<string, string>;
  accounts: Account[];
  regions: Record<string, string>;
  companies: Company[];
  tech_radar: TechRadarGroup[];
  opportunity_radar: { signal: string; ey_response: string; clients: string[] }[];
  field_labels: Record<string, string>;
  roles_by_company: Record<string, Role[]>;
  sales_journey: JourneyStage[];
}
