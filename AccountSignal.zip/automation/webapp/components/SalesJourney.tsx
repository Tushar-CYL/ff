import clsx from "clsx";
import type { JourneyStage } from "@/lib/types";

export default function SalesJourney({ stages }: { stages: JourneyStage[] }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {stages.map((s) => (
        <div
          key={s.n}
          className={clsx(
            "flex-1 min-w-[132px] rounded-lg px-3 py-2.5 border transition-colors",
            s.covered
              ? "bg-[#1f1f2a] text-white border-[#ffe60055]"
              : "bg-[#14141c] text-ey-faint border-[#2b2b38]"
          )}
        >
          <div className="flex items-center gap-2">
            <span
              className={clsx(
                "w-5 h-5 rounded-full grid place-items-center text-[10px] font-extrabold",
                s.covered ? "bg-ey-yellow text-ey-black" : "bg-ey-lt text-ey-faint"
              )}
            >
              {s.n}
            </span>
            <span className={clsx("text-[11px] font-bold leading-tight", s.covered && "text-white")}>
              {s.name}
            </span>
          </div>
          {s.covered ? (
            <div className="mt-1.5">
              <div className="text-ey-yellow text-lg font-extrabold leading-none">{s.count}</div>
              <div className="text-[9.5px] text-gray-400 uppercase tracking-wide">{s.metric}</div>
            </div>
          ) : (
            <div className="mt-1.5">
              <div className="text-[10px] text-ey-faint leading-snug">{s.desc}</div>
              <div className="text-[8.5px] uppercase tracking-wide text-ey-faint/70 mt-1 font-semibold">Team-led</div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
