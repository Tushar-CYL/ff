"use client";
import { useEffect, useState } from "react";
import { useData } from "@/lib/data";
import type { Data } from "@/lib/types";
import { SectionTitle } from "@/components/ui";
import Echart from "@/components/Echart";

function CountUp({ value }: { value: number }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0; const start = performance.now(), dur = 850;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <>{n.toLocaleString()}</>;
}

const BAR = "#ffe600";
function hbar(data: [string, number][], n = 8) {
  const d = data.slice(0, n).reverse();
  return {
    grid: { left: 140, right: 40, top: 6, bottom: 6 },
    xAxis: { type: "value", show: false },
    yAxis: {
      type: "category", data: d.map((x) => x[0]),
      axisTick: { show: false }, axisLine: { show: false },
      axisLabel: { color: "#c7c7d0", fontSize: 11.5 },
    },
    series: [{
      type: "bar", data: d.map((x) => x[1]), barWidth: 14,
      itemStyle: { color: BAR, borderRadius: 4 },
      label: { show: true, position: "right", color: "#e9e9ee", fontWeight: 800, fontSize: 11 },
    }],
  };
}

function radarOption(items: { practice: string; value: number }[]) {
  const max = Math.max(...items.map((i) => i.value), 1);
  return {
    tooltip: {},
    radar: {
      indicator: items.map((i) => ({ name: i.practice, max })),
      radius: "66%", splitNumber: 4,
      axisName: { color: "#c7c7d0", fontSize: 10.5 },
      splitLine: { lineStyle: { color: "#2b2b38" } },
      splitArea: { areaStyle: { color: ["#15151f", "#1a1a24"] } },
      axisLine: { lineStyle: { color: "#2b2b38" } },
    },
    series: [{
      type: "radar",
      data: [{
        value: items.map((i) => i.value),
        areaStyle: { color: "rgba(255,230,0,.22)" },
        lineStyle: { color: BAR, width: 2 }, itemStyle: { color: BAR },
      }],
    }],
  };
}

function treeOption(d: Data) {
  const root = {
    name: "Open roles",
    children: d.sectors.filter((s) => s.roles > 0).map((s) => ({
      name: `${s.name} · ${s.roles}`,
      children: s.companies.slice(0, 8).map((c) => ({ name: `${c.name} (${c.roles})`, value: c.roles })),
    })),
  };
  return {
    tooltip: { trigger: "item", triggerOn: "mousemove" },
    series: [{
      type: "tree", data: [root], top: 8, left: 110, bottom: 8, right: 180,
      symbolSize: 7, orient: "LR", initialTreeDepth: 1, expandAndCollapse: true,
      itemStyle: { color: BAR, borderColor: BAR },
      label: { color: "#e9e9ee", fontSize: 11, position: "left", align: "right" },
      leaves: { label: { position: "right", align: "left", color: "#c7c7d0" } },
      lineStyle: { color: "#3a3a4a", width: 1 },
      emphasis: { focus: "descendant" },
      animationDuration: 450,
    }],
  };
}

function heatmapOption(dm: Data["demand_matrix"]) {
  const secs = dm.sectors.map((s) => s.name);
  const pracs = dm.practices.map((p) => p.name.replace(" tools", "").replace(" / CRM", "").replace(" & Infra", ""));
  const maxVal = Math.max(1, ...dm.cells.map((c) => c[2]));
  return {
    tooltip: {
      position: "top",
      formatter: (p: any) =>
        `${secs[p.data[1]]}<br/>${dm.practices[p.data[0]].name}: <b>${p.data[2]}</b> role${p.data[2] === 1 ? "" : "s"}`,
    },
    grid: { left: 150, right: 18, top: 44, bottom: 10, containLabel: false },
    xAxis: {
      type: "category", data: pracs, position: "top",
      axisTick: { show: false }, axisLine: { show: false },
      axisLabel: { color: "#c7c7d0", fontSize: 10.5, interval: 0, rotate: 0, hideOverlap: false,
        formatter: (v: string) => v.length > 10 ? v.slice(0, 9) + "…" : v },
      splitArea: { show: false },
    },
    yAxis: {
      type: "category", data: secs,
      axisTick: { show: false }, axisLine: { show: false },
      axisLabel: { color: "#e9e9ee", fontSize: 11, fontWeight: 600 },
      splitArea: { show: false },
    },
    visualMap: {
      min: 0, max: maxVal, calculable: false, show: false,
      inRange: { color: ["#15151f", "#3a3410", "#8a7d12", "#ffe600"] },
    },
    series: [{
      type: "heatmap",
      // store expects [sectorIdx, practiceIdx, count]; ECharts heatmap wants [x,y,val]=[prac,sec,val]
      data: dm.cells.map((c) => [c[1], c[0], c[2]]),
      label: { show: true, color: "#0b0b0f", fontSize: 10.5, fontWeight: 800,
        formatter: (p: any) => (p.data[2] > 0 ? p.data[2] : "") },
      itemStyle: { borderColor: "#0b0b0f", borderWidth: 2, borderRadius: 3 },
      emphasis: { itemStyle: { borderColor: "#fff", borderWidth: 1.5 } },
    }],
  };
}

export default function Summary() {
  const { data, error } = useData();
  if (error) return <div className="mt-10 text-[#ff8a7a]">Could not load data.json — {error}</div>;
  if (!data) return <div className="mt-10 text-gray-500">Loading…</div>;

  const t = data.totals;
  const topCity = data.locations[0]?.city || "—";
  const kpis = [
    { v: t.roles, l: "Open India roles", s: "last 30 days", accent: "text-white" },
    { v: t.with_roles, l: "Accounts hiring", s: `of ${t.companies} tracked`, accent: "text-[#57e188]" },
    { v: t.sectors, l: "Industry sectors", s: "coverage", accent: "text-ey-yellow" },
    { v: data.locations[0]?.roles || 0, l: `Roles in ${topCity}`, s: "top GCC hub", accent: "text-[#35a4e8]" },
  ];

  return (
    <div>
      <div className="mt-5">
        <h1 className="text-xl font-extrabold m-0 text-white">Market Insights — Summary</h1>
        <div className="text-gray-500 text-xs">{data.month_label}</div>
      </div>

      <div className="grid gap-3.5 grid-cols-2 md:grid-cols-4 mt-4">
        {kpis.map((k, i) => (
          <div key={i} className="card p-4 relative overflow-hidden animate-in" style={{ animationDelay: `${i * 0.06}s` }}>
            <span className="absolute left-0 top-0 bottom-0 w-1 bg-ey-yellow" />
            <div className={`text-[28px] font-extrabold leading-none ${k.accent}`}><CountUp value={k.v} /></div>
            <div className="text-gray-300 text-xs mt-1.5 font-semibold">{k.l}</div>
            <div className="text-gray-500 text-[11px]">{k.s}</div>
          </div>
        ))}
      </div>

      <SectionTitle title="Overall open roles" note="where the demand sits — by sector, tech space and location" />
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card p-4">
          <div className="sub mb-2">In different sectors / industry</div>
          <Echart option={hbar(data.sectors.map((s) => [s.name, s.roles])) as any} height={210} />
        </div>
        <div className="card p-4">
          <div className="sub mb-2">In different tech space</div>
          <Echart option={hbar(data.practices.map((p) => [p.name, p.roles])) as any} height={210} />
        </div>
        <div className="card p-4">
          <div className="sub mb-2">In different locations</div>
          <Echart option={hbar(data.locations.map((l) => [l.city, l.roles])) as any} height={210} />
        </div>
      </div>

      <SectionTitle title="Technology demand radar" note="skill/tool practices hired for across the whole book" />
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-4"><Echart option={radarOption(data.tech_radar) as any} height={300} /></div>
        <div className="card p-4">
          <div className="sub mb-1">Decomposition — sector → companies</div>
          <div className="text-[11px] text-gray-500 mb-1">click a sector to expand the companies hiring in it</div>
          <Echart option={treeOption(data) as any} height={300} />
        </div>
      </div>

      <SectionTitle title="Where capabilities are being built" note="sector × tech practice — India roles mapped to each capability, by industry" />
      <div className="card p-4">
        {data.demand_matrix.sectors.length > 0 ? (
          <>
            <Echart
              option={heatmapOption(data.demand_matrix) as any}
              height={Math.max(220, data.demand_matrix.sectors.length * 34 + 60)}
            />
            <div className="text-[11px] text-gray-500 mt-2">
              Brighter cells mark where a sector is building most. Rows and columns are ranked by total demand; blank cells mean no India roles mapped to that capability this month.
            </div>
          </>
        ) : (
          <div className="text-ey-faint text-xs py-8 text-center">No tech-mapped roles yet.</div>
        )}
      </div>

      <footer className="text-gray-500 text-[11px] mt-8 pt-3.5 border-t border-[#2b2b38]">
        India hiring scraped from each client's own career portal; market signals from public news. Last 30 days. Internal use.
      </footer>
    </div>
  );
}
