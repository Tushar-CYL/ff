"""Enrich hiring roles with department, skills, employment type and critical-role
flag — deterministic keyword heuristics (no LLM cost, runs on all 400+ roles).
Seniority is already set by the scraper. Nothing is invented; empty when unknown.
"""
from __future__ import annotations

import re

from ..store.schema import Role

# department <- keywords in the role title (business-domain buckets from the brief)
_DEPARTMENTS: list[tuple[str, tuple[str, ...]]] = [
    ("Finance", ("finance", "accounting", "controller", "fp&a", "treasury", "audit", "tax")),
    ("Supply Chain", ("supply chain", "logistics", "procurement", "sourcing", "planning", "warehouse", "inventory")),
    ("Clinical/R&D", ("clinical", "r&d", "regulatory affairs", "pharmacovig", "drug safety", "biolog", "chemist", "research scientist", "laboratory", "preclinical")),
    ("Risk & Compliance", ("risk", "compliance", "legal", "governance", "fraud", "aml", "security")),
    ("Manufacturing", ("manufactur", "production", "plant", "quality", "maintenance", "operator", "assembly")),
    ("Commercial & Marketing", ("sales", "marketing", "commercial", "brand", "category", "trade", "account manager", "business development")),
    ("HR & People", ("hr", "human resource", "talent", "recruit", "people", "learning")),
    ("Technology / IT", ("engineer", "developer", "software", "data", "it ", "devops", "cloud", "analyst", "architect", "cyber", "ml", "ai ", "sap", "platform", "qa", "test")),
]

# skills / tech to detect in the title
_SKILLS = ("SAP", "Azure", "AWS", "GCP", "Power BI", "Python", "Java", "SQL",
           "GenAI", "AI", "ML", "Salesforce", "Oracle", "Kubernetes", "React",
           "Tableau", "Spark", "Snowflake", "Workday", ".NET", "Linux")

_CRITICAL = ("head", "director", "chief", "vp", "vice president", "lead architect",
             "principal", "gcc", "capability centre", "capability center")


def _department(title: str) -> str:
    t = title.lower()
    for dept, kws in _DEPARTMENTS:
        if any(k in t for k in kws):
            return dept
    return ""


def _skills(title: str) -> list[str]:
    out = []
    for s in _SKILLS:
        if re.search(r"\b" + re.escape(s.lower()) + r"\b", title.lower()):
            out.append(s)
    return out


def classify(role: Role) -> Role:
    title = role.role or ""
    if not role.department:
        role.department = _department(title)
    if not role.skills:
        role.skills = _skills(title)
    if not role.critical_role:
        role.critical_role = any(k in title.lower() for k in _CRITICAL)
    return role
