"""Derive strategic signals + short 'so what for EY' takeaways per company.
EYQ when available; deterministic heuristics otherwise."""
from __future__ import annotations

import json
import logging
import re

from ..store.schema import MarketIntel, Role, Signals
from .eyq_client import EYQClient

log = logging.getLogger("accountsignal.enrich.signals")

_TOOLS = ("SAP", "Azure", "AWS", "GCP", "Power BI", "Python", "Salesforce",
          "Oracle", "Workday", "ServiceNow", "Snowflake", "Databricks", "SAP S/4HANA",
          "GenAI", "AI", "Cloud", "Tableau", "Kubernetes")

_SYSTEM = (
    "You are an EY account strategist. From the supplied market-intelligence "
    "summaries and India hiring signals, produce concise, client-ready JSON. "
    "Use only the given facts. Each list item is one short straight sentence."
)


def _clean(title: str) -> str:
    return title.split(" - ")[0].strip()


def _tool_gravitation(mi: MarketIntel, roles: list[Role]) -> list[str]:
    hay = " ".join(it.title for c in ("partnerships", "vision", "expansion")
                   for it in getattr(mi, c).items).lower()
    hay += " " + " ".join((r.role + " " + " ".join(r.skills)) for r in roles).lower()
    found = []
    for t in _TOOLS:
        if re.search(r"\b" + re.escape(t.lower()) + r"\b", hay):
            found.append(t)
    # de-dup keep order, cap
    out, seen = [], set()
    for t in found:
        if t.lower() not in seen:
            seen.add(t.lower()); out.append(t)
    return out[:8]


def _mock_signals(company: str, mi: MarketIntel, roles: list[Role]) -> Signals:
    part = [_clean(it.title) for it in mi.partnerships.items[:3]]
    vis = [_clean(it.title) for it in mi.vision.items[:3]]
    tools = _tool_gravitation(mi, roles)
    takeaways = []
    if tools:
        takeaways.append(f"{company} leans on {', '.join(tools[:4])} — a natural EY technology & transformation entry point.")
    if mi.expansion.items:
        takeaways.append(f"Active expansion/investment signals suggest demand for EY advisory on scaling India/GCC operations.")
    if roles:
        depts = {r.department for r in roles if r.department}
        if depts:
            takeaways.append(f"India hiring concentrated in {', '.join(sorted(depts)[:3])} — aligns with EY managed-services opportunities.")
    return Signals(partnership_signals=part, vision_shifts=vis,
                   tool_gravitation=tools, ey_takeaways=takeaways[:4])


def _eyq_signals(client: EYQClient, company: str, mi: MarketIntel, roles: list[Role]) -> Signals:
    summaries = {c: getattr(mi, c).summary for c in ("hiring", "vision", "partnerships", "financial", "expansion")}
    depts = sorted({r.department for r in roles if r.department})
    tools_hint = _tool_gravitation(mi, roles)
    user = (
        f"Company: {company}\n"
        f"Market-intel summaries: {json.dumps(summaries)}\n"
        f"India hiring departments: {depts}\n"
        f"Tools detected: {tools_hint}\n\n"
        "Return JSON with keys: partnership_signals, vision_shifts, tool_gravitation, "
        "ey_takeaways (each a list of <=4 short sentences). ey_takeaways = the 'so what for EY'."
    )
    data = client.chat_json(_SYSTEM, user, max_tokens=600)
    if not data:
        return _mock_signals(company, mi, roles)
    def _lst(k):
        v = data.get(k, [])
        return [str(x).strip() for x in v][:4] if isinstance(v, list) else []
    return Signals(
        partnership_signals=_lst("partnership_signals"),
        vision_shifts=_lst("vision_shifts"),
        tool_gravitation=_lst("tool_gravitation") or tools_hint,
        ey_takeaways=_lst("ey_takeaways"),
    )


def enrich(company: str, mi: MarketIntel, roles: list[Role], client: EYQClient) -> Signals:
    if client.mock:
        return _mock_signals(company, mi, roles)
    return _eyq_signals(client, company, mi, roles)
