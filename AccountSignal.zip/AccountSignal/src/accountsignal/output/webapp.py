"""Transform the normalized store into the Next.js webapp's data.json shape.

The webapp (webapp/) fetches /data.json at runtime, so we only need to write a
file matching its `Data` TypeScript contract (lib/types.ts). Static facts
(sector, listing, region) are reused from the existing data.json by company
name; everything dated/dynamic (roles, news, signals, aggregations, summaries)
is regenerated fresh from this run. No LinkedIn / people data is emitted.
"""
from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

from .. import config
from ..store import io

log = logging.getLogger("accountsignal.output.webapp")

CATS = ("hiring", "vision", "partnerships", "financial", "expansion")
# my category -> webapp fields key
_FIELD_KEY = {"hiring": "hiring", "vision": "vision_strategy", "partnerships": "partnerships",
              "financial": "money_metrics", "expansion": "expansion"}
_FIELD_LABELS = {"hiring": "Hiring", "vision_strategy": "Vision & strategy",
                 "partnerships": "Partnerships", "money_metrics": "Financial performance",
                 "expansion": "Expansion"}
_REGIONS = {"BLR": "Bengaluru", "Hyd": "Hyderabad", "West": "West (Mumbai / Pune)", "": "—"}

_SENIORITY = {"Manager-Lead": "Manager/Lead"}  # normalize to webapp label
_DEPT_NORMALIZE = {"Clinical/R&D": "Clinical / R&D"}

# skill -> technology theme (for intensity donut, tech radar, opportunities)
_THEMES: list[tuple[str, tuple[str, ...]]] = [
    ("Data & analytics", ("sql", "power bi", "tableau", "spark", "snowflake", "databricks", "data")),
    ("ERP", ("sap", "oracle", "s/4hana")),
    ("Cloud platform", ("aws", "azure", "gcp", "google cloud", "cloud", "kubernetes")),
    ("AI & GenAI", ("genai", " ai", "ai ", "machine learning", "ml")),
    ("Cybersecurity", ("cyber", "security")),
    ("Enterprise apps", ("salesforce", "servicenow", "workday", "dynamics")),
]
_THEME_RESPONSE = {
    "Data & analytics": "Data engineering, governance and analytics managed services",
    "ERP": "SAP S/4HANA / ERP transformation and data migration",
    "Cloud platform": "Cloud migration, platform engineering and FinOps",
    "AI & GenAI": "AI strategy, architecture and governance",
    "Cybersecurity": "Cyber strategy, identity and managed detection",
    "Enterprise apps": "Enterprise application implementation and run",
}
_VENDOR_ANGLE = {
    "SAP": "SAP S/4HANA / ERP transformation and data migration",
    "Azure": "Azure migration, platform engineering and governance",
    "AWS": "AWS migration and data engineering",
    "GCP": "Google Cloud migration and data engineering",
    "Power BI": "Enterprise BI and analytics modernization",
    "Python": "Data engineering and automation delivery",
    "Salesforce": "Salesforce implementation and run",
    "Workday": "Workday deployment and integration",
    "ServiceNow": "ServiceNow ITSM / workflow automation",
    "Snowflake": "Lakehouse / cloud data platform build",
    "Databricks": "Lakehouse / data platform engineering",
    "AI": "AI strategy, architecture and governance",
    "Cloud": "Cloud migration and platform engineering",
}


def _slug(name: str) -> str:
    s = name.lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "-", s)
    return s.strip("-")


def _norm_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def _theme_for(text: str) -> str | None:
    t = text.lower()
    for theme, kws in _THEMES:
        if any(k in t for k in kws):
            return theme
    return None


def _emp_cat(raw: str) -> str:
    t = (raw or "").lower()
    if "intern" in t:
        return "Internship"
    if "contract" in t or "temp" in t:
        return "Contract"
    return "Permanent"


def _priority(role: dict) -> str:
    if role.get("critical_role"):
        return "High"
    if role.get("seniority") in ("Executive", "Manager-Lead"):
        return "Medium"
    return "Low"


def _load_base() -> dict[str, dict]:
    """Static facts (sector, listing, region) keyed by normalized name."""
    out: dict[str, dict] = {}
    if config.WEBAPP_DATA.exists():
        try:
            prev = io.read_json(config.WEBAPP_DATA)
            for c in prev.get("companies", []):
                out[_norm_name(c.get("name", ""))] = {
                    "sector": c.get("sector", "—"),
                    "listing": c.get("listing", ""),
                    "region": c.get("region", ""),
                }
        except Exception as exc:
            log.info("webapp: could not read base data.json: %s", exc)
    return out


def _counts(pairs: Counter) -> list[list]:
    return [[k, v] for k, v in pairs.most_common()]


def _region_from_locations(loc_counts: Counter) -> str:
    if not loc_counts:
        return ""
    top = loc_counts.most_common(1)[0][0].lower()
    if any(x in top for x in ("bengaluru", "bangalore")):
        return "BLR"
    if "hyderabad" in top:
        return "Hyd"
    if any(x in top for x in ("mumbai", "pune")):
        return "West"
    return "BLR"


def _clean(title: str) -> str:
    return title.split(" - ")[0].strip()


def _build_company(rec: dict, base: dict[str, dict]) -> tuple[dict, list[dict]]:
    name = rec["company"]
    slug = _slug(name)
    roles_in = rec.get("hiring_india", [])
    mi = rec["market_intel"]
    sig = rec.get("signals", {})
    meta = base.get(_norm_name(name), {})

    # ---- roles ----
    roles: list[dict] = []
    dept_c, skill_c, sen_c, emp_c, loc_c = Counter(), Counter(), Counter(), Counter(), Counter()
    theme_c = Counter()
    for r in roles_in:
        dept = _DEPT_NORMALIZE.get(r.get("department", ""), r.get("department", ""))
        sen = _SENIORITY.get(r.get("seniority", ""), r.get("seniority", ""))
        emp = _emp_cat(r.get("employment_type", ""))
        loc = r.get("city") or ""
        skills = r.get("skills", []) or []
        roles.append({
            "role_title": r.get("role", ""), "business_domain": dept or "Other",
            "team": "", "reports_to": "", "location": (loc + ", India") if loc else "India",
            "seniority": sen or "Mid", "skills": skills,
            "posted_date": r.get("posted_date", ""), "aging_days": r.get("days_open"),
            "source_url": r.get("source_url", ""), "critical": bool(r.get("critical_role")),
            "employment_category": emp, "likely_manager": None, "priority": _priority(r),
            "hiring_manager": r.get("hiring_manager") or "", "work_mode": "",
            "extraction_method": rec.get("ats") or "indeed", "description_captured": False,
        })
        if dept:
            dept_c[dept] += 1
        for s in skills:
            skill_c[s] += 1
            th = _theme_for(s)
            if th:
                theme_c[th] += 1
        if sen:
            sen_c[sen] += 1
        emp_c[emp] += 1
        if loc:
            loc_c[loc] += 1
        th = _theme_for(r.get("role", ""))
        if th:
            theme_c[th] += 1

    total = len(roles)
    critical = sum(1 for r in roles if r["critical"])

    # ---- hotspot ----
    hotspot = None
    if dept_c:
        top_field, top_n = dept_c.most_common(1)[0]
        hs_skills = Counter()
        for r in roles:
            if r["business_domain"] == top_field:
                for s in r["skills"]:
                    hs_skills[s] += 1
        hotspot = {"field": top_field, "roles": top_n,
                   "critical": sum(1 for r in roles if r["business_domain"] == top_field and r["critical"]),
                   "skills": [k for k, _ in hs_skills.most_common(6)], "leader": ""}

    # ---- strategic signals from news ----
    strategic_signals = []
    for it in mi["partnerships"]["items"][:3]:
        strategic_signals.append({"type": "Partnership", "headline": _clean(it["title"]),
                                  "vendor": "", "source": it.get("url", ""),
                                  "ey_opportunity": "Explore where EY can enable or extend this partnership"})
    for it in mi["vision"]["items"][:2]:
        strategic_signals.append({"type": "Vision / change", "headline": _clean(it["title"]),
                                  "vendor": "", "source": it.get("url", ""),
                                  "ey_opportunity": "Shape a point of view aligned to the stated direction"})

    # ---- tool gravitation from signals + hiring ----
    tool_gravitation = []
    for vendor in (sig.get("tool_gravitation") or [])[:8]:
        hits = sum(1 for r in roles if vendor.lower() in (r["role_title"] + " " + " ".join(r["skills"])).lower())
        tool_gravitation.append({"vendor": vendor, "hiring": hits, "mentions": 0,
                                 "ey_angle": _VENDOR_ANGLE.get(vendor, f"{vendor} delivery and integration"), "source": ""})

    # ---- intensity + opportunities ----
    intensity = _counts(theme_c)
    opportunities = [{"interpretation": f"{th} activity", "ey_response": _THEME_RESPONSE.get(th, "EY advisory"),
                      "evidence": f"{n} matching roles", "weight": n} for th, n in theme_c.most_common(6)]

    # ---- fields (market intelligence summaries) ----
    fields = {}
    for cat in CATS:
        f = mi[cat]
        fields[_FIELD_KEY[cat]] = {"summary": f.get("summary", ""), "significance": "",
                                   "sources": [i.get("url", "") for i in f["items"][:3]]}

    takeaways = sig.get("ey_takeaways", [])
    narrative = (mi["vision"]["summary"] or mi["partnerships"]["summary"] or "")[:260]
    direction = "Growth" if mi["expansion"]["items"] else ("Mixed" if total else "Signals")

    # ---- analyst text (data-driven; upgraded automatically when EYQ runs enrich) ----
    top_dept = dept_c.most_common(1)[0][0] if dept_c else ""
    tools = [t["vendor"] for t in tool_gravitation][:4]
    strategy = mi["vision"]["summary"] or ""
    why = (f"India hiring concentrates in {top_dept} ({dept_c.most_common(1)[0][1]} of {total} roles), "
           f"indicating active delivery build-out." if hotspot else "")
    investments = (f"Hiring and signals point to investment in {', '.join(tools)}." if tools else "")
    stakeholders = (f"Engage {top_dept} leadership and transformation owners." if top_dept else "")
    actions = takeaways[:4]

    company = {
        "slug": slug, "name": name, "sector": meta.get("sector", "—"),
        "listing": meta.get("listing", ""), "region": meta.get("region") or _region_from_locations(loc_c),
        "provenance": {
            "extraction_method": rec.get("ats") or "indeed",
            "method_label": (rec.get("ats") or "Indeed").title(),
            "coverage_status": "full_jd" if total else "signals_only",
            "coverage_label": "Full JD" if total else "Signals only",
            "roles": total, "roles_full_jd": total,
        },
        "strategic_signals": strategic_signals, "tool_gravitation": tool_gravitation,
        "direction": direction, "narrative": narrative, "total": total, "critical": critical,
        "employment": _counts(emp_c), "hotspot": hotspot, "intensity": intensity,
        "takeaways": takeaways, "current_state": narrative, "discovery_questions": [],
        "strategy": strategy, "why": why, "investments": investments, "stakeholders": stakeholders,
        "actions": actions, "people": [], "recruiters": [],
        "departments": _counts(dept_c), "skills": _counts(skill_c), "seniority": _counts(sen_c),
        "locations": _counts(loc_c), "opportunities": opportunities, "fields": fields, "filings": 0,
    }
    return company, roles


def build(out_path: Path | None = None) -> Path:
    out_path = out_path or config.WEBAPP_DATA
    base = _load_base()
    data = io.read_json(io.normalized_path())
    today = date.today().isoformat()

    companies, roles_by_company, names, accounts = [], {}, {}, []
    theme_clients: dict[str, list[str]] = defaultdict(list)
    tech_members: dict[str, Counter] = defaultdict(Counter)

    for rec in data:
        company, roles = _build_company(rec, base)
        slug = company["slug"]
        companies.append(company)
        roles_by_company[slug] = roles
        names[slug] = company["name"]
        accounts.append({
            "name": company["name"], "slug": slug, "sector": company["sector"],
            "region": company["region"], "has_data": company["total"] > 0,
            "has_signals": bool(company["strategic_signals"] or any(
                company["fields"][k]["summary"] for k in company["fields"])),
            "coverage_status": company["provenance"]["coverage_status"],
            "coverage_label": company["provenance"]["coverage_label"],
        })
        # radars
        if company["intensity"]:
            theme_clients[company["intensity"][0][0]].append(company["name"])
        for s, n in company["skills"]:
            th = _theme_for(s)
            if th:
                tech_members[th][s] += n

    tech_radar = []
    for group, members in tech_members.items():
        tech_radar.append({"group": group, "adoption": sum(members.values()),
                           "members": [[k, v] for k, v in members.most_common(6)]})
    tech_radar.sort(key=lambda g: g["adoption"], reverse=True)

    opportunity_radar = []
    for theme, clients in sorted(theme_clients.items(), key=lambda x: -len(x[1])):
        opportunity_radar.append({"signal": f"{theme} capability build-up",
                                  "ey_response": _THEME_RESPONSE.get(theme, "EY advisory"),
                                  "clients": clients[:12]})

    with_data = sum(1 for a in accounts if a["has_data"])
    sales_journey = [
        {"n": 1, "name": "Market & Account Insight", "covered": True,
         "desc": "Where to play and who to target", "metric": "accounts analysed", "count": len(companies)},
        {"n": 2, "name": "Relationship Building", "covered": True,
         "desc": "Engage key stakeholders, earn the right to advise", "metric": "accounts with signals",
         "count": sum(1 for a in accounts if a["has_signals"])},
        {"n": 3, "name": "Opportunity Identification", "covered": True,
         "desc": "Turn signals into concrete EY plays", "metric": "accounts with live hiring", "count": with_data},
        {"n": 4, "name": "Pursuit & Proposal", "covered": False,
         "desc": "Qualify and pursue", "metric": "", "count": None},
        {"n": 5, "name": "Delivery & Expansion", "covered": False,
         "desc": "Deliver and grow the account", "metric": "", "count": None},
    ]

    payload = {
        "generated": today,
        "month_label": f"India · all departments · open roles, last 30 days (as of {today})",
        "window": 30, "names": names, "accounts": accounts, "regions": _REGIONS,
        "companies": companies, "tech_radar": tech_radar, "opportunity_radar": opportunity_radar,
        "field_labels": _FIELD_LABELS, "roles_by_company": roles_by_company,
        "sales_journey": sales_journey,
    }

    out_path.parent.mkdir(parents=True, exist_ok=True)
    io.write_json(out_path, payload)
    # also feed the prebuilt static export (out/data.json) if it exists, so the
    # app serves fresh data without a rebuild.
    export_data = config.WEBAPP_DIR / "out" / "data.json"
    if export_data.parent.exists():
        io.write_json(export_data, payload)
    log.info("webapp data.json written -> %s (%d companies, %d roles)",
             out_path, len(companies), sum(len(v) for v in roles_by_company.values()))
    return out_path
