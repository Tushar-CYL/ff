"""Normalized data model — the single source of truth consumed by Excel + UI.

Uses plain dataclasses (stdlib only) so there is no pydantic dependency to
install on the office laptop. `to_dict` / `from_dict` handle (de)serialization.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class Role:
    """One open India role (hiring = India only, posted last month)."""
    role: str = ""
    city: str = ""
    country: str = "India"
    department: str = ""            # Finance, Supply Chain, Clinical/R&D, ...
    skills: list[str] = field(default_factory=list)
    seniority: str = ""             # Executive / Manager-Lead / Senior / Mid / Junior
    experience_years: str = ""      # free text where stated, else ""
    employment_type: str = ""       # Permanent/Full-time vs Contract/Temp/Intern
    posted_date: str = ""           # ISO date
    days_open: int | None = None
    critical_role: bool = False
    job_id: str = ""
    source_url: str = ""
    hiring_manager: str | None = None  # only if named in the posting


@dataclass(slots=True)
class NewsItem:
    title: str = ""
    url: str = ""
    date: str = ""                  # ISO date
    source: str = ""
    category: str = ""              # hiring/vision/partnerships/financial/expansion
    summary: str = ""               # one clean sentence (filled by enrichment)
    _score: float = 0.0             # INTERNAL relevance rank — never rendered


@dataclass(slots=True)
class MarketField:
    summary: str = ""               # clean paragraph, no duplication
    items: list[NewsItem] = field(default_factory=list)


@dataclass(slots=True)
class MarketIntel:
    hiring: MarketField = field(default_factory=MarketField)
    vision: MarketField = field(default_factory=MarketField)
    partnerships: MarketField = field(default_factory=MarketField)
    financial: MarketField = field(default_factory=MarketField)
    expansion: MarketField = field(default_factory=MarketField)


@dataclass(slots=True)
class Signals:
    partnership_signals: list[str] = field(default_factory=list)
    vision_shifts: list[str] = field(default_factory=list)
    tool_gravitation: list[str] = field(default_factory=list)
    ey_takeaways: list[str] = field(default_factory=list)


@dataclass(slots=True)
class CompanyRecord:
    company: str = ""
    website: str = ""
    career_url: str = ""
    ats: str | None = None
    run_ts: str = ""
    hiring_india: list[Role] = field(default_factory=list)
    market_intel: MarketIntel = field(default_factory=MarketIntel)
    signals: Signals = field(default_factory=Signals)
    scrape_errors: list[str] = field(default_factory=list)  # what failed (transparency)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_public_dict(self) -> dict[str, Any]:
        """Dashboard payload: strips every internal ranking field (_score)."""
        d = self.to_dict()
        for mf in d.get("market_intel", {}).values():
            for item in mf.get("items", []):
                item.pop("_score", None)
        return d
