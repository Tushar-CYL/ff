"""Hiring cascade: try each available free method in order, then the Apify
fallback, and keep the first that yields India roles.

Order: Workday JSON API / Eightfold renderer (platform-optimal) -> generic
Playwright DOM -> Apify Indeed (paid-but-cheap, only when free methods find
nothing, so we still capture India hiring wherever it exists).
"""
from __future__ import annotations

import logging

from ...config import Company, Settings
from ...http import Http
from ...store.schema import Role
from . import apify_jobs, eightfold, generic, workday
from .detect import detect

log = logging.getLogger("accountsignal.hiring.dispatch")

# ATS platforms whose jobs never surface in the generic DOM scraper (API-only /
# anti-bot); skip straight to the Apify fallback to save time.
_HARD_ATS = {"phenom", "successfactors", "avature"}


def scrape_hiring(company: Company, http: Http, settings: Settings) -> tuple[list[Role], str | None, str]:
    """Return (roles, ats, note). Never raises; one method failing falls through."""
    career_url = company.career_url
    lookback = settings.lookback_days
    tried: list[str] = []

    def _try(name, fn):
        tried.append(name)
        try:
            roles = fn()
            if roles:
                return roles
        except Exception as exc:
            log.info("hiring %s failed for %s: %s", name, company.name, exc)
        return []

    ats = None
    roles: list[Role] = []
    if career_url:
        det = detect(career_url, http)
        ats = det.ats
        # 1) platform-optimal free method
        if ats == "workday":
            roles = _try("workday", lambda: workday.fetch_india_roles(career_url, http, lookback))
        elif ats == "eightfold":
            roles = _try("eightfold", lambda: eightfold.fetch_india_roles(career_url, http, lookback))
        # 2) universal free fallback (render + read job cards) — skip for
        #    API-only platforms where it never works.
        if not roles and ats not in _HARD_ATS:
            roles = _try("generic", lambda: generic.fetch_india_roles(career_url, http, lookback))

    # 3) Apify fallback (only if free methods found nothing) — captures India
    #    hiring from Indeed for any company, regardless of its ATS.
    source = "free"
    if not roles and settings.apify_token:
        roles = _try("apify", lambda: apify_jobs.fetch_india_roles(
            company.name, settings.apify_token, lookback,
            settings.apify_max_items, settings.apify_max_usd))
        if roles:
            source = "apify"

    note = f"ats={ats}; src={source}; tried={'>'.join(tried) or 'none'}; roles={len(roles)}"
    return roles, ats, note
