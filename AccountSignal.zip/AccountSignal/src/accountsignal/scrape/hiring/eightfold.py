"""Eightfold adapter — renders the India-filtered careers SPA with Playwright and
reads the job cards from the DOM (Eightfold exposes no stable public JSON API).

Covers companies whose careers run on Eightfold (e.g. Qualcomm, Chevron, BCG,
AstraZeneca, Applied Materials, Estee Lauder). Playwright is an optional dep; if
it is not installed this adapter returns [] with a note.
"""
from __future__ import annotations

import logging

from ...store.schema import Role
from . import base

log = logging.getLogger("accountsignal.hiring.eightfold")

# JS run in-page: collect one record per job anchor (title + card text + href)
_EXTRACT = r"""
() => {
  const anchors = [...document.querySelectorAll('a[href*="/careers/job/"], a[href*="/career/job/"], a[href*="/job/"]')];
  const seen = new Set(); const out = [];
  for (const a of anchors) {
    const href = a.href;
    if (!/\/job\//.test(href) || seen.has(href)) continue;
    seen.add(href);
    const card = a.closest('[data-test-id], li, .position-card, article, div');
    const text = (card ? card.innerText : a.innerText).trim();
    out.push({ href, text });
  }
  return out;
}
"""


def _parse_card(text: str, href: str) -> Role | None:
    lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
    if not lines:
        return None
    title = lines[0]
    # location = first line that reads as a place (India match or has a comma)
    location = ""
    for ln in lines[1:]:
        if base.is_india(ln) or ("," in ln and len(ln) < 60):
            location = ln
            break
    if not base.is_india(location):
        return None
    posted_date, days_open = "", None
    for ln in lines:
        if "posted" in ln.lower() or "ago" in ln.lower():
            posted_date, days_open = base.parse_relative_posted(ln)
            break
    job_id = href.rstrip("/").split("/")[-1]
    return Role(
        role=title, city=base.india_city(location), country="India",
        seniority=base.guess_seniority(title),
        posted_date=posted_date, days_open=days_open,
        job_id=job_id, source_url=href,
    )


def fetch_india_roles(career_url: str, http=None, lookback_days: int = 30) -> list[Role]:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        log.warning("eightfold: playwright not installed; skipping %s", career_url)
        return []

    from urllib.parse import urlparse
    host = urlparse(career_url).netloc or career_url
    url = f"https://{host}/careers?location=India&query=&sort_by=relevance"
    roles: list[Role] = []
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            context = browser.new_context(ignore_https_errors=True, user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"))
            page = context.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=45000)
            page.wait_for_timeout(5000)
            # Eightfold uses infinite scroll / "show more": scroll to load more cards
            last = 0
            for _ in range(12):
                page.mouse.wheel(0, 6000)
                page.wait_for_timeout(1200)
                n = page.evaluate("document.querySelectorAll('a[href*=\"/job/\"]').length")
                if n == last:
                    break
                last = n
            cards = page.evaluate(_EXTRACT)
            browser.close()
    except Exception as exc:
        log.warning("eightfold: render failed for %s: %s", host, exc)
        return []

    seen_ids = set()
    for c in cards:
        role = _parse_card(c.get("text", ""), c.get("href", ""))
        if not role or role.job_id in seen_ids:
            continue
        if not base.within_lookback(role.days_open, lookback_days):
            continue
        seen_ids.add(role.job_id)
        roles.append(role)
    log.info("eightfold: %s -> %d India roles", host, len(roles))
    return roles
