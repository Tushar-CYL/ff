"""Apify fallback adapter — Indeed India job listings via the misceres/indeed-scraper
actor (pay-per-result, $0.006/listing on the free tier). Used only when free
methods return nothing, so we capture India hiring wherever it actually exists.

A spend guard checks the account's month-to-date usage and skips the call if it
would risk exceeding the configured budget. Requires APIFY_TOKEN in .env and the
apify-client package (optional dependency).
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone

from ...store.schema import Role
from . import base

log = logging.getLogger("accountsignal.hiring.apify")

_ACTOR = "misceres/indeed-scraper"

_SENIORITY_MAP = {
    "entry_level": "Junior", "mid_level": "Mid", "senior_level": "Senior",
    "director": "Executive", "executive": "Executive",
}

# Cumulative Apify spend within THIS pipeline process (bounds cost per run; the
# free tier also hard-stops at its own $5 monthly ceiling).
_run_spend_usd = 0.0


def spent_this_run() -> float:
    return _run_spend_usd


def _days_open(iso: str) -> tuple[str, int | None]:
    if not iso:
        return "", None
    try:
        d = datetime.fromisoformat(iso.replace("Z", "+00:00")).date()
        return d.isoformat(), (date.today() - d).days
    except Exception:
        return "", None


def fetch_india_roles(company_name: str, token: str, lookback_days: int = 30,
                      max_items: int = 15, budget_usd: float = 4.5) -> list[Role]:
    if not token:
        return []
    try:
        from apify_client import ApifyClient
    except ImportError:
        log.warning("apify: apify-client not installed; skipping %s", company_name)
        return []

    global _run_spend_usd
    if _run_spend_usd >= budget_usd:
        log.warning("apify: budget guard hit ($%.2f >= $%.2f); skipping %s",
                    _run_spend_usd, budget_usd, company_name)
        return []

    client = ApifyClient(token)
    run_input = {
        "position": company_name, "country": "IN", "location": "India",
        "maxItems": max_items, "parseCompanyDetails": False, "saveOnlyUniqueItems": True,
    }
    try:
        run = client.actor(_ACTOR).call(run_input=run_input)
    except Exception as exc:
        log.warning("apify: run failed for %s: %s", company_name, exc)
        return []
    _run_spend_usd += float(run.usage_total_usd or 0.0)
    if run.status != "SUCCEEDED":
        log.warning("apify: run %s for %s", run.status, company_name)
        return []

    roles: list[Role] = []
    # The Indeed query is the company name, so results are already scoped to it;
    # we keep all India + last-month postings (no extra company filter, which
    # wrongly dropped e.g. "HCLTech" vs "HCL Technologies").
    for it in client.dataset(run.default_dataset_id).iterate_items():
        loc = it.get("location") or ""
        if not base.is_india(loc):
            continue
        posted_date, days_open = _days_open(it.get("postingDateParsed") or "")
        if not base.within_lookback(days_open, lookback_days):
            continue
        jt = it.get("jobType") or []
        roles.append(Role(
            role=(it.get("positionName") or "").strip(),
            city=base.india_city(loc), country="India",
            skills=[],
            seniority=_SENIORITY_MAP.get((it.get("experienceLevel") or "").lower(),
                                         base.guess_seniority(it.get("positionName", ""))),
            employment_type=", ".join(jt) if isinstance(jt, list) else str(jt),
            posted_date=posted_date, days_open=days_open,
            job_id=str(it.get("id") or ""),
            source_url=it.get("externalApplyLink") or it.get("url") or "",
        ))
    log.info("apify: %s -> %d India roles (run spend so far $%.2f)", company_name, len(roles), _run_spend_usd)
    return roles
